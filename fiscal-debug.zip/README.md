# Fiscal

CLI pipeline that extracts 10-year financial statement data from European
public company Annual Reports (Adyen, Heineken, SAP), classifies metrics,
and serves a web UI that exports a formatted PDF report on demand.

## Quick start (database already populated)

```bash
source .venv/bin/activate
fiscal serve          # → http://127.0.0.1:8080
```

Click **Run Pipeline & Download PDF** in the browser. The button runs the full
downstream pipeline (classify → build views → export) and downloads a combined
PDF report for all three companies.

## Setup from scratch

```bash
# 1. Create virtual environment and install
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -e ".[dev]"

# 2. Initialize database and directories
fiscal init

# 3. Discover filings from IR pages
fiscal discover

# 4. Download annual report PDFs  (~1–2 GB, takes a while)
fiscal download

# 5. Extract financial tables from PDFs
fiscal extract

# 6. Run the fast downstream pipeline
fiscal classify-metrics
fiscal build-views

# 7. Start the web UI
fiscal serve
```

Or run everything in one shot:

```bash
fiscal run-all
```

## CLI reference

| Command | Description |
|---------|-------------|
| `fiscal init` | Initialize database and `data/` directories |
| `fiscal discover` | Scrape IR pages, classify and store filing URLs |
| `fiscal download` | Download annual report PDFs to `data/pdfs/` |
| `fiscal extract` | Extract financial tables from PDFs |
| `fiscal classify-metrics` | Assign metric groups to raw line items |
| `fiscal build-views` | Compile 10-year aggregated views |
| `fiscal export` | Write CSV + JSON to `output/` |
| `fiscal export-pdf` | Write formatted PDF reports to `output/` |
| `fiscal run-all` | Run the full pipeline end-to-end |
| `fiscal serve` | Start the web UI (default: http://127.0.0.1:8080) |
| `fiscal status` | Show pipeline state and row counts |

All commands accept `--verbose / -v` for DEBUG-level logging.

```bash
fiscal serve --port 5000
fiscal classify-metrics --company adyen
fiscal export-pdf --company heineken
```

## Web UI

`fiscal serve` starts a Flask server with a single-page UI. The **Run Pipeline**
button:

1. Re-runs `classify-metrics` across all companies
2. Rebuilds `compiled_views`
3. Exports CSV + JSON to `output/`
4. Generates per-company PDFs, merges them into `output/fiscal_report.pdf`
5. Streams the combined PDF to the browser as a download

## PDF output

The PDF report mirrors the sample output format:

- Landscape A4, one section per statement type
- **Income Statement** — revenue, costs, EBITDA, net profit, tax, KPIs
- **Balance Sheet** — assets, liabilities, equity
- **Cash Flow Statement** — operating, investing, financing flows
- 6 most-recent fiscal years as columns
- Metrics placed by semantic `metric_group`, not PDF page location
- Footnote reference numbers automatically scrubbed from value cells


## Database

All pipeline state lives in `data/fiscal.db`. Key tables:

| Table | Contents |
|-------|----------|
| `filings` | Discovered filing URLs, download + extraction status |
| `raw_tables` | Extracted tables (JSON) from PDFs |
| `raw_line_items` | Parsed label + value rows from raw tables |
| `classified_metrics` | Metric group + key assignments per line item |
| `compiled_views` | Deduplicated 10-year pivot (one row per label/year) |

```bash
# Inspect with any SQLite client, e.g.:
sqlite3 data/fiscal.db ".tables"
sqlite3 data/fiscal.db "SELECT company, COUNT(*) FROM compiled_views GROUP BY 1;"
```

## Classification

The classifier (`fiscal/classify_metrics.py`) runs five layers in order:

1. **Company override** — exact label matches per company (score 1.0)
2. **Industry exact** — normalized label lookup per industry family (0.9)
3. **Industry pattern** — regex rules per industry (0.7–0.8)
4. **Generic heuristic** — cross-industry regex (0.3–0.7)
5. **Token matching** — power tokens (EBITDA, CAPEX…) + keyword overlap (0.4–0.65)

Highest-scoring candidate wins. Unclassified rows are split into
`unclassified_financial` (has financial keywords) and `non_metric` (headers/junk).

## Company IR pages

Fallback URL lists in `fiscal/companies/` were verified April 2025. If
downloads return 404s, update from the company IR pages:

- Adyen: https://www.adyen.com/en-GB/investors/reports-and-results/annual-reports
- Heineken: https://www.theheinekencompany.com/investors/reports-and-presentations/annual-reports
- SAP: https://www.sap.com/investors/en/reports.html

## Running tests

```bash
pytest
pytest -v
pytest tests/test_classifier.py
```
