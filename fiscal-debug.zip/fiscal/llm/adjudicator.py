from __future__ import annotations


def should_accept_llm(
    *,
    deterministic_metric_key: str | None,
    deterministic_score: float,
    llm_metric_key: str | None,
    llm_confidence: float,
    low_score_threshold: float = 0.60,
    llm_threshold: float = 0.80,
) -> bool:
    if not llm_metric_key:
        return False

    if deterministic_metric_key is None:
        return llm_confidence >= llm_threshold

    return deterministic_score < low_score_threshold and llm_confidence >= llm_threshold