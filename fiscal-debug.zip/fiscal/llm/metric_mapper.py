from __future__ import annotations

from fiscal.metrics_rules import METRIC_GROUPS
from .client import LLMClient
from .prompts import METRIC_MAPPER_SYSTEM_PROMPT
from .schemas import MetricMappingResult

# Canonical groups the LLM is allowed to return — excludes internal sentinel values.
_ALLOWED_GROUPS: frozenset[str] = frozenset(
    k for k in METRIC_GROUPS
    if k not in ("non_metric", "unclassified_financial", "unclassified")
)

# Pre-built string injected into the system prompt once at import time.
_CANONICAL_GROUPS_STR: str = "\n".join(
    f"  - {k}  ({METRIC_GROUPS[k]})" for k in sorted(_ALLOWED_GROUPS)
)

# Resolved system prompt (template filled once at import).
_SYSTEM_PROMPT: str = METRIC_MAPPER_SYSTEM_PROMPT.format(
    canonical_groups=_CANONICAL_GROUPS_STR
)


def map_metric_with_llm(
    *,
    raw_label: str,
    statement_type: str,
    sibling_labels: list[str] | None = None,
    company: str | None = None,
    report_year: int | None = None,
    client: LLMClient | None = None,
) -> MetricMappingResult:
    client = client or LLMClient()
    sibling_labels = sibling_labels or []

    user_prompt = f"""
Company: {company or "unknown"}
Report year: {report_year or "unknown"}
Statement type: {statement_type}

Raw label:
{raw_label}

Nearby labels:
{sibling_labels[:12]}
""".strip()

    response = client.complete_json(
        system_prompt=_SYSTEM_PROMPT,
        user_prompt=user_prompt,
        temperature=0.0,
    )

    data = response.content
    metric_group = data.get("metric_group")
    metric_key   = data.get("metric_key")

    # Reject any group not in the approved taxonomy — null both fields together
    # so the adjudicator never sees a valid group paired with an invented key.
    if metric_group is not None and metric_group not in _ALLOWED_GROUPS:
        metric_group = None
        metric_key   = None

    return MetricMappingResult(
        metric_group=metric_group,
        metric_key=metric_key,
        display_label=data.get("display_label"),
        confidence=float(data.get("confidence", 0.0) or 0.0),
        include=bool(data.get("include", True)),
        rationale=data.get("rationale"),
        raw_response=data,
    )
