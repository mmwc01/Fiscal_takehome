from __future__ import annotations

import json

from .client import LLMClient
from .prompts import PAGE_CLASSIFIER_SYSTEM_PROMPT
from .schemas import PageClassificationResult


def classify_page_with_llm(
    *,
    page_text: str,
    company: str | None = None,
    report_year: int | None = None,
    client: LLMClient | None = None,
) -> PageClassificationResult:
    client = client or LLMClient()

    user_prompt = f"""
Company: {company or "unknown"}
Report year: {report_year or "unknown"}

Page text:
{page_text[:12000]}
""".strip()

    response = client.complete_json(
        system_prompt=PAGE_CLASSIFIER_SYSTEM_PROMPT,
        user_prompt=user_prompt,
        temperature=0.0,
    )

    data = response.content
    return PageClassificationResult(
        statement_type=data.get("statement_type", "other"),
        confidence=float(data.get("confidence", 0.0)),
        evidence=list(data.get("evidence", [])),
        raw_response=data,
    )
