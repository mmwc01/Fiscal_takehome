from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class MetricMappingResult:
    metric_group: str | None
    metric_key: str | None
    display_label: str | None
    confidence: float
    include: bool = True
    rationale: str | None = None
    raw_response: dict[str, Any] = field(default_factory=dict)


@dataclass
class PageClassificationResult:
    statement_type: str
    confidence: float
    evidence: list[str] = field(default_factory=list)
    raw_response: dict[str, Any] = field(default_factory=dict)


@dataclass
class TableNormalizationRow:
    label: str
    values: dict[str, Any] = field(default_factory=dict)
    period_years: list[int] = field(default_factory=list)


@dataclass
class TableNormalizationResult:
    rows: list[TableNormalizationRow] = field(default_factory=list)
    period_years: list[int] = field(default_factory=list)
    raw_response: dict[str, Any] = field(default_factory=dict)