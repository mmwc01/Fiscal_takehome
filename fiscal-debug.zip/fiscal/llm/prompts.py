PAGE_CLASSIFIER_SYSTEM_PROMPT = """
You classify a page from an annual report PDF as a financial statement type.

Return JSON only with:
- statement_type: one of "income_statement", "balance_sheet", "cash_flow_statement", "other"
- confidence: number from 0.0 to 1.0
- evidence: list of short strings explaining the classification
""".strip()

TABLE_NORMALIZER_SYSTEM_PROMPT = """
You normalize a raw financial table extracted from a PDF into structured rows.

Return JSON only with:
- period_years: list of integer years covered by the table
- rows: list of objects each with:
  - label: canonical display label
  - values: object mapping year (as string) to numeric value or null
""".strip()

MISSING_FIELD_RECOVERY_SYSTEM_PROMPT = """
You extract specific financial values from a raw financial table.

You will receive:
1. A text representation of a financial table from an annual report
2. A list of specific metric_keys you must search for

Return JSON only with key "recovered": a list of objects, one per found value:
  - metric_key: string — MUST be one of the requested keys exactly as given
  - display_label: the label as it appears in the source table
  - value: numeric (integer or float) — required, never null or string
  - period_year: 4-digit integer year
  - confidence: float 0.0–1.0
  - evidence: exact short text snippet from the table proving the value

Rules:
- Only return metric_keys from the provided requested list. Never add your own.
- Only return values explicitly present in the table — no estimation or calculation.
- value MUST be numeric. Express costs/losses as negative numbers if shown as (123) or negative.
- Return one entry per (metric_key, period_year) pair found.
- Omit any metric you cannot find clearly in the table.
- Return {"recovered": []} if nothing is found.
- Only include entries where your confidence is at least 0.8.
""".strip()

METRIC_MAPPER_SYSTEM_PROMPT = """
You map a raw financial statement line item to a canonical metric.

Return JSON only:
- metric_group: one of the APPROVED groups listed below, or null if none fits
- metric_key: short snake_case identifier for the specific metric, or null — prefer keys already used by the deterministic classifier (e.g. net_revenue, operating_profit, total_assets, borrowings) and avoid inventing overly specific or company-specific keys
- display_label: clean human-readable label (title-case, no company jargon), or null
- confidence: 0.0–1.0
- include: true if this is a real primary-statement financial metric, false otherwise
- rationale: one-sentence explanation

APPROVED metric_group values (use only these or null):
{canonical_groups}

Rules:
- metric_group MUST be one of the approved values above, or null. Never invent a new group.
- Use statement_type to disambiguate ambiguous labels (e.g. "profit" on a cash flow statement → cash_flow_operating).
- Set include=false for non-financial rows: footnotes, headers, disclosures, ESG/sustainability rows, policy notes, contact information.
- If no approved group fits well, return null for both metric_group and metric_key (do not force a poor fit).
""".strip()