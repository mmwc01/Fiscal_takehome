"""
LLM-based missing field recovery.

After deterministic classification, some canonical financial metrics may still
be absent because the PDF layout couldn't be parsed or the label didn't match
any rule. This module asks the LLM to scan the raw table text for those specific
gaps — and ONLY those gaps. It never overwrites existing classified values.

Entry point: run_missing_field_recovery(company, conn, llm_client)
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from fiscal.llm.client import LLMClient
from fiscal.llm.prompts import MISSING_FIELD_RECOVERY_SYSTEM_PROMPT

logger = logging.getLogger(__name__)

MIN_CONFIDENCE = 0.8

# row_index sentinel used to identify synthetic raw_line_items created by this
# module so they can be cleaned up on re-runs without touching real data.
_SYNTHETIC_ROW_INDEX = -1

# Canonical fields expected for each statement type.
# Recovery only ever asks for keys absent from this list — it never invents new ones.
CANONICAL_EXPECTED_FIELDS: dict[str, list[dict[str, str]]] = {
    "income_statement": [
        {"metric_key": "net_revenue",                "metric_group": "revenue",           "display_label": "Net Revenue"},
        {"metric_key": "gross_profit",               "metric_group": "gross_profit",      "display_label": "Gross Profit"},
        {"metric_key": "operating_profit",           "metric_group": "profitability",     "display_label": "Operating Profit"},
        {"metric_key": "ebitda",                     "metric_group": "profitability",     "display_label": "EBITDA"},
        {"metric_key": "profit_before_tax",          "metric_group": "profitability",     "display_label": "Profit Before Tax"},
        {"metric_key": "net_profit",                 "metric_group": "profitability",     "display_label": "Net Profit"},
        {"metric_key": "income_tax",                 "metric_group": "tax",               "display_label": "Income Tax Expense"},
        {"metric_key": "interest_expense",           "metric_group": "profitability",     "display_label": "Interest Expense"},
        {"metric_key": "depreciation_amortization",  "metric_group": "operating_expense", "display_label": "D&A"},
    ],
    "balance_sheet": [
        {"metric_key": "total_assets",              "metric_group": "assets",      "display_label": "Total Assets"},
        {"metric_key": "cash_equivalents",          "metric_group": "assets",      "display_label": "Cash and Cash Equivalents"},
        {"metric_key": "total_liabilities",         "metric_group": "liabilities", "display_label": "Total Liabilities"},
        {"metric_key": "borrowings",                "metric_group": "liabilities", "display_label": "Borrowings"},
        {"metric_key": "total_equity",              "metric_group": "equity",      "display_label": "Total Equity"},
    ],
    "cash_flow_statement": [
        {"metric_key": "cash_flow_operations", "metric_group": "cash_flow_operating",  "display_label": "Net Cash from Operating Activities"},
        {"metric_key": "capex",                "metric_group": "cash_flow_investing",  "display_label": "Capital Expenditure"},
        {"metric_key": "cash_flow_investing",  "metric_group": "cash_flow_investing",  "display_label": "Net Cash from Investing Activities"},
        {"metric_key": "cash_flow_financing",  "metric_group": "cash_flow_financing",  "display_label": "Net Cash from Financing Activities"},
    ],
}


@dataclass
class RecoveredField:
    metric_key: str
    metric_group: str
    display_label: str
    value: float
    period_year: int
    confidence: float
    evidence: str
    raw_response: dict[str, Any] = field(default_factory=dict)


def _build_table_text(items: list[dict]) -> str:
    """Format raw_line_items into a compact table string for the LLM prompt."""
    years: list[int] = sorted(
        {r["period_year"] for r in items if r.get("period_year")},
        reverse=True,
    )[:5]

    lines: list[str] = []

    if years:
        # Pivot: label → {year → value}
        by_label: dict[str, dict[int, float]] = {}
        for row in items:
            label = (row.get("raw_label") or "").strip()
            year = row.get("period_year")
            value = row.get("parsed_value")
            if label and year and value is not None:
                by_label.setdefault(label, {})[year] = value

        header = "Label | " + " | ".join(str(y) for y in years)
        lines = [header, "-" * min(len(header), 80)]
        for label, year_vals in list(by_label.items())[:100]:
            vals = " | ".join(
                f"{year_vals[y]:g}" if y in year_vals else "—"
                for y in years
            )
            lines.append(f"{label} | {vals}")

    # Include labels that appear without year columns — common when the PDF
    # extractor splits a table and loses the header row for one section.
    labels_without_year = sorted({
        (row.get("raw_label") or "").strip()
        for row in items
        if not row.get("period_year") and (row.get("raw_label") or "").strip()
    })
    if labels_without_year:
        lines.append("")
        lines.append("Labels found without year assignment (table section without column headers):")
        for lbl in labels_without_year[:40]:
            lines.append(f"  {lbl}")

    return "\n".join(lines) if lines else "(no table data)"


def recover_missing_fields(
    *,
    statement_type: str,
    report_year: int,
    missing_fields: list[dict[str, str]],
    table_text: str,
    company: str | None = None,
    client: LLMClient | None = None,
) -> list[RecoveredField]:
    """
    Ask the LLM to find specific missing fields in the table text.

    Returns a list of RecoveredField objects with confidence >= MIN_CONFIDENCE
    and a numeric value.
    """
    client = client or LLMClient()

    field_list = "\n".join(
        f"  - {f['metric_key']}  ({f['display_label']})"
        for f in missing_fields
    )
    user_prompt = f"""
Company: {company or 'unknown'}
Report year: {report_year}
Statement: {statement_type}

Requested metric_keys to find:
{field_list}

Table content:
{table_text}
""".strip()

    response = client.complete_json(
        system_prompt=MISSING_FIELD_RECOVERY_SYSTEM_PROMPT,
        user_prompt=user_prompt,
        temperature=0.0,
    )

    raw_list = response.content.get("recovered") or []
    if not isinstance(raw_list, list):
        return []

    # Index requested fields by metric_key; keep a list in case the same key
    # appears under multiple groups (e.g. cash flow "total" variants are now
    # distinct keys, but guard anyway).
    fields_by_key: dict[str, list[dict]] = {}
    for f in missing_fields:
        fields_by_key.setdefault(f["metric_key"], []).append(f)

    results: list[RecoveredField] = []
    for item in raw_list:
        if not isinstance(item, dict):
            continue
        mk = item.get("metric_key")
        candidates = fields_by_key.get(mk)
        if not candidates:
            continue  # LLM invented a key — discard

        raw_value = item.get("value")
        if not isinstance(raw_value, (int, float)):
            continue  # non-numeric — discard

        confidence = float(item.get("confidence") or 0.0)
        if confidence < MIN_CONFIDENCE:
            continue

        period_year = item.get("period_year")
        if not isinstance(period_year, int) or period_year < 2000 or period_year > 2100:
            continue

        # Use the first matching field definition (all share the same metric_key).
        canon = candidates[0]
        results.append(
            RecoveredField(
                metric_key=mk,
                metric_group=canon["metric_group"],
                display_label=item.get("display_label") or canon["display_label"],
                value=float(raw_value),
                period_year=period_year,
                confidence=confidence,
                evidence=str(item.get("evidence") or ""),
                raw_response=item,
            )
        )

    return results


def run_missing_field_recovery(
    company: str,
    conn,
    *,
    llm_client: LLMClient,
    report_year: int | None = None,
    industry_family: str = "generic",
    max_calls: int = 20,
) -> dict[str, int]:
    """
    For each (report_year, statement_type) of `company`, find which canonical
    fields are missing from classified_metrics, call the LLM to recover them,
    and insert accepted rows back into classified_metrics.

    Returns counts: recovered, skipped, failed.
    """
    # Clean up synthetic rows from any previous recovery run for this company.
    conn.execute(
        "DELETE FROM raw_line_items WHERE company = ? AND row_index = ?",
        (company, _SYNTHETIC_ROW_INDEX),
    )

    counts = {"recovered": 0, "skipped": 0, "failed": 0, "llm_calls": 0}
    now = datetime.now(timezone.utc).isoformat()

    # Collect (report_year, statement_type) combos present in raw_line_items.
    year_filter = "AND report_year = ?" if report_year else ""
    params: list = [company]
    if report_year:
        params.append(report_year)

    combos = conn.execute(
        f"""
        SELECT DISTINCT report_year, statement_type
        FROM raw_line_items
        WHERE company = ? {year_filter}
          AND statement_type IN ('income_statement', 'balance_sheet', 'cash_flow_statement')
        ORDER BY report_year DESC, statement_type
        """,
        params,
    ).fetchall()

    for combo in combos:
        ry: int = combo[0]
        stmt: str = combo[1]
        expected = CANONICAL_EXPECTED_FIELDS.get(stmt, [])
        if not expected:
            continue

        # Which keys are already classified with real data for this combo?
        present = {
            row[0]
            for row in conn.execute(
                """
                SELECT DISTINCT metric_key
                FROM classified_metrics
                WHERE company = ?
                  AND report_year = ?
                  AND statement_type = ?
                  AND metric_key IS NOT NULL
                  AND parsed_value IS NOT NULL
                  AND period_year IS NOT NULL
                  AND classification_method != 'unclassified'
                  AND metric_group NOT IN ('non_metric', 'unclassified_financial')
                """,
                (company, ry, stmt),
            ).fetchall()
        }

        # For cash_flow_statement, "total" serves multiple groups — keep the
        # expected entry for each group independently by checking (key, group).
        present_grouped = {
            (row[0], row[1])
            for row in conn.execute(
                """
                SELECT DISTINCT metric_key, metric_group
                FROM classified_metrics
                WHERE company = ?
                  AND report_year = ?
                  AND statement_type = ?
                  AND metric_key IS NOT NULL
                  AND parsed_value IS NOT NULL
                  AND period_year IS NOT NULL
                  AND classification_method != 'unclassified'
                  AND metric_group NOT IN ('non_metric', 'unclassified_financial')
                """,
                (company, ry, stmt),
            ).fetchall()
        }

        missing = [
            f for f in expected
            if (f["metric_key"], f["metric_group"]) not in present_grouped
        ]
        if not missing:
            logger.debug("[recovery] %s %s/%s — no missing fields", company, ry, stmt)
            continue

        if counts["llm_calls"] >= max_calls:
            counts["skipped"] += len(missing)
            logger.info(
                "[recovery] %s %s/%s — skipped (%s missing, budget exhausted)",
                company, ry, stmt, len(missing),
            )
            continue

        # Fetch raw table text for this (company, report_year, statement_type).
        raw_items = conn.execute(
            """
            SELECT raw_label, parsed_value, period_year
            FROM raw_line_items
            WHERE company = ? AND report_year = ? AND statement_type = ?
              AND (row_index IS NULL OR row_index != ?)
            ORDER BY id
            """,
            (company, ry, stmt, _SYNTHETIC_ROW_INDEX),
        ).fetchall()
        raw_items = [dict(r) for r in raw_items]

        table_text = _build_table_text(raw_items)

        logger.info(
            "[recovery] %s %s/%s — requesting %s missing: %s",
            company, ry, stmt, len(missing),
            [f["metric_key"] for f in missing],
        )

        try:
            recovered = recover_missing_fields(
                statement_type=stmt,
                report_year=ry,
                missing_fields=missing,
                table_text=table_text,
                company=company,
                client=llm_client,
            )
            counts["llm_calls"] += 1
        except Exception as exc:
            logger.warning("[recovery] %s %s/%s — LLM error: %s", company, ry, stmt, exc)
            counts["failed"] += 1
            continue

        if not recovered:
            logger.info("[recovery] %s %s/%s — LLM found nothing", company, ry, stmt)
            continue

        # Find the filing and a raw_table_id to anchor synthetic rows.
        filing_row = conn.execute(
            "SELECT id FROM filings WHERE company = ? AND fiscal_year = ? LIMIT 1",
            (company, ry),
        ).fetchone()
        if not filing_row:
            logger.warning("[recovery] %s — no filing found for report_year=%s", company, ry)
            counts["skipped"] += len(recovered)
            continue
        filing_id: int = filing_row[0]

        raw_table_row = conn.execute(
            """
            SELECT id FROM raw_tables
            WHERE filing_id = ? AND statement_type = ?
            ORDER BY page_number LIMIT 1
            """,
            (filing_id, stmt),
        ).fetchone()
        if not raw_table_row:
            # Fall back to any raw_table for this filing.
            raw_table_row = conn.execute(
                "SELECT id FROM raw_tables WHERE filing_id = ? ORDER BY page_number LIMIT 1",
                (filing_id,),
            ).fetchone()
        if not raw_table_row:
            logger.warning("[recovery] %s — no raw_table found for filing_id=%s", company, filing_id)
            counts["skipped"] += len(recovered)
            continue
        raw_table_id: int = raw_table_row[0]

        for rec in recovered:
            try:
                # Insert a synthetic raw_line_item so FK is satisfied.
                cursor = conn.execute(
                    """
                    INSERT INTO raw_line_items
                        (raw_table_id, filing_id, company, report_year,
                         statement_type, raw_label, raw_value, parsed_value,
                         period_label, period_year, row_index)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        raw_table_id,
                        filing_id,
                        company,
                        ry,
                        stmt,
                        rec.evidence[:500] if rec.evidence else rec.display_label,
                        str(rec.value),
                        rec.value,
                        str(rec.period_year),
                        rec.period_year,
                        _SYNTHETIC_ROW_INDEX,
                    ),
                )
                rli_id = cursor.lastrowid

                # Insert classified_metrics row.
                conn.execute(
                    """
                    INSERT OR IGNORE INTO classified_metrics
                        (raw_line_item_id, company, report_year, statement_type,
                         raw_label, raw_value, parsed_value,
                         period_label, period_year,
                         industry_family, metric_group, metric_key,
                         display_label, classification_confidence,
                         classification_method, classification_score,
                         matched_pattern, classified_at)
                    VALUES
                        (?, ?, ?, ?, ?, ?, ?, ?, ?,
                         ?, ?, ?,
                         ?, ?,
                         ?, ?,
                         ?, ?)
                    """,
                    (
                        rli_id, company, ry, stmt,
                        rec.evidence[:500] if rec.evidence else rec.display_label,
                        str(rec.value),
                        rec.value,
                        str(rec.period_year),
                        rec.period_year,
                        industry_family,
                        rec.metric_group,
                        rec.metric_key,
                        rec.display_label,
                        "high" if rec.confidence >= 0.9 else "medium",
                        "llm_recovered",
                        rec.confidence,
                        "llm_recovery",
                        now,
                    ),
                )
                counts["recovered"] += 1
                logger.info(
                    "[recovery] %s %s/%s — recovered %s/%s period_year=%s conf=%.2f",
                    company, ry, stmt,
                    rec.metric_group, rec.metric_key,
                    rec.period_year, rec.confidence,
                )
            except Exception as exc:
                logger.warning(
                    "[recovery] %s — insert failed for %s/%s: %s",
                    company, rec.metric_group, rec.metric_key, exc,
                )
                counts["failed"] += 1

    logger.info(
        "[recovery] %s: recovered=%s skipped=%s failed=%s llm_calls=%s",
        company,
        counts["recovered"],
        counts["skipped"],
        counts["failed"],
        counts["llm_calls"],
    )
    return counts
