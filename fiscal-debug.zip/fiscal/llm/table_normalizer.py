from __future__ import annotations

from .client import LLMClient
from .prompts import TABLE_NORMALIZER_SYSTEM_PROMPT
from .schemas import TableNormalizationResult, TableNormalizationRow


def normalize_table_with_llm(
    *,
    raw_table: list[list[str]],
    page_text: str,
    statement_type: str,
    company: str | None = None,
    report_year: int | None = None,
    client: LLMClient | None = None,
) -> TableNormalizationResult:
    client = client or LLMClient()

    user_prompt = f"""
Company: {company or "unknown"}
Report year: {report_year or "unknown"}
Statement type: {statement_type}

Raw table:
{raw_table[:100]}

Page text excerpt:
{page_text[:8000]}
""".strip()

    response = client.complete_json(
        system_prompt=TABLE_NORMALIZER_SYSTEM_PROMPT,
        user_prompt=user_prompt,
        temperature=0.0,
    )

    data = response.content
    rows = [
        TableNormalizationRow(
            label=row.get("label", ""),
            values_by_period=dict(row.get("values_by_period", {})),
        )
        for row in data.get("rows", [])
        if isinstance(row, dict)
    ]

    return TableNormalizationResult(
        rows=rows,
        confidence=float(data.get("confidence", 0.0)),
        notes=list(data.get("notes", [])),
        raw_response=data,
    )
