"""
Discovery pipeline: runs per-company adapters, classifies results, writes to DB.

Called by `fiscal discover`. For each target company:
  1. Calls company.discover_filings(session) — scraper or fallback
  2. Classifies each candidate with classification.classify_filing()
  3. Falls back to adapter-provided fiscal_year if classifier couldn't infer one
  4. Upserts to filings table (duplicate URLs are silently skipped)
"""
import logging
from datetime import datetime, timezone
from types import ModuleType
from typing import Optional

import requests

from fiscal import classification, db
from fiscal.companies import REGISTRY

logger = logging.getLogger(__name__)


def run_discovery(
    company: Optional[str] = None,
    db_path=None,
) -> dict[str, int]:
    """
    Discover and classify filings for all companies (or one if specified).

    Returns {company_key: new_filing_count}.
    """
    db_path = db_path or db.DB_PATH
    targets = _resolve_targets(company)
    session = _make_session()
    results: dict[str, int] = {}

    with db.get_connection(db_path) as conn:
        for module in targets:
            logger.info(f"[{module.KEY}] Starting discovery from {module.IR_URL}")
            if hasattr(module, "prepare_session"):
                module.prepare_session(session)
            candidates = module.discover_filings(session)
            new_count = _process_candidates(conn, module, candidates)
            logger.info(
                f"[{module.KEY}] Done: {new_count} new filing(s) "
                f"(of {len(candidates)} candidate(s))"
            )
            results[module.KEY] = new_count

    return results


def _process_candidates(
    conn,
    module: ModuleType,
    candidates: list[dict],
) -> int:
    """Classify and upsert candidates for one company. Returns count of new rows."""
    new_count = 0
    for candidate in candidates:
        title = candidate.get("title", "")
        url = candidate["url"]

        doc_type, inferred_year = classification.classify_filing(title, url)

        # Adapter-supplied fiscal_year is more reliable than text inference
        # (the adapter already knows the year from page metadata or URL structure)
        fiscal_year = candidate.get("fiscal_year") or inferred_year

        filing_data = {
            "company":       module.KEY,
            "title":         title,
            "url":           url,
            "document_type": doc_type,
            "fiscal_year":   fiscal_year,
            "status":        "classified",
            "discovered_at": datetime.now(timezone.utc).isoformat(),
        }

        inserted = db.upsert_filing(conn, filing_data)
        if inserted:
            new_count += 1
            logger.debug(
                f"[{module.KEY}] + {doc_type:<16} fy={fiscal_year or '?':>4}  {title!r}"
            )
        else:
            logger.debug(f"[{module.KEY}] ~ skip (duplicate URL): {url}")

    return new_count


def _resolve_targets(company: Optional[str]) -> list[ModuleType]:
    """Return list of company modules to process. Raises ValueError on unknown key."""
    if company is None:
        return list(REGISTRY.values())
    if company not in REGISTRY:
        raise ValueError(
            f"Unknown company key {company!r}. "
            f"Valid options: {', '.join(sorted(REGISTRY))}"
        )
    return [REGISTRY[company]]


def _make_session() -> requests.Session:
    """Create a requests Session with a descriptive User-Agent."""
    session = requests.Session()
    session.headers.update({
        "User-Agent": (
            "fiscal/0.1 financial-research-tool "
            "(educational use; contact: see project README)"
        )
    })
    return session
