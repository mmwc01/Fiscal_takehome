"""
Database connection management and schema initialization.

All pipeline stages share data/fiscal.db. Use get_connection() as a context
manager for all read/write operations — it auto-commits on success and
rolls back on any exception.

Tables
------
filings            — one row per discovered filing URL
raw_tables         — exact pdfplumber output per PDF page, stored before normalization
raw_line_items     — one row per (label, period) pair extracted from a raw_table
classified_metrics — metric classifications produced by classify_metrics.py
compiled_views     — aggregated 10-year view, rebuilt by build-views command

Debuggability note
------------------
raw_tables stores the raw 2D cell arrays as JSON. You can inspect them directly
in any SQLite browser to debug extraction without re-parsing PDFs:

    SELECT page_number, table_index, statement_type, num_rows, num_cols, raw_data
    FROM raw_tables WHERE filing_id = ?;
"""
import json
import logging
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Generator

logger = logging.getLogger(__name__)

DB_PATH = Path("data/fiscal.db")

# ---------------------------------------------------------------------------
# Schema
# ---------------------------------------------------------------------------

_SCHEMA = """
CREATE TABLE IF NOT EXISTS filings (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    company          TEXT NOT NULL,
    title            TEXT,
    url              TEXT NOT NULL,
    document_type    TEXT NOT NULL DEFAULT 'unknown',
    fiscal_year      INTEGER,
    local_path       TEXT,
    file_size_bytes  INTEGER,
    sha256           TEXT,
    status           TEXT NOT NULL DEFAULT 'discovered',
    extraction_error TEXT,
    discovered_at    TEXT NOT NULL,
    downloaded_at    TEXT,
    extracted_at     TEXT,
    metadata         TEXT NOT NULL DEFAULT '{}'
);
CREATE UNIQUE INDEX IF NOT EXISTS uix_filings_url ON filings(url);

-- Exact pdfplumber output per page, stored as JSON before any normalization.
-- Each row is one table extracted from one page of one filing.
CREATE TABLE IF NOT EXISTS raw_tables (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    filing_id        INTEGER NOT NULL REFERENCES filings(id),
    page_number      INTEGER NOT NULL,
    table_index      INTEGER NOT NULL,
    raw_data         TEXT NOT NULL,    -- JSON: list[list[str | null]]
    num_rows         INTEGER NOT NULL,
    num_cols         INTEGER NOT NULL,
    statement_type   TEXT,             -- assigned by statement_detector; null = unknown
    detection_reason TEXT,             -- why this page was selected for extraction
    extracted_at     TEXT NOT NULL
);

-- One row per (label, period) pair produced by cleaning a raw_table.
-- raw_label and raw_value are never modified after insertion.
CREATE TABLE IF NOT EXISTS raw_line_items (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    raw_table_id    INTEGER NOT NULL REFERENCES raw_tables(id),
    filing_id       INTEGER NOT NULL REFERENCES filings(id),
    company         TEXT NOT NULL,
    report_year     INTEGER NOT NULL,  -- fiscal_year of the source filing
    statement_type  TEXT NOT NULL,
    raw_label       TEXT NOT NULL,     -- exact extracted text, never modified
    raw_value       TEXT NOT NULL,     -- exact extracted text, never modified
    parsed_value    REAL,
    period_label    TEXT NOT NULL,     -- column header as extracted ("2022", "FY 2022", etc.)
    period_year     INTEGER,           -- 4-digit year parsed from period_label
    unit            TEXT,              -- "millions" | "thousands" | null
    currency        TEXT,              -- "EUR" | "USD" | null
    page_number     INTEGER,
    table_index     INTEGER,
    row_index       INTEGER,
    col_index       INTEGER,
    -- Reserved for bonus phase; NULL in base version:
    canonical_label TEXT,
    is_restated     INTEGER NOT NULL DEFAULT 0,
    preferred       INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_rli_lookup
    ON raw_line_items(company, statement_type, period_year);
CREATE INDEX IF NOT EXISTS idx_rli_filing
    ON raw_line_items(filing_id);

-- LLM-assigned canonical label mappings.
-- Maps raw extracted labels to clean, deduplicated, ordered canonical names.
-- Populated by the canonicalize command; survives build-views reruns.
CREATE TABLE IF NOT EXISTS label_mappings (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    company          TEXT NOT NULL,
    statement_type   TEXT NOT NULL,
    raw_label        TEXT NOT NULL,
    canonical_label  TEXT NOT NULL,
    sort_order       INTEGER NOT NULL DEFAULT 999,
    include          INTEGER NOT NULL DEFAULT 1,  -- 0 = exclude from export
    created_at       TEXT NOT NULL,
    UNIQUE(company, statement_type, raw_label)
);

-- Combined view: all three statements per company in one table, with
-- canonical labels applied. Rebuilt by build-combined command.
-- statement_order: 1=income_statement, 2=balance_sheet, 3=cash_flow_statement
CREATE TABLE IF NOT EXISTS combined_views (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    company          TEXT NOT NULL,
    statement_type   TEXT NOT NULL,
    statement_order  INTEGER NOT NULL,
    canonical_label  TEXT NOT NULL,
    sort_order       INTEGER NOT NULL DEFAULT 999,
    period_year      INTEGER NOT NULL,
    value            REAL,
    built_at         TEXT NOT NULL,
    UNIQUE(company, statement_type, canonical_label, period_year)
);
CREATE INDEX IF NOT EXISTS idx_cv_lookup
    ON combined_views(company, statement_type);

-- Rules-based metric classifications produced by classify_metrics.py.
-- One row per raw_line_item; re-populated on every classify-metrics run.
-- Raw data is never modified here — this table only adds metadata.
CREATE TABLE IF NOT EXISTS classified_metrics (
    id                         INTEGER PRIMARY KEY AUTOINCREMENT,
    raw_line_item_id           INTEGER NOT NULL REFERENCES raw_line_items(id),
    -- Copied from raw_line_items for query convenience (no join required)
    company                    TEXT    NOT NULL,
    report_year                INTEGER,
    statement_type             TEXT    NOT NULL,
    raw_label                  TEXT    NOT NULL,
    raw_value                  TEXT,
    parsed_value               REAL,
    period_label               TEXT,
    period_year                INTEGER,
    page_number                INTEGER,
    -- Classification fields
    industry_family            TEXT,   -- beverage | software | payments | generic | …
    metric_group               TEXT,   -- revenue | profitability | assets | …
    metric_key                 TEXT,   -- e.g. "revenue.net_revenue"
    display_label              TEXT,   -- standardised human-readable label
    classification_confidence  TEXT    DEFAULT 'low',   -- high | medium | low
    classification_method      TEXT    DEFAULT 'unclassified',  -- company_rule | industry_exact_rule |
                                                                --   industry_pattern_rule | generic_heuristic |
                                                                --   unclassified
    classification_score       REAL    DEFAULT 0.0,   -- numeric score that drove classification
    matched_pattern            TEXT    DEFAULT '',    -- rule/pattern that matched (for debugging)
    classified_at              TEXT,
    UNIQUE(raw_line_item_id)   -- one classification per source row
);
CREATE INDEX IF NOT EXISTS idx_cm_lookup
    ON classified_metrics(company, statement_type, metric_key, period_year);
CREATE INDEX IF NOT EXISTS idx_cm_company
    ON classified_metrics(company);

-- Aggregated 10-year view, deterministically rebuilt by build-views.
-- Selection rule (base): prefer report_year == period_year; fallback to
-- earliest report_year > period_year. See view_builder.py for full comment.
CREATE TABLE IF NOT EXISTS compiled_views (
    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    company            TEXT NOT NULL,
    statement_type     TEXT NOT NULL,
    label              TEXT NOT NULL,
    period_year        INTEGER NOT NULL,
    value              REAL,
    unit               TEXT,
    currency           TEXT,
    source_report_year INTEGER,
    source_filing_id   INTEGER REFERENCES filings(id),
    built_at           TEXT NOT NULL,
    UNIQUE(company, statement_type, label, period_year)
);
"""


# ---------------------------------------------------------------------------
# Connection management
# ---------------------------------------------------------------------------

@contextmanager
def get_connection(path: Path = DB_PATH) -> Generator[sqlite3.Connection, None, None]:
    """
    Context manager for all DB access. Commits on success, rolls back on exception.

    Usage:
        with db.get_connection() as conn:
            db.upsert_filing(conn, {...})
            # auto-commits when the with block exits cleanly
    """
    conn = sqlite3.connect(str(path))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def _migrate_classified_metrics(conn: sqlite3.Connection) -> None:
    """
    Add columns that were introduced after the initial classified_metrics schema.
    ALTER TABLE is only executed when the column is absent — safe to call repeatedly.
    """
    try:
        existing = {row[1] for row in conn.execute("PRAGMA table_info(classified_metrics)")}
    except Exception:
        return  # table doesn't exist yet; CREATE TABLE will handle it
    for col, defn in [
        ("classification_score", "REAL DEFAULT 0.0"),
        ("matched_pattern",      "TEXT DEFAULT ''"),
    ]:
        if col not in existing:
            conn.execute(f"ALTER TABLE classified_metrics ADD COLUMN {col} {defn}")


def init_db(path: Path = DB_PATH) -> None:
    """
    Create database file and all tables. Safe to call multiple times (idempotent).
    Creates parent directories if they don't exist.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(path))
    try:
        conn.executescript(_SCHEMA)
        _migrate_classified_metrics(conn)
        conn.commit()
    finally:
        conn.close()
    logger.info(f"Database ready at {path}")


# ---------------------------------------------------------------------------
# Filing helpers
# ---------------------------------------------------------------------------

def upsert_filing(conn: sqlite3.Connection, data: dict) -> bool:
    """
    Insert a filing if its URL is not already in the database.

    Returns True if a new row was inserted, False if skipped (duplicate URL).
    Caller is responsible for committing (handled by get_connection context manager).
    """
    existing = conn.execute(
        "SELECT id FROM filings WHERE url = ?", (data["url"],)
    ).fetchone()
    if existing:
        return False

    conn.execute(
        """
        INSERT INTO filings
            (company, title, url, document_type, fiscal_year,
             status, discovered_at, metadata)
        VALUES
            (:company, :title, :url, :document_type, :fiscal_year,
             :status, :discovered_at, :metadata)
        """,
        {
            "company":       data["company"],
            "title":         data.get("title"),
            "url":           data["url"],
            "document_type": data.get("document_type", "unknown"),
            "fiscal_year":   data.get("fiscal_year"),
            "status":        data.get("status", "classified"),
            "discovered_at": data.get("discovered_at", _utcnow()),
            "metadata":      json.dumps(data.get("metadata", {})),
        },
    )
    return True


def get_filings(
    conn: sqlite3.Connection,
    company: str | None = None,
    status: str | None = None,
    document_type: str | None = None,
) -> list[dict]:
    """Fetch filings with optional filters. Returns list of plain dicts."""
    clauses = ["1=1"]
    params: list = []
    if company:
        clauses.append("company = ?")
        params.append(company)
    if status:
        clauses.append("status = ?")
        params.append(status)
    if document_type:
        clauses.append("document_type = ?")
        params.append(document_type)

    rows = conn.execute(
        f"SELECT * FROM filings WHERE {' AND '.join(clauses)} "
        f"ORDER BY company, fiscal_year DESC",
        params,
    ).fetchall()
    return [dict(r) for r in rows]


def update_filing(conn: sqlite3.Connection, filing_id: int, **fields) -> None:
    """Update arbitrary columns on a single filing row."""
    if not fields:
        return
    set_clause = ", ".join(f"{k} = ?" for k in fields)
    values = list(fields.values()) + [filing_id]
    conn.execute(f"UPDATE filings SET {set_clause} WHERE id = ?", values)


# ---------------------------------------------------------------------------
# Status / reporting helpers
# ---------------------------------------------------------------------------

def get_status_summary(conn: sqlite3.Connection) -> list[dict]:
    """Per-company filing counts used by `fiscal status`."""
    rows = conn.execute(
        """
        SELECT
            company,
            COUNT(*)                                                              AS total_filings,
            SUM(CASE WHEN document_type = 'annual_report'                 THEN 1 END) AS annual_reports,
            SUM(CASE WHEN status IN ('downloaded','extracted','extraction_failed') THEN 1 END)
                                                                                  AS downloaded,
            SUM(CASE WHEN status = 'extracted'                            THEN 1 END) AS extracted,
            SUM(CASE WHEN status = 'extraction_failed'                    THEN 1 END) AS failed
        FROM filings
        GROUP BY company
        ORDER BY company
        """
    ).fetchall()
    return [dict(r) for r in rows]


def get_aggregate_counts(conn: sqlite3.Connection) -> dict:
    """Total row counts for the derived tables."""
    # classified_metrics table may not exist in older databases
    try:
        classified = conn.execute("SELECT COUNT(*) FROM classified_metrics").fetchone()[0]
    except Exception:
        classified = 0
    return {
        "raw_tables":          conn.execute("SELECT COUNT(*) FROM raw_tables").fetchone()[0],
        "raw_line_items":      conn.execute("SELECT COUNT(*) FROM raw_line_items").fetchone()[0],
        "classified_metrics":  classified,
        "compiled_views":      conn.execute("SELECT COUNT(*) FROM compiled_views").fetchone()[0],
        "combined_views":      conn.execute("SELECT COUNT(*) FROM combined_views").fetchone()[0],
    }


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


# ---------------------------------------------------------------------------
# Raw table helpers
# ---------------------------------------------------------------------------

def get_filing_by_id(conn: sqlite3.Connection, filing_id: int) -> dict | None:
    """Fetch a single filing row by primary key. Returns None if not found."""
    row = conn.execute(
        "SELECT * FROM filings WHERE id = ?", (filing_id,)
    ).fetchone()
    return dict(row) if row else None


def insert_raw_table(conn: sqlite3.Connection, data: dict) -> int:
    """
    Insert one raw_table row. Returns the new row id.
    data must contain: filing_id, page_number, table_index, raw_data,
                       num_rows, num_cols, statement_type, detection_reason,
                       extracted_at.
    """
    cursor = conn.execute(
        """
        INSERT INTO raw_tables
            (filing_id, page_number, table_index, raw_data,
             num_rows, num_cols, statement_type, detection_reason, extracted_at)
        VALUES
            (:filing_id, :page_number, :table_index, :raw_data,
             :num_rows, :num_cols, :statement_type, :detection_reason, :extracted_at)
        """,
        data,
    )
    return cursor.lastrowid


# ---------------------------------------------------------------------------
# Label mapping helpers
# ---------------------------------------------------------------------------

def upsert_label_mapping(conn: sqlite3.Connection, data: dict) -> None:
    """Insert or replace a label mapping row."""
    conn.execute(
        """
        INSERT INTO label_mappings
            (company, statement_type, raw_label, canonical_label,
             sort_order, include, created_at)
        VALUES
            (:company, :statement_type, :raw_label, :canonical_label,
             :sort_order, :include, :created_at)
        ON CONFLICT(company, statement_type, raw_label) DO UPDATE SET
            canonical_label = excluded.canonical_label,
            sort_order      = excluded.sort_order,
            include         = excluded.include,
            created_at      = excluded.created_at
        """,
        data,
    )


def get_label_mappings(
    conn: sqlite3.Connection,
    company: str,
    statement_type: str,
) -> dict[str, dict]:
    """
    Return {raw_label: {canonical_label, sort_order, include}} for one
    (company, statement_type) pair.
    """
    rows = conn.execute(
        """
        SELECT raw_label, canonical_label, sort_order, include
        FROM label_mappings
        WHERE company = ? AND statement_type = ?
        """,
        (company, statement_type),
    ).fetchall()
    return {
        r["raw_label"]: {
            "canonical_label": r["canonical_label"],
            "sort_order":      r["sort_order"],
            "include":         bool(r["include"]),
        }
        for r in rows
    }


def upsert_combined_view(conn: sqlite3.Connection, data: dict) -> None:
    """Insert or replace a combined_view row."""
    conn.execute(
        """
        INSERT INTO combined_views
            (company, statement_type, statement_order, canonical_label,
             sort_order, period_year, value, built_at)
        VALUES
            (:company, :statement_type, :statement_order, :canonical_label,
             :sort_order, :period_year, :value, :built_at)
        ON CONFLICT(company, statement_type, canonical_label, period_year) DO UPDATE SET
            statement_order = excluded.statement_order,
            sort_order      = excluded.sort_order,
            value           = excluded.value,
            built_at        = excluded.built_at
        """,
        data,
    )


def get_combined_views(
    conn: sqlite3.Connection,
    company: str | None = None,
) -> list[dict]:
    """
    Return combined_views rows ordered for display:
    company → statement_order → sort_order → canonical_label → period_year.
    """
    sql = (
        "SELECT company, statement_type, statement_order, canonical_label, "
        "sort_order, period_year, value "
        "FROM combined_views "
    )
    params: list = []
    if company:
        sql += "WHERE company = ? "
        params.append(company)
    sql += "ORDER BY company, statement_order, sort_order, canonical_label, period_year"
    return [dict(r) for r in conn.execute(sql, params).fetchall()]


def get_raw_tables(conn: sqlite3.Connection, filing_id: int) -> list[dict]:
    """Return all raw_table rows for a given filing, ordered by page and table index."""
    rows = conn.execute(
        "SELECT * FROM raw_tables WHERE filing_id = ? ORDER BY page_number, table_index",
        (filing_id,),
    ).fetchall()
    return [dict(r) for r in rows]


def delete_raw_tables_for_filing(conn: sqlite3.Connection, filing_id: int) -> None:
    """Delete all raw_tables (and cascading raw_line_items) for a filing.
    Used when --filing-id forces a re-extraction run."""
    conn.execute(
        "DELETE FROM raw_line_items WHERE filing_id = ?", (filing_id,)
    )
    conn.execute(
        "DELETE FROM raw_tables WHERE filing_id = ?", (filing_id,)
    )


# ---------------------------------------------------------------------------
# Classified metrics helpers
# ---------------------------------------------------------------------------

def upsert_classified_metric(conn: sqlite3.Connection, data: dict) -> int:
    """
    Insert or replace a classified_metrics row (keyed on raw_line_item_id).

    Required keys: raw_line_item_id, company, statement_type, raw_label,
                   metric_group, metric_key, display_label,
                   classification_confidence, classification_method.
    Optional keys: report_year, raw_value, parsed_value, period_label,
                   period_year, page_number, industry_family,
                   classification_score, matched_pattern, classified_at.
    """
    cursor = conn.execute(
        """
        INSERT INTO classified_metrics
            (raw_line_item_id, company, report_year, statement_type,
             raw_label, raw_value, parsed_value, period_label, period_year,
             page_number, industry_family, metric_group, metric_key,
             display_label, classification_confidence, classification_method,
             classification_score, matched_pattern, classified_at)
        VALUES
            (:raw_line_item_id, :company, :report_year, :statement_type,
             :raw_label, :raw_value, :parsed_value, :period_label, :period_year,
             :page_number, :industry_family, :metric_group, :metric_key,
             :display_label, :classification_confidence, :classification_method,
             :classification_score, :matched_pattern, :classified_at)
        ON CONFLICT(raw_line_item_id) DO UPDATE SET
            metric_group              = excluded.metric_group,
            metric_key                = excluded.metric_key,
            display_label             = excluded.display_label,
            industry_family           = excluded.industry_family,
            classification_confidence = excluded.classification_confidence,
            classification_method     = excluded.classification_method,
            classification_score      = excluded.classification_score,
            matched_pattern           = excluded.matched_pattern,
            classified_at             = excluded.classified_at
        """,
        {
            "raw_line_item_id":          data["raw_line_item_id"],
            "company":                   data["company"],
            "report_year":               data.get("report_year"),
            "statement_type":            data["statement_type"],
            "raw_label":                 data["raw_label"],
            "raw_value":                 data.get("raw_value"),
            "parsed_value":              data.get("parsed_value"),
            "period_label":              data.get("period_label"),
            "period_year":               data.get("period_year"),
            "page_number":               data.get("page_number"),
            "industry_family":           data.get("industry_family"),
            "metric_group":              data["metric_group"],
            "metric_key":                data["metric_key"],
            "display_label":             data["display_label"],
            "classification_confidence": data.get("classification_confidence", "low"),
            "classification_method":     data.get("classification_method", "unclassified"),
            "classification_score":      data.get("classification_score", 0.0),
            "matched_pattern":           data.get("matched_pattern", ""),
            "classified_at":             data.get("classified_at", _utcnow()),
        },
    )
    return cursor.lastrowid


def delete_classified_metrics_for_company(conn: sqlite3.Connection, company: str) -> None:
    """Delete all classified_metrics rows for a company. Used before re-classifying."""
    conn.execute("DELETE FROM classified_metrics WHERE company = ?", (company,))


def get_classified_metrics(
    conn: sqlite3.Connection,
    company: str | None = None,
    statement_type: str | None = None,
    method: str | None = None,
) -> list[dict]:
    """
    Fetch classified_metrics rows with optional filters.

    Args:
        company:        Filter to one company.
        statement_type: Filter to one statement type.
        method:         Filter by classification_method (e.g. "unclassified").
    """
    clauses = ["1=1"]
    params: list = []
    if company:
        clauses.append("company = ?")
        params.append(company)
    if statement_type:
        clauses.append("statement_type = ?")
        params.append(statement_type)
    if method:
        clauses.append("classification_method = ?")
        params.append(method)
    sql = (
        f"SELECT * FROM classified_metrics WHERE {' AND '.join(clauses)} "
        "ORDER BY company, statement_type, metric_group, metric_key, period_year"
    )
    return [dict(r) for r in conn.execute(sql, params).fetchall()]


def insert_raw_line_item(conn: sqlite3.Connection, data: dict) -> int:
    """
    Insert one raw_line_item row. Returns the new row id.
    Required keys: raw_table_id, filing_id, company, report_year,
                   statement_type, raw_label, raw_value, period_label.
    Optional keys: parsed_value, period_year, page_number, table_index,
                   row_index, col_index.
    """
    cursor = conn.execute(
        """
        INSERT INTO raw_line_items
            (raw_table_id, filing_id, company, report_year,
             statement_type, raw_label, raw_value, parsed_value,
             period_label, period_year,
             page_number, table_index, row_index, col_index)
        VALUES
            (:raw_table_id, :filing_id, :company, :report_year,
             :statement_type, :raw_label, :raw_value, :parsed_value,
             :period_label, :period_year,
             :page_number, :table_index, :row_index, :col_index)
        """,
        {
            "raw_table_id":   data["raw_table_id"],
            "filing_id":      data["filing_id"],
            "company":        data["company"],
            "report_year":    data["report_year"],
            "statement_type": data["statement_type"],
            "raw_label":      data["raw_label"],
            "raw_value":      data["raw_value"],
            "parsed_value":   data.get("parsed_value"),
            "period_label":   data["period_label"],
            "period_year":    data.get("period_year"),
            "page_number":    data.get("page_number"),
            "table_index":    data.get("table_index"),
            "row_index":      data.get("row_index"),
            "col_index":      data.get("col_index"),
        },
    )
    return cursor.lastrowid
