"""
Pydantic models for in-memory validation at DB write boundaries.

These are not an ORM. DB reads return plain dicts via sqlite3.Row.
These models validate data before it is written to the database,
making schema violations surface as Python errors rather than SQL errors.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from pydantic import BaseModel, Field, field_validator

_VALID_DOC_TYPES = frozenset({
    "annual_report", "interim_report", "quarterly",
    "sustainability", "other", "unknown",
})
_VALID_STATUSES = frozenset({
    "discovered", "classified", "downloaded",
    "extracted", "extraction_failed",
})


def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


class Filing(BaseModel):
    """One discovered filing entry (corresponds to filings table)."""
    company: str
    title: str | None = None
    url: str
    document_type: str = "unknown"
    fiscal_year: int | None = None
    local_path: str | None = None
    file_size_bytes: int | None = None
    sha256: str | None = None
    status: str = "discovered"
    extraction_error: str | None = None
    discovered_at: str = Field(default_factory=_utcnow)
    downloaded_at: str | None = None
    extracted_at: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)

    @field_validator("document_type")
    @classmethod
    def valid_document_type(cls, v: str) -> str:
        if v not in _VALID_DOC_TYPES:
            raise ValueError(f"document_type must be one of {_VALID_DOC_TYPES}, got {v!r}")
        return v

    @field_validator("status")
    @classmethod
    def valid_status(cls, v: str) -> str:
        if v not in _VALID_STATUSES:
            raise ValueError(f"status must be one of {_VALID_STATUSES}, got {v!r}")
        return v


class RawTable(BaseModel):
    """
    A table extracted from one PDF page by pdfplumber (raw_tables table).

    raw_data is the exact list-of-lists output from pdfplumber.extract_tables(),
    serialized as JSON. It is never modified after insertion.
    """
    filing_id: int
    page_number: int
    table_index: int                      # 0-indexed within the page
    raw_data: list[list[str | None]]      # exact pdfplumber output
    num_rows: int
    num_cols: int
    statement_type: str | None = None
    detection_reason: str | None = None
    extracted_at: str = Field(default_factory=_utcnow)

    @property
    def shape(self) -> str:
        return f"{self.num_rows}×{self.num_cols}"


class RawLineItem(BaseModel):
    """
    A single (label, period) data point from a cleaned RawTable (raw_line_items table).

    raw_label and raw_value are the exact strings from the PDF cell.
    They are never modified after insertion — normalization lives in canonical_label.
    """
    raw_table_id: int
    filing_id: int
    company: str
    report_year: int                      # fiscal_year of the source Annual Report
    statement_type: str
    raw_label: str                        # exact cell text — never changed
    raw_value: str                        # exact cell text — never changed
    parsed_value: float | None = None
    period_label: str                     # column header as extracted
    period_year: int | None = None        # 4-digit year from period_label
    unit: str | None = None
    currency: str | None = None
    page_number: int | None = None
    table_index: int | None = None
    row_index: int | None = None
    col_index: int | None = None
    # Reserved for bonus phase — NULL in base version:
    canonical_label: str | None = None
    is_restated: int = 0
    preferred: int = 0


class CompiledRow(BaseModel):
    """
    One cell in the compiled 10-year view (compiled_views table).

    Base selection rule:
      For each (company, statement_type, label, period_year), prefer the value
      from the report where report_year == period_year (home-year report).
      Fallback: use the earliest report where report_year > period_year.
      Tie-break: MAX(raw_line_items.id) — last inserted wins.
    """
    company: str
    statement_type: str
    label: str
    period_year: int
    value: float | None = None
    unit: str | None = None
    currency: str | None = None
    source_report_year: int | None = None
    source_filing_id: int | None = None
    built_at: str = Field(default_factory=_utcnow)
