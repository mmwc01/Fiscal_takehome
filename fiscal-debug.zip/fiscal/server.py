"""
Flask web server. Exposes a single-page UI with per-company buttons that run
the pipeline and return a PDF for that company.

Start with: fiscal serve [--port 8080]
"""
import logging
from pathlib import Path

from flask import Flask, jsonify, render_template_string, request, send_file

from fiscal import classify_metrics as classifier
from fiscal import db
from fiscal import discovery
from fiscal import download as downloader
from fiscal import view_builder
from fiscal import exporter as csv_exporter
from fiscal.extraction import pipeline as extractor
from fiscal.extraction.table_cleaner import run_clean_all
from fiscal.pdf_exporter import run_export_pdf

logger = logging.getLogger(__name__)

_PROJECT_ROOT = Path(__file__).resolve().parent.parent
_OUTPUT_DIR   = str(_PROJECT_ROOT / "output")

COMPANIES = ["adyen", "heineken", "sap"]

app = Flask(__name__)

_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Fiscal Pipeline</title>
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto,
                   Helvetica, Arial, sans-serif;
      background: #F4F6F9;
      color: #1A1A2E;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 32px;
      padding: 40px 20px;
    }

    .card {
      background: #fff;
      border-radius: 12px;
      box-shadow: 0 2px 16px rgba(0,0,0,0.08);
      padding: 40px 48px;
      width: 100%;
      max-width: 560px;
      text-align: center;
    }

    h1 {
      font-size: 1.6rem;
      font-weight: 700;
      margin-bottom: 8px;
      color: #1A1A2E;
    }

    .subtitle {
      font-size: 0.9rem;
      color: #666;
      margin-bottom: 32px;
      line-height: 1.5;
    }

    .btn-group {
      display: flex;
      flex-direction: column;
      gap: 12px;
    }

    .run-btn {
      background: #4338CA;
      color: #fff;
      border: none;
      border-radius: 8px;
      font-size: 1rem;
      font-weight: 600;
      padding: 14px 36px;
      cursor: pointer;
      transition: background 0.15s, transform 0.1s;
      width: 100%;
    }
    .run-btn:hover:not(:disabled) { background: #3730A3; }
    .run-btn:active:not(:disabled) { transform: scale(0.98); }
    .run-btn:disabled { background: #A5B4FC; cursor: not-allowed; }

    #status {
      margin-top: 20px;
      font-size: 0.85rem;
      color: #555;
      min-height: 22px;
      line-height: 1.5;
    }

    .success { color: #059669; font-weight: 600; }
    .error   { color: #DC2626; font-weight: 600; }

    .spinner {
      display: inline-block;
      width: 14px; height: 14px;
      border: 2px solid #A5B4FC;
      border-top-color: #4338CA;
      border-radius: 50%;
      animation: spin 0.7s linear infinite;
      vertical-align: middle;
      margin-right: 6px;
    }
    @keyframes spin { to { transform: rotate(360deg); } }
  </style>
</head>
<body>
  <div class="card">
    <h1>Fiscal Pipeline</h1>
    <p class="subtitle">
      Select a company to run the pipeline and download its PDF report.
    </p>

    <div class="btn-group">
      <button class="run-btn" onclick="runPipeline('adyen',    this)">Adyen — Download PDF</button>
      <button class="run-btn" onclick="runPipeline('heineken', this)">Heineken — Download PDF</button>
      <button class="run-btn" onclick="runPipeline('sap',      this)">SAP — Download PDF</button>
    </div>

    <div id="status"></div>
  </div>

  <script>
    async function runPipeline(company, btn) {
      const allBtns = document.querySelectorAll('.run-btn');
      const status  = document.getElementById('status');

      allBtns.forEach(b => b.disabled = true);
      const label = company.charAt(0).toUpperCase() + company.slice(1);
      status.innerHTML = '<span class="spinner"></span> Running pipeline for '
                       + label + '… (this may take a minute)';

      try {
        const resp = await fetch('/run', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ company }),
        });

        if (!resp.ok) {
          const err = await resp.json().catch(() => ({ error: resp.statusText }));
          status.innerHTML = '<span class="error">Pipeline failed.</span> '
                           + (err.error || resp.statusText);
          return;
        }

        const blob = await resp.blob();
        const url  = URL.createObjectURL(blob);
        const a    = document.createElement('a');
        a.href     = url;
        a.download = resp.headers.get('X-Filename') || company + '_report.pdf';
        document.body.appendChild(a);
        a.click();
        a.remove();
        URL.revokeObjectURL(url);

        const clsfd = resp.headers.get('X-Classified')   || '?';
        const rows  = resp.headers.get('X-Rows-Written') || '?';
        status.innerHTML = '<span class="success">Done!</span> '
                         + clsfd + ' metrics classified · '
                         + rows  + ' view rows · PDF downloaded.';

      } catch (e) {
        status.innerHTML = '<span class="error">Network error:</span> ' + e.message;
      } finally {
        allBtns.forEach(b => b.disabled = false);
      }
    }
  </script>
</body>
</html>
"""


@app.get("/")
def index():
    return render_template_string(_HTML)


@app.post("/run")
def run():
    body   = request.get_json(silent=True) or {}
    company = body.get("company", "").strip().lower()

    if company not in COMPANIES:
        return jsonify({"error": f"Unknown company {company!r}. Must be one of {COMPANIES}"}), 400

    try:
        discovery.run_discovery(company=company)
        downloader.run_download(company=company)
        extractor.run_extract(company=company)
        run_clean_all(company=company)
        cls_result = classifier.run_classify(company=company)
        vb_result  = view_builder.run_build_views()
        csv_exporter.run_export(company=company, fmt="both", output_dir=_OUTPUT_DIR)
        pdf_result = run_export_pdf(company=company, output_dir=_OUTPUT_DIR)

        written_pdfs = pdf_result["written"]
        if not written_pdfs:
            return jsonify({"error": "No PDF was generated"}), 500

        pdf_path   = written_pdfs[0]
        classified = cls_result.get("classified", 0)
        rows       = vb_result.get("rows_written", 0)
        filename   = Path(pdf_path).name

        return send_file(
            pdf_path,
            mimetype="application/pdf",
            as_attachment=True,
            download_name=filename,
            max_age=0,
        ), 200, {
            "X-Filename":     filename,
            "X-Classified":   str(classified),
            "X-Rows-Written": str(rows),
        }

    except Exception as exc:
        logger.exception("Pipeline error")
        return jsonify({"error": str(exc)}), 500


def run_server(host: str = "127.0.0.1", port: int = 8080, debug: bool = False) -> None:
    app.run(host=host, port=port, debug=debug)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    run_server(debug=True)
