"""
Table cleaner: converts raw pdfplumber table data into raw_line_items rows.

Entry point: run_clean_all(company, db_path)
"""
import json
import logging
import re
from pathlib import Path
from typing import Optional

from fiscal import db

logger = logging.getLogger(__name__)

# Matches any digit — used to decide whether a cell contains a number.
_HAS_DIGIT = re.compile(r"\d")

# Matches a 4-digit year in the range 2000-2099.
_YEAR_RE = re.compile(r"20\d{2}")

# Reasonable fiscal year range for these filings.
_MIN_YEAR = 2010
_MAX_YEAR = 2029

# Matches cells that are purely numeric/dash with no alphabetic label content.
# Used to detect tables where col 0 is values, not labels.
_LOOKS_LIKE_VALUE = re.compile(r"^[\s\d,.()\-–—€$%+*/]+$")

# Matches footnote-reference-only labels like "(A.1)", "(C.2)", "(D.9)", "B.6"
# These appear as the only text in SAP/Adyen label cells and are not real labels.
_FOOTNOTE_REF = re.compile(r"^[\s(]*[A-Za-z][\d]+(?:[.,]\d+)*[\s)]*(?:[,;]\s*[\s(]*[A-Za-z][\d]+(?:[.,]\d+)*[\s)]*)*$")


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def run_clean_all(
    company: Optional[str] = None,
    db_path: Optional[Path] = None,
) -> dict[str, int]:
    """
    Clean all raw_tables for every extracted filing (optionally filtered by company).

    Returns {"items_inserted": N, "tables_processed": N, "tables_skipped": N, "filings_cleaned": N}.
    """
    db_path = db_path or db.DB_PATH
    totals = {"items_inserted": 0, "tables_processed": 0, "tables_skipped": 0, "filings_cleaned": 0}

    with db.get_connection(db_path) as conn:
        filings = db.get_filings(conn, company=company, status="extracted", document_type="annual_report")

    for filing in filings:
        counts = run_clean(filing_id=filing["id"], db_path=db_path)
        totals["items_inserted"]   += counts["items_inserted"]
        totals["tables_processed"] += counts["tables_processed"]
        totals["tables_skipped"]   += counts["tables_skipped"]
        totals["filings_cleaned"]  += 1
        with db.get_connection(db_path) as conn:
            db.update_filing(conn, filing["id"], status="classified")

    return totals


def run_clean(
    filing_id: int,
    db_path: Optional[Path] = None,
) -> dict[str, int]:
    """
    Clean all raw_tables for the given filing into raw_line_items.

    Returns {"items_inserted": N, "tables_processed": N, "tables_skipped": N}.
    """
    db_path = db_path or db.DB_PATH
    counts = {"items_inserted": 0, "tables_processed": 0, "tables_skipped": 0}

    with db.get_connection(db_path) as conn:
        filing = db.get_filing_by_id(conn, filing_id)
        if filing is None:
            raise ValueError(f"Filing ID {filing_id} not found.")
        raw_tables = db.get_raw_tables(conn, filing_id)

    if not raw_tables:
        logger.info(f"[{filing['company']}/{filing.get('fiscal_year','?')}] No raw_tables to clean.")
        return counts

    with db.get_connection(db_path) as conn:
        for raw_table in raw_tables:
            items = _clean_table(raw_table, filing)
            if not items:
                counts["tables_skipped"] += 1
                continue
            counts["tables_processed"] += 1
            for item in items:
                db.insert_raw_line_item(conn, item)
                counts["items_inserted"] += 1

    logger.info(
        f"[{filing['company']}/{filing.get('fiscal_year','?')}] "
        f"Cleaned {counts['tables_processed']} table(s), "
        f"{counts['items_inserted']} line item(s) inserted."
    )
    return counts


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _clean_table(raw_table: dict, filing: dict) -> list[dict]:
    """
    Convert one raw_table row into a list of raw_line_item dicts.

    Returns an empty list if the table is empty or yields no usable rows.
    """
    table: list[list] = json.loads(raw_table["raw_data"])
    if not table or len(table) < 2:
        # Need at least a header row + one data row
        return []

    header_row = table[0]
    data_rows  = table[1:]

    # Period labels live in columns 1..N of the header row (col 0 is blank/label)
    period_labels = [str(cell or "").strip() for cell in header_row[1:]]

    # Skip tables where col-0 looks like values, not labels (value-only fragment).
    non_empty_data_rows = [r for r in data_rows if r]
    if non_empty_data_rows:
        value_like_col0 = sum(
            1 for r in non_empty_data_rows
            if _LOOKS_LIKE_VALUE.match(str(r[0] or "").strip())
            and str(r[0] or "").strip()  # non-empty
        )
        if value_like_col0 / len(non_empty_data_rows) > 0.5:
            return []

    # When no period header parses as a year and all headers are empty or plain
    # numbers, fall back to report_year, report_year-1, … column assignment.
    # (Covers tables where pdfplumber produced a blank or all-numeric header row.)
    if period_labels and all(_parse_year(pl) is None for pl in period_labels):
        all_empty_or_numeric = all(
            not pl or _parse_number(pl) is not None for pl in period_labels
        )
        report_year = filing.get("fiscal_year") or 0
        if all_empty_or_numeric and report_year:
            period_labels = [
                str(report_year - i) for i in range(len(period_labels))
            ]

    items = []
    for row_idx, row in enumerate(data_rows):
        if not row:
            continue

        label = str(row[0] or "").strip()
        # Normalize whitespace: collapse newlines and multiple spaces from
        # multi-line cells that pdfplumber merges into a single cell.
        label = " ".join(label.split())
        if not label:
            continue

        # Skip rows where col 0 is purely numeric — these are footnote reference
        # markers like "(1)", "(1,259)", or misaligned value cells, not labels.
        if _parse_number(label) is not None:
            continue

        # Skip labels that are purely footnote references like "(A.1), (C.2)"
        # or "(D.9)" — these have no semantic meaning as line item names.
        if _FOOTNOTE_REF.match(label):
            continue

        # Skip very short labels (< 4 chars of actual letters) — these are
        # truncated cell fragments like "Am", "Wa", "Cos", "Net" that result
        # from pdfplumber splitting multi-line cells mid-word.
        if sum(1 for c in label if c.isalpha()) < 4:
            continue

        value_cells = row[1:]

        # Skip rows that contain no numeric content at all
        if not any(_HAS_DIGIT.search(str(c or "")) for c in value_cells):
            continue

        for col_idx, cell in enumerate(value_cells):
            raw_value = str(cell or "").strip()
            if not raw_value:
                continue

            period_label = period_labels[col_idx] if col_idx < len(period_labels) else ""
            period_year  = _parse_year(period_label)
            parsed_value = _parse_number(raw_value)

            items.append({
                "raw_table_id":   raw_table["id"],
                "filing_id":      filing["id"],
                "company":        filing["company"],
                "report_year":    filing.get("fiscal_year") or 0,
                "statement_type": raw_table["statement_type"],
                "raw_label":      label,
                "raw_value":      raw_value,
                "parsed_value":   parsed_value,
                "period_label":   period_label,
                "period_year":    period_year,
                "page_number":    raw_table["page_number"],
                "table_index":    raw_table["table_index"],
                "row_index":      row_idx + 1,  # +1: row 0 was the header
                "col_index":      col_idx + 1,  # +1: col 0 is the label column
            })

    return items


def _parse_year(text: str) -> Optional[int]:
    """Return the first 20xx year found in text, or None.

    Only accepts years within _MIN_YEAR.._MAX_YEAR to prevent footnote
    markers or page numbers (e.g. "Note 2001") from creating bogus columns.
    """
    m = _YEAR_RE.search(text)
    if not m:
        return None
    year = int(m.group())
    return year if _MIN_YEAR <= year <= _MAX_YEAR else None


def _parse_number(text: str) -> Optional[float]:
    """
    Best-effort numeric parse of a raw cell value.

    Handles common annual-report formatting:
      "1,234.5"  → 1234.5
      "(1,234)"  → -1234   (parentheses = negative)
      "1.234,5"  → 1234.5  (European comma-decimal)
      "—" / "-"  → None    (dash = nil/not applicable)
    """
    s = text.strip()
    if not s or s in {"-", "—", "–", "n/a", "N/A", "—"}:
        return None

    negative = s.startswith("(") and s.endswith(")")
    if negative:
        s = s[1:-1]

    # Remove thousand separators and normalise decimal separator.
    # Heuristic: if both '.' and ',' appear, the last one is the decimal sep.
    if "." in s and "," in s:
        if s.rfind(".") > s.rfind(","):
            # e.g. "1,234.56" — comma is thousands sep
            s = s.replace(",", "")
        else:
            # e.g. "1.234,56" — period is thousands sep
            s = s.replace(".", "").replace(",", ".")
    elif "," in s:
        # Could be "1,234" (thousands) or "1,5" (European decimal)
        parts = s.split(",")
        if len(parts) == 2 and len(parts[1]) <= 2:
            # Treat as decimal separator
            s = s.replace(",", ".")
        else:
            s = s.replace(",", "")
    # else: plain number, possibly with a lone period decimal

    # Strip trailing % or common suffixes
    s = s.rstrip("%").strip()

    try:
        value = float(s)
        return -value if negative else value
    except ValueError:
        return None
