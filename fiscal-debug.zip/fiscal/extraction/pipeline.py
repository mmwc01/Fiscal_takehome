"""
Extraction pipeline: scans PDF pages for financial statement tables and stores
them as raw JSON in the raw_tables table.

This is Phase 4a — raw table persistence only.
Table cleaning and raw_line_items population come in Phase 4b.

Flow (per filing)
-----------------
1. Load filing record from DB; verify local_path exists.
2. Open PDF with pdfplumber.
3. For each page:
   a. Extract page text.
   b. Run statement_detector.detect() on the text.
   c. If statement_type == "unknown", do a fallback check for financial-looking pages.
   d. Extract all tables from the page via pdfplumber.
   e. If pdfplumber tables are poor, try word-based reconstruction.
   f. Store each table as a raw_tables row (JSON, no cleaning).
4. Update filing status: "extracted" or "extraction_failed".

Debuggability
-------------
Every triggered page, its detection reason, table count, and each table's
shape (rows×cols) is logged at INFO level. Run with --verbose to see all of
this in the CLI.

Re-extraction
-------------
`run_extract(filing_id=N)` clears existing raw_tables for that filing before
re-running. Use this when iterating on the extraction logic.
"""
import json
import logging
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import pdfplumber

from fiscal import db
from fiscal.extraction import statement_detector

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Public entry points
# ---------------------------------------------------------------------------

def run_extract(
    company: Optional[str] = None,
    filing_id: Optional[int] = None,
    db_path: Optional[Path] = None,
) -> dict[str, int]:
    """
    Orchestrate extraction for one filing (--filing-id) or all downloaded
    annual reports for a company (or all companies).

    When filing_id is given, existing raw_tables for that filing are cleared
    first so re-extraction is a clean slate.

    Returns {"extracted": N, "failed": N, "skipped": N}.
    """
    db_path = db_path or db.DB_PATH
    counts: dict[str, int] = {"extracted": 0, "failed": 0, "skipped": 0}

    if filing_id is not None:
        with db.get_connection(db_path) as conn:
            filing = db.get_filing_by_id(conn, filing_id)
        if filing is None:
            raise ValueError(f"Filing ID {filing_id} not found in the database.")
        # Clear stale data so re-extraction starts clean
        with db.get_connection(db_path) as conn:
            db.delete_raw_tables_for_filing(conn, filing_id)
        filings = [filing]
    else:
        with db.get_connection(db_path) as conn:
            filings = db.get_filings(
                conn,
                company=company,
                status="downloaded",
                document_type="annual_report",
            )

    if not filings:
        logger.info("No filings to extract (run `fiscal download` first).")
        return counts

    for filing in filings:
        result = _extract_one(filing, db_path)
        if result.get("error"):
            counts["failed"] += 1
        elif result.get("skipped"):
            counts["skipped"] += 1
        else:
            counts["extracted"] += 1

    return counts


def extract_filing(
    filing_id: int,
    db_path: Optional[Path] = None,
) -> dict:
    """
    Extract raw tables from a single filing. Never raises.

    Returns a result dict:
      {"pages_scanned": N, "pages_triggered": N, "tables_stored": N}
      or on failure:
      {"error": "...message..."}
    """
    db_path = db_path or db.DB_PATH

    with db.get_connection(db_path) as conn:
        filing = db.get_filing_by_id(conn, filing_id)

    if filing is None:
        logger.error(f"Filing ID {filing_id} not found.")
        return {"error": f"Filing {filing_id} not found"}

    return _extract_one(filing, db_path)


# ---------------------------------------------------------------------------
# Internal: per-filing extraction
# ---------------------------------------------------------------------------

def _extract_one(filing: dict, db_path: Path) -> dict:
    """Run extraction for one filing dict. Updates filing status in DB. Never raises."""
    tag = f"[{filing['company']}/{filing.get('fiscal_year', '?')}]"

    local_path = filing.get("local_path")
    if not local_path or not Path(local_path).exists():
        msg = f"PDF not found at {local_path!r}"
        logger.error(f"{tag} {msg}")
        with db.get_connection(db_path) as conn:
            db.update_filing(
                conn,
                filing["id"],
                status="extraction_failed",
                extraction_error=msg,
            )
        return {"skipped": True, "error": msg}

    try:
        result = _extract_pdf(filing, db_path)
        with db.get_connection(db_path) as conn:
            db.update_filing(
                conn,
                filing["id"],
                status="extracted",
                extracted_at=_utcnow(),
            )
        logger.info(
            f"{tag} OK — {result['pages_triggered']} page(s) triggered, "
            f"{result['tables_stored']} table(s) stored"
        )
        return result
    except Exception as exc:
        msg = str(exc)[:500]
        logger.error(f"{tag} Extraction failed: {exc}")
        with db.get_connection(db_path) as conn:
            db.update_filing(
                conn,
                filing["id"],
                status="extraction_failed",
                extraction_error=msg,
            )
        return {"error": msg}


def _extract_pdf(filing: dict, db_path: Path) -> dict:
    """
    Open the PDF with pdfplumber, scan every page, and store triggered tables.

    Opens a single DB connection for all table inserts for this filing
    (atomic per filing — if something fails, nothing is written for this filing).
    """
    tag = f"[{filing['company']}/{filing.get('fiscal_year', '?')}]"
    tables_stored = 0
    pages_triggered = 0
    pages_scanned = 0

    with pdfplumber.open(filing["local_path"]) as pdf:
        logger.info(f"{tag} Opened PDF: {len(pdf.pages)} page(s)")

        with db.get_connection(db_path) as conn:
            for page in pdf.pages:
                page_num = page.page_number  # pdfplumber uses 1-indexed page numbers
                pages_scanned += 1

                page_text = page.extract_text() or ""
                if not page_text.strip():
                    logger.debug(f"{tag}   Page {page_num}: no text extracted (skipped)")
                    continue

                detection = statement_detector.detect(page_text)
                found_tables = page.find_tables() or []

                should_extract = False
                extraction_reason = ""
                statement_type = detection.statement_type
                detection_reason = detection.reason

                if detection.statement_type != "unknown":
                    should_extract = True
                    extraction_reason = (
                        f"{detection.statement_type} [{detection.confidence}] — {detection.reason}"
                    )
                else:
                    # Fallback path for pages the detector misses but that still
                    # look like useful financial/note pages.
                    if _looks_financial(page_text):
                        should_extract = True
                        extraction_reason = (
                            "fallback financial-text trigger — detector returned unknown"
                        )
                        detection_reason = (
                            f"fallback financial-text trigger; original detector reason: {detection.reason}"
                        )
                        statement_type = "unknown"

                if not should_extract:
                    continue

                pages_triggered += 1
                logger.info(f"{tag}   Page {page_num}: TRIGGERED → {extraction_reason}")
                logger.info(f"{tag}   Page {page_num}: {len(found_tables)} table(s) found")

                # If pdfplumber's table detection produced unusable tables,
                # fall back to word-position based reconstruction.
                # Two failure modes to detect:
                #   (a) all data tables are single-column — no row boundaries found
                #   (b) tables have stacked multi-value cells (newlines in numeric cells)
                # Single-row tables (nav bars) are excluded from the check.
                data_table_pairs = [
                    (tbl, tbl.extract() or [])
                    for tbl in found_tables
                    if len(tbl.extract() or []) > 1
                ]

                all_single_col = bool(data_table_pairs) and all(
                    max((len(r) for r in data), default=0) <= 1
                    for _, data in data_table_pairs
                )
                has_stacked = bool(data_table_pairs) and any(
                    any(
                        cell and "\n" in str(cell) and re.search(r"\d", str(cell))
                        for row in data[:5]
                        for cell in row
                    )
                    for _, data in data_table_pairs
                )

                reconstructed = None
                if all_single_col or has_stacked or (not found_tables and _looks_financial(page_text)):
                    reconstructed = _reconstruct_table_from_words(page)
                    if reconstructed:
                        logger.info(
                            f"{tag}   Page {page_num}: word-reconstruction yielded "
                            f"{len(reconstructed)}×{max(len(r) for r in reconstructed)} table"
                        )
                        found_tables = [_FakeTable(reconstructed)]

                # If no table on this page has year column headers in row 0,
                # try to recover them from the page text (e.g. "NOTE 2025 2024").
                # Annual report PDFs sometimes render column headers as floating
                # text above the table boundary, so pdfplumber misses them.
                page_year_tokens = _page_year_header(page_text)

                for i, tbl_obj in enumerate(found_tables):
                    table = tbl_obj.extract()
                    if not table:
                        continue

                    # If the table has no usable label column (col 0 is all
                    # None/empty), try to align labels from page text by
                    # Y-coordinate. This fixes PDFs where the label column is
                    # flowing text outside the table boundary.
                    if not isinstance(tbl_obj, _FakeTable):
                        table = _inject_labels_from_page(page, tbl_obj, table)

                    # Inject synthetic year header when row 0 has no years but
                    # the page text does (floating column headers not in table box).
                    if (
                        page_year_tokens
                        and not isinstance(tbl_obj, _FakeTable)
                        and not _row0_has_years(table)
                    ):
                        n_cols = max((len(row) for row in table), default=0)
                        header = _make_year_header(page_year_tokens, n_cols)
                        if header:
                            table = [header] + table
                            logger.debug(
                                f"{tag}     Table {i}: injected year header {header}"
                            )

                    num_rows = len(table)
                    num_cols = max((len(row) for row in table), default=0)
                    logger.info(f"{tag}     Table {i}: {num_rows}×{num_cols}")

                    db.insert_raw_table(
                        conn,
                        {
                            "filing_id": filing["id"],
                            "page_number": page_num,
                            "table_index": i,
                            "raw_data": json.dumps(table),
                            "num_rows": num_rows,
                            "num_cols": num_cols,
                            "statement_type": statement_type,
                            "detection_reason": detection_reason,
                            "extracted_at": _utcnow(),
                        },
                    )
                    tables_stored += 1

    return {
        "pages_scanned": pages_scanned,
        "pages_triggered": pages_triggered,
        "tables_stored": tables_stored,
    }


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


class _FakeTable:
    """Thin wrapper so word-reconstructed tables fit the existing tbl_obj.extract() call pattern."""

    def __init__(self, rows: list[list]):
        self._rows = rows
        # Provide a dummy bbox spanning the full page (not used for label injection)
        self.bbox = (0, 0, 0, 0)

    def extract(self) -> list[list]:
        return self._rows


_YEAR_RE = re.compile(r"^20[12]\d$")
_VALUE_RE = re.compile(r"^[\-–—\(\d,\.]+[\)\d]?$")
_PTEXT_YEAR = re.compile(r"20[12]\d")  # search version for page text


def _looks_financial(page_text: str) -> bool:
    """
    Recall-oriented fallback gate for pages the strict statement detector misses.

    A page is considered "financial-looking" when it contains multiple terms that
    strongly suggest statement rows, note tables, or financial disclosures.
    """
    text = page_text.lower()

    phrases = [
        "revenue",
        "net revenue",
        "other income",
        "other financial results",
        "interest income",
        "interest expense",
        "income tax",
        "income taxes",
        "net income",
        "net profit",
        "profit before tax",
        "ebitda",
        "operating activities",
        "investing activities",
        "financing activities",
        "cash and cash equivalents",
        "closing cash position",
        "opening cash position",
        "total assets",
        "total liabilities",
        "total equity",
        "current assets",
        "current liabilities",
        "retained earnings",
        "share capital",
    ]

    hits = sum(1 for phrase in phrases if phrase in text)

    # Require a few strong signals to avoid triggering on generic prose.
    return hits >= 3


def _reconstruct_table_from_words(page) -> list[list] | None:
    """
    Word-position based table reconstruction for pages where pdfplumber
    cannot detect row boundaries.

    Extracts words with (x, y) positions, identifies value-column X centres
    from header rows containing year numbers, then groups remaining words into
    label and value cells.

    Returns [[label, val1, val2, ...], ...] or None if reconstruction fails.
    """
    NAV_X_MAX = 55      # left navigation sidebar cutoff
    Y_BUCKET = 3        # points per Y band for row grouping
    COL_TOL = 28        # ± tolerance for assigning a word to a value column

    try:
        words = page.extract_words(
            x_tolerance=3,
            y_tolerance=3,
            keep_blank_chars=False,
        )
    except Exception:
        return None

    if not words:
        return None

    # Filter nav sidebar
    words = [w for w in words if w["x0"] > NAV_X_MAX]

    # Group into Y-bucketed rows
    lines: dict[int, list] = {}
    for w in words:
        y_key = round(w["top"] / Y_BUCKET) * Y_BUCKET
        lines.setdefault(y_key, []).append(w)

    sorted_lines = [
        (y, sorted(ws, key=lambda ww: ww["x0"]))
        for y, ws in sorted(lines.items())
    ]

    # Discover value-column X centres: look for rows containing ≥2 four-digit years
    val_col_xs: list[float] = []
    val_col_years: list[str] = []
    for _y, ws in sorted_lines:
        year_hits = [
            ((w["x0"] + w["x1"]) / 2, w["text"])
            for w in ws
            if _YEAR_RE.match(w["text"])
        ]
        if len(year_hits) >= 2:
            val_col_xs = [x for x, _ in sorted(year_hits)]
            val_col_years = [yr for _, yr in sorted(year_hits)]
            break

    if not val_col_xs:
        return None

    # Split value columns into "left statement" and "right statement" by
    # finding the largest gap between consecutive column X positions.
    MIN_SPLIT_GAP = 80  # pt — smaller gaps are within one statement
    split_idx = 0
    if len(val_col_xs) >= 2:
        gaps = [val_col_xs[i + 1] - val_col_xs[i] for i in range(len(val_col_xs) - 1)]
        max_gap = max(gaps)
        if max_gap >= MIN_SPLIT_GAP:
            split_idx = gaps.index(max_gap) + 1

    left_val_xs = [(i, x) for i, x in enumerate(val_col_xs) if i < split_idx or split_idx == 0]
    right_val_xs = [(i, x) for i, x in enumerate(val_col_xs) if i >= split_idx and split_idx > 0]

    if not left_val_xs:
        return None

    left_label_max = left_val_xs[0][1] - 30
    right_label_min = left_val_xs[-1][1] + 20
    right_label_max = right_val_xs[0][1] - 30 if right_val_xs else right_label_min

    def _col_for_word(w: dict) -> tuple[str, int] | None:
        xc = (w["x0"] + w["x1"]) / 2
        for idx, vx in left_val_xs:
            if abs(xc - vx) <= COL_TOL:
                return ("left_val", idx)
        for idx, vx in right_val_xs:
            if abs(xc - vx) <= COL_TOL:
                return ("right_val", idx)
        if xc <= left_label_max:
            return ("left_label", 0)
        if right_val_xs and right_label_min <= xc <= right_label_max:
            return ("right_label", 0)
        return None

    output: list[tuple[float, list]] = []

    for y, ws in sorted_lines:
        left_label_words: list[str] = []
        right_label_words: list[str] = []
        left_vals: dict[int, list[str]] = {}
        right_vals: dict[int, list[str]] = {}

        for w in ws:
            assignment = _col_for_word(w)
            if assignment is None:
                continue
            kind, idx = assignment
            if kind == "left_label":
                left_label_words.append(w["text"])
            elif kind == "right_label":
                right_label_words.append(w["text"])
            elif kind == "left_val":
                left_vals.setdefault(idx, []).append(w["text"])
            elif kind == "right_val":
                right_vals.setdefault(idx, []).append(w["text"])

        ll = " ".join(left_label_words).strip()
        lv = [" ".join(left_vals.get(i, [])).strip() for i, _ in left_val_xs]
        if ll or any(lv):
            output.append((y, [ll] + lv))

        if right_val_xs:
            rl = " ".join(right_label_words).strip()
            rv = [" ".join(right_vals.get(i, [])).strip() for i, _ in right_val_xs]
            if rl or any(rv):
                output.append((y + 0.5, [rl] + rv))

    if len(output) < 3:
        return None

    rows = [row for _, row in sorted(output)]

    num_left_vals = len(left_val_xs)
    num_right_vals = len(right_val_xs)
    max_cols = 1 + max(num_left_vals, num_right_vals)

    left_years = [val_col_years[i] for i, _ in left_val_xs]
    right_years = [val_col_years[i] for i, _ in right_val_xs]

    header_years = left_years if num_left_vals >= num_right_vals else right_years
    header = [""] + header_years + [""] * (max_cols - 1 - len(header_years))

    def _pad(r: list) -> list:
        return r + [""] * (max_cols - len(r)) if len(r) < max_cols else r[:max_cols]

    result = [_pad(header)] + [_pad(r) for r in rows]
    return result


def _inject_labels_from_page(page, tbl_obj, table: list[list]) -> list[list]:
    """
    If a table's col 0 is entirely None/empty, attempt to recover labels by
    extracting words from the page region to the LEFT of the table and aligning
    them with table rows by Y-coordinate.

    Returns the original table unchanged if col 0 already has content or if
    label recovery yields nothing useful.
    """
    if not table or len(table) < 2:
        return table

    col0_values = [str(row[0] or "").strip() for row in table if row]
    populated = sum(1 for v in col0_values if v)
    if populated / len(col0_values) > 0.4:
        return table

    try:
        tbl_bbox = tbl_obj.bbox  # (x0, y0, x1, y1)
        label_x1 = tbl_bbox[0]
        page_x0 = 0
        page_y0 = tbl_bbox[1]
        page_y1 = tbl_bbox[3]

        if label_x1 < 20:
            return table

        label_region = page.crop((page_x0, page_y0, label_x1, page_y1))
        words = label_region.extract_words(
            x_tolerance=5,
            y_tolerance=5,
            keep_blank_chars=False,
        )
        if not words:
            return table

        lines: dict[float, list[str]] = {}
        for w in words:
            y = round(w["top"] / 4) * 4
            lines.setdefault(y, []).append(w["text"])

        sorted_lines = sorted(lines.items())

        n_rows = len(table)
        tbl_top = tbl_bbox[1]
        tbl_bottom = tbl_bbox[3]
        row_height = (tbl_bottom - tbl_top) / n_rows if n_rows else 1
        row_centers = [tbl_top + (i + 0.5) * row_height for i in range(n_rows)]

        row_labels: dict[int, str] = {}
        for line_y, words_in_line in sorted_lines:
            label_text = " ".join(words_in_line).strip()
            if not label_text:
                continue
            best_row = min(
                range(len(row_centers)),
                key=lambda idx: abs(row_centers[idx] - line_y),
            )
            if abs(row_centers[best_row] - line_y) <= row_height:
                existing = row_labels.get(best_row, "")
                row_labels[best_row] = (
                    (existing + " " + label_text).strip()
                    if existing else label_text
                )

        if not row_labels:
            return table

        enriched = []
        for row_idx, row in enumerate(table):
            if row is None:
                enriched.append(row)
                continue
            new_row = list(row)
            if row_idx in row_labels:
                new_row[0] = row_labels[row_idx]
            enriched.append(new_row)

        return enriched

    except Exception:
        return table


def _page_year_header(page_text: str) -> list[str]:
    """
    Scan the first 15 lines of page text for a column-header line like
    'NOTE 2025 2024' or '2024 2023 2022'.

    Returns deduplicated tokens starting at the first year/'NOTE' token.
    """
    _HEADER_WORDS = {"NOTE", "NOTES", "%", "#", "EUR", "USD", "GBP", "CHF", "THB", "SGD"}
    for line in page_text.split("\n")[:15]:
        years = _PTEXT_YEAR.findall(line)
        if len(set(years)) < 2:
            continue
        tokens = line.split()
        if not tokens:
            continue
        header_count = sum(
            1 for t in tokens
            if _PTEXT_YEAR.match(t) or t.upper() in _HEADER_WORDS
        )
        if header_count / len(tokens) < 0.4:
            continue
        seen: set[str] = set()
        unique: list[str] = []
        for t in tokens:
            if t not in seen:
                seen.add(t)
                unique.append(t)
        for start, t in enumerate(unique):
            if _PTEXT_YEAR.match(t) or t.upper() in ("NOTE", "NOTES"):
                return unique[start:]
    return []


def _row0_has_years(table: list[list]) -> bool:
    """Return True if the first row of table contains any year-like value."""
    if not table or not table[0]:
        return False
    return any(_PTEXT_YEAR.search(str(cell or "")) for cell in table[0])


def _make_year_header(tokens: list[str], n_cols: int) -> list | None:
    """
    Build a synthetic header row of length n_cols from page-text year tokens.
    """
    if n_cols < 2 or not tokens:
        return None
    slots = n_cols - 1
    if len(tokens) == slots:
        return [""] + tokens
    year_tokens = [t for t in tokens if _PTEXT_YEAR.match(t)]
    if 0 < len(year_tokens) <= slots:
        return [""] + [""] * (slots - len(year_tokens)) + year_tokens
    return None