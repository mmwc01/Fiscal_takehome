"""
Extraction package: PDF parsing, statement detection, table cleaning, line item writing.

Phase 4 — not yet implemented.

When implemented, the pipeline will have two sub-stages:
  4a. Extract raw tables from PDF pages → raw_tables (persisted before normalization)
  4b. Clean raw tables → raw_line_items

Keeping raw_tables separate from raw_line_items means you can re-run cleaning
against stored table data without re-parsing PDFs.
"""
