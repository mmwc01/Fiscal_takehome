"""
Combined view builder: merges all three financial statements per company
into a single combined_views table, with canonical labels applied.

For each company the table contains rows for income_statement (order=1),
balance_sheet (order=2), and cash_flow_statement (order=3), using the
canonical labels and sort_orders from label_mappings.  Raw labels without
a mapping are included as-is with sort_order=999.

When multiple raw labels map to the same canonical label for the same
period_year, the first non-NULL value wins.

Entry point
-----------
    run_build_combined(company, db_path) -> dict[str, int]
        Returns {"rows_written": N, "companies_processed": N}.
"""
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from fiscal import db

logger = logging.getLogger(__name__)

_STATEMENT_ORDER = {
    "income_statement":    1,
    "balance_sheet":       2,
    "cash_flow_statement": 3,
}


def run_build_combined(
    company: Optional[str] = None,
    db_path: Optional[Path] = None,
) -> dict[str, int]:
    """
    Build combined_views for all companies (or one if company= is given).

    Returns {"rows_written": N, "companies_processed": N}.
    """
    db_path = db_path or db.DB_PATH

    with db.get_connection(db_path) as conn:
        if company:
            companies = [company]
        else:
            rows = conn.execute(
                "SELECT DISTINCT company FROM compiled_views ORDER BY company"
            ).fetchall()
            companies = [r[0] for r in rows]

    total_rows = 0
    for co in companies:
        n = _build_one(co, db_path)
        total_rows += n
        logger.info(f"[{co}] {n} combined_view row(s) written.")

    return {"rows_written": total_rows, "companies_processed": len(companies)}


# ---------------------------------------------------------------------------
# Internal
# ---------------------------------------------------------------------------

def _build_one(company: str, db_path: Path) -> int:
    """Rebuild combined_views for one company. Returns rows written."""
    built_at = datetime.now(timezone.utc).isoformat()
    written = 0

    with db.get_connection(db_path) as conn:
        # Clear existing rows for this company
        conn.execute("DELETE FROM combined_views WHERE company = ?", (company,))

        for stmt, stmt_order in _STATEMENT_ORDER.items():
            mappings = db.get_label_mappings(conn, company, stmt)

            # All compiled rows for this (company, stmt)
            rows = conn.execute(
                "SELECT label, period_year, value "
                "FROM compiled_views "
                "WHERE company = ? AND statement_type = ? "
                "ORDER BY label, period_year",
                (company, stmt),
            ).fetchall()

            if not rows:
                continue

            # Group: canonical_label -> {period_year -> first non-NULL value}
            # Also track sort_order per canonical label
            groups: dict[str, dict] = {}  # canonical -> {"_sort": int, year: value}

            for row in rows:
                raw = row["label"]
                m = mappings.get(raw)

                if m and not m["include"]:
                    continue

                canon = m["canonical_label"] if m else raw
                sort  = m["sort_order"]      if m else 999

                entry = groups.setdefault(canon, {"_sort": sort})
                py = row["period_year"]
                if py and py not in entry:
                    # first non-NULL value wins
                    entry[py] = row["value"]

            # Write rows
            for canon, year_data in groups.items():
                sort_order = year_data["_sort"]
                for period_year, value in year_data.items():
                    if period_year == "_sort":
                        continue
                    db.upsert_combined_view(conn, {
                        "company":        company,
                        "statement_type": stmt,
                        "statement_order": stmt_order,
                        "canonical_label": canon,
                        "sort_order":     sort_order,
                        "period_year":    period_year,
                        "value":          value,
                        "built_at":       built_at,
                    })
                    written += 1

    return written
