"""
Canonicalizer: uses OpenAI to deduplicate and order financial statement labels.

For each (company, statement_type) combination in compiled_views, this module:
  1. Fetches all unique raw labels
  2. Asks GPT-4o to assign canonical names, a sort order, and include/exclude flags
  3. Stores the mappings in the label_mappings table

The exporter then uses these mappings to produce clean, ordered output instead
of the raw alphabetical dump.

Entry point
-----------
    run_canonicalize(company, statement_type, api_key, db_path) -> dict[str, int]
        Returns {"mappings_written": N, "combinations_processed": N}.
"""
import json
import logging
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from openai import OpenAI

from fiscal import db

logger = logging.getLogger(__name__)

STATEMENT_TYPES = ["income_statement", "balance_sheet", "cash_flow_statement"]

_STATEMENT_DISPLAY = {
    "income_statement":    "Income Statement",
    "balance_sheet":       "Balance Sheet",
    "cash_flow_statement": "Cash Flow Statement",
}

_COMPANY_DISPLAY = {
    "adyen":    "Adyen N.V.",
    "heineken": "Heineken N.V.",
    "sap":      "SAP SE",
}

_SYSTEM_PROMPT = """\
You are a financial analyst specializing in European public company annual reports (IFRS).
You will receive a list of raw labels extracted by OCR/PDF parsing from a company's \
financial statements. The list contains:
- Duplicates with slightly different names across report years
- Items from notes or supplementary schedules that do not belong in the primary statement
- Legitimate line items that should appear in the final clean table

Your job is to return a JSON array — one object per input raw label — with these fields:
  "raw_label"       : exactly as provided (do not modify)
  "canonical_label" : the clean, standardized name to display (use the company's latest \
report wording; merge near-duplicates to one name)
  "sort_order"      : integer 1–999 reflecting where this item appears in the statement \
(top of statement = low number; subtotals/totals near the bottom = higher)
  "include"         : true if this belongs in the primary statement, false to exclude \
(exclude: balance sheet items in an income statement, note-only items like maturity \
schedules, currency names, percentages, share count rows, etc.)

Rules:
- Multiple raw labels that represent the same line item MUST share the same \
canonical_label and sort_order.
- Do NOT invent new line items; only map what is given.
- Respond with ONLY the JSON array, no markdown fences, no explanation.
"""


def run_canonicalize(
    company: Optional[str] = None,
    statement_type: Optional[str] = None,
    api_key: Optional[str] = None,
    model: str = "gpt-4o",
    db_path: Optional[Path] = None,
) -> dict[str, int]:
    """
    Run label canonicalization for all (company, statement_type) combinations
    that have compiled_view rows, optionally filtered.

    Returns {"mappings_written": N, "combinations_processed": N}.
    """
    db_path = db_path or db.DB_PATH
    api_key = api_key or os.environ.get("OPENAI_API_KEY")
    if not api_key:
        raise ValueError("OpenAI API key required (pass api_key= or set OPENAI_API_KEY)")

    client = OpenAI(api_key=api_key)

    # Fetch all (company, statement_type) pairs that have data
    with db.get_connection(db_path) as conn:
        rows = conn.execute(
            """
            SELECT DISTINCT company, statement_type
            FROM compiled_views
            ORDER BY company, statement_type
            """
        ).fetchall()

    pairs = [
        (r["company"], r["statement_type"])
        for r in rows
        if (company is None or r["company"] == company)
        and (statement_type is None or r["statement_type"] == statement_type)
    ]

    total_mappings = 0
    for co, stmt in pairs:
        n = _canonicalize_one(co, stmt, client, model, db_path)
        total_mappings += n
        logger.info(f"[{co}/{stmt}] {n} mapping(s) written.")

    return {"mappings_written": total_mappings, "combinations_processed": len(pairs)}


# ---------------------------------------------------------------------------
# Internal
# ---------------------------------------------------------------------------

def _canonicalize_one(
    company: str,
    statement_type: str,
    client: OpenAI,
    model: str,
    db_path: Path,
) -> int:
    """Canonicalize labels for one (company, statement_type). Returns rows written."""
    with db.get_connection(db_path) as conn:
        raw_labels = [
            r[0]
            for r in conn.execute(
                "SELECT DISTINCT label FROM compiled_views "
                "WHERE company = ? AND statement_type = ? ORDER BY label",
                (company, statement_type),
            ).fetchall()
        ]

    if not raw_labels:
        return 0

    co_display   = _COMPANY_DISPLAY.get(company, company.title())
    stmt_display = _STATEMENT_DISPLAY.get(statement_type, statement_type.replace("_", " ").title())

    user_msg = (
        f"Company: {co_display}\n"
        f"Statement: {stmt_display}\n"
        f"Number of raw labels: {len(raw_labels)}\n\n"
        f"Raw labels (one per line):\n"
        + "\n".join(f"- {lbl}" for lbl in raw_labels)
    )

    logger.info(
        f"[{company}/{statement_type}] Sending {len(raw_labels)} label(s) to {model}…"
    )

    response = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": _SYSTEM_PROMPT},
            {"role": "user",   "content": user_msg},
        ],
        temperature=0,
    )

    raw_json = response.choices[0].message.content.strip()

    # Strip markdown fences if the model added them despite instructions
    if raw_json.startswith("```"):
        raw_json = "\n".join(
            line for line in raw_json.splitlines()
            if not line.startswith("```")
        ).strip()

    parsed = json.loads(raw_json)

    # Unwrap if the model returned {"mappings": [...]} instead of [...]
    if isinstance(parsed, dict):
        for v in parsed.values():
            if isinstance(v, list):
                parsed = v
                break

    created_at = datetime.now(timezone.utc).isoformat()
    written = 0

    with db.get_connection(db_path) as conn:
        for item in parsed:
            raw_label = item.get("raw_label", "").strip()
            if not raw_label:
                continue
            db.upsert_label_mapping(conn, {
                "company":        company,
                "statement_type": statement_type,
                "raw_label":      raw_label,
                "canonical_label": item.get("canonical_label", raw_label).strip(),
                "sort_order":     int(item.get("sort_order", 999)),
                "include":        1 if item.get("include", True) else 0,
                "created_at":     created_at,
            })
            written += 1

    return written
