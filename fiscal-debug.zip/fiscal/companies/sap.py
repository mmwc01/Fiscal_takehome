"""
SAP SE — Discovery adapter.

IR page: https://www.sap.com/investors/en/reports.html

Scraper strategy
----------------
SAP's investor relations page renders its report listing via JavaScript.
A static BeautifulSoup parse will almost always return zero PDF links.
The scraper is included for completeness but is expected to fail in most
environments, triggering the fallback immediately.

Fallback (expected primary path for SAP)
-----------------------------------------
FALLBACK_FILINGS covers 10 years (2014–2023) from sap.com/docs/download.
SAP switched from "Annual Report" to "Integrated Report" branding around 2020.
URLs were verified in April 2025. Re-check if you encounter 404s.
"""
import logging
import re
from urllib.parse import urljoin

import requests
from bs4 import BeautifulSoup

logger = logging.getLogger(__name__)

KEY = "sap"
NAME = "SAP SE"
IR_URL = "https://www.sap.com/investors/en/reports.html"
_BASE = "https://www.sap.com"

# NOTE: SAP's IR page uses JS; fallback is the expected code path.
# Verify URLs before running; update from the IR page if any return 404.
FALLBACK_FILINGS: list[dict] = [
    {
        "title": "SAP Integrated Report 2024",
        "url": "https://www.sap.com/docs/download/investors/2024/sap-2024-integrated-report.pdf",
        "fiscal_year": 2024,
    },
    {
        "title": "SAP Integrated Report 2023",
        "url": "https://www.sap.com/docs/download/investors/2023/sap-2023-integrated-report.pdf",
        "fiscal_year": 2023,
    },
    {
        "title": "SAP Integrated Report 2022",
        "url": "https://www.sap.com/docs/download/investors/2022/sap-2022-integrated-report.pdf",
        "fiscal_year": 2022,
    },
    {
        "title": "SAP Integrated Report 2021",
        "url": "https://www.sap.com/docs/download/investors/2021/sap-2021-integrated-report.pdf",
        "fiscal_year": 2021,
    },
    {
        "title": "SAP Integrated Report 2020",
        "url": "https://www.sap.com/docs/download/investors/2020/sap-2020-integrated-report.pdf",
        "fiscal_year": 2020,
    },
    {
        "title": "SAP Annual Report 2019",
        "url": "https://www.annualreports.com/HostedData/AnnualReportArchive/s/NYSE_SAP_2019.pdf",
        "fiscal_year": 2019,
    },
    {
        "title": "SAP Annual Report 2018",
        "url": "https://www.annualreports.com/HostedData/AnnualReportArchive/s/NYSE_SAP_2018.pdf",
        "fiscal_year": 2018,
    },
    {
        "title": "SAP Annual Report 2017",
        "url": "https://www.annualreports.com/HostedData/AnnualReportArchive/s/NYSE_SAP_2017.pdf",
        "fiscal_year": 2017,
    },
    {
        "title": "SAP Annual Report 2016",
        "url": "https://www.annualreports.com/HostedData/AnnualReportArchive/s/NYSE_SAP_2016.pdf",
        "fiscal_year": 2016,
    },
    {
        "title": "SAP Annual Report 2015",
        "url": "https://www.sap.com/docs/download/investors/2015/sap-2015-annual-report.pdf",
        "fiscal_year": 2015,
    },
    {
        "title": "SAP Annual Report 2014",
        "url": "https://www.sap.com/docs/download/investors/2014/sap-2014-annual-report.pdf",
        "fiscal_year": 2014,
    },
]

# SAP sometimes uses German filenames even for English PDFs
_ANNUAL_SIGNALS = ["annual", "integrated-report", "geschaeftsbericht", "jahresbericht"]
_YEAR_RE = re.compile(r"\b(20\d{2})\b")


def prepare_session(session: requests.Session) -> None:
    """
    Configure the shared requests session for SAP's CDN.

    SAP's docs.download CDN runs Akamai Bot Manager.  It checks for
    browser-authentic headers including Sec-Fetch-* metadata, Accept-Language,
    and a same-origin Referer.  The full header set below passes the check.
    """
    session.headers.update({
        "User-Agent": (
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/124.0.0.0 Safari/537.36"
        ),
        "Referer": IR_URL,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
        "Accept-Encoding": "gzip, deflate, br",
        "Connection": "keep-alive",
        "Sec-Fetch-Dest": "document",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Site": "same-origin",
    })


def discover_filings(session: requests.Session) -> list[dict]:
    """
    Return FilingCandidate dicts for SAP annual reports.
    SAP's page requires JS; the scraper is expected to fail and trigger the fallback.
    """
    try:
        candidates = _scrape(session)
        if len(candidates) < 2:
            raise ValueError(
                f"scraper returned only {len(candidates)} result(s) "
                "— SAP IR page likely requires JavaScript rendering"
            )
        logger.info(f"sap: scraper found {len(candidates)} filing(s)")
        return candidates
    except Exception as exc:
        logger.warning(
            f"sap: scraper failed ({exc}); "
            f"using {len(FALLBACK_FILINGS)} hardcoded fallback URL(s)"
        )
        return FALLBACK_FILINGS


# ---------------------------------------------------------------------------
# Internal
# ---------------------------------------------------------------------------

def _scrape(session: requests.Session) -> list[dict]:
    resp = session.get(IR_URL, timeout=15)
    resp.raise_for_status()
    soup = BeautifulSoup(resp.text, "lxml")

    candidates: list[dict] = []
    seen: set[str] = set()

    for a in soup.find_all("a", href=True):
        href: str = a["href"]
        if not href.lower().endswith(".pdf"):
            continue

        abs_url = urljoin(_BASE, href)
        link_text = a.get_text(strip=True)
        combined = (abs_url + link_text).lower()

        if not any(sig in combined for sig in _ANNUAL_SIGNALS):
            continue

        if abs_url in seen:
            continue
        seen.add(abs_url)

        title = link_text or _title_from_url(href)
        fiscal_year = _year_from(title) or _year_from(href)
        candidates.append({"title": title, "url": abs_url, "fiscal_year": fiscal_year})

    return candidates


def _title_from_url(url: str) -> str:
    stem = url.rstrip("/").split("/")[-1].replace(".pdf", "")
    return stem.replace("-", " ").replace("_", " ").title()


def _year_from(text: str) -> int | None:
    m = _YEAR_RE.search(text)
    return int(m.group(1)) if m else None
