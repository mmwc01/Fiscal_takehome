"""
Company registry.

REGISTRY maps company keys to their adapter modules. Each adapter module exposes:

    KEY              : str   — short key, e.g. "adyen"
    NAME             : str   — display name, e.g. "Adyen N.V."
    FALLBACK_FILINGS : list[dict]  — hardcoded fallback URLs with title/url/fiscal_year
    discover_filings : (session: requests.Session) -> list[dict]

The list[dict] return type is a list of FilingCandidate dicts:
    title       : str
    url         : str            — must be a direct PDF link
    fiscal_year : int | None     — if known from the source page

No base class or protocol is used — the three adapters follow this convention
by construction.
"""
from types import ModuleType

from fiscal.companies import adyen, heineken, sap

REGISTRY: dict[str, ModuleType] = {
    adyen.KEY:    adyen,
    heineken.KEY: heineken,
    sap.KEY:      sap,
}

__all__ = ["REGISTRY", "adyen", "heineken", "sap"]
