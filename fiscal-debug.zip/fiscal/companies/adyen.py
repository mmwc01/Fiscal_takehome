"""
Adyen N.V. — Discovery adapter.

Current IR entrypoint:
    https://investors.adyen.com/financials

Strategy
--------
1. Load the Financials page.
2. Find year detail pages under /financials/<year>.
3. Open each year page and extract the "Download PDF" link.
4. Return filing candidates for the annual reports.

Notes
-----
- Adyen's old media.adyen.com fallback URLs are stale in some environments, so
  this adapter intentionally relies on the live investor site instead.
- If scraping fails, we return an empty list and let the discovery layer/logs
  make the failure visible.
"""
from __future__ import annotations

import logging
import re
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup

logger = logging.getLogger(__name__)

KEY = "adyen"
NAME = "Adyen N.V."
IR_URL = "https://investors.adyen.com/financials"
_BASE = "https://investors.adyen.com"

_YEAR_RE = re.compile(r"\b(20\d{2})\b")
_YEAR_PATH_RE = re.compile(r"/financials/(20\d{2})(?:/)?$")


def discover_filings(session: requests.Session) -> list[dict]:
    """
    Return FilingCandidate dicts for Adyen annual reports.

    Unlike the other adapters, this one does not rely on hardcoded fallback PDF
    URLs because Adyen's older CDN paths are no longer reliable.
    """
    candidates = _scrape(session)
    if len(candidates) < 2:
        raise ValueError(f"adyen scraper returned only {len(candidates)} result(s)")
    logger.info(f"adyen: scraper found {len(candidates)} filing(s)")
    return candidates


def _scrape(session: requests.Session) -> list[dict]:
    resp = session.get(IR_URL, timeout=20)
    resp.raise_for_status()

    soup = BeautifulSoup(resp.text, "lxml")
    year_pages = _find_year_pages(soup)

    candidates: list[dict] = []
    seen_pdfs: set[str] = set()

    for fiscal_year, year_page_url in sorted(year_pages.items(), reverse=True):
        try:
            pdf_url = _find_pdf_on_year_page(session, year_page_url)
        except Exception as exc:
            logger.warning(
                f"adyen: failed to resolve PDF for {fiscal_year} from {year_page_url}: {exc}"
            )
            continue

        if pdf_url in seen_pdfs:
            continue
        seen_pdfs.add(pdf_url)

        candidates.append(
            {
                "title": f"Annual Report {fiscal_year}",
                "url": pdf_url,
                "fiscal_year": fiscal_year,
            }
        )

    return candidates


def _find_year_pages(soup: BeautifulSoup) -> dict[int, str]:
    """
    Find /financials/<year> detail pages from the main financials page.
    """
    year_pages: dict[int, str] = {}

    for a in soup.find_all("a", href=True):
        href = a["href"].strip()
        abs_url = urljoin(_BASE, href)

        match = _YEAR_PATH_RE.search(urlparse(abs_url).path)
        if not match:
            continue

        fiscal_year = int(match.group(1))
        if fiscal_year < 2018:
            continue

        year_pages[fiscal_year] = abs_url

    return year_pages


def _find_pdf_on_year_page(session: requests.Session, year_page_url: str) -> str:
    """
    Find the PDF download link on a given Adyen financial year page.
    """
    resp = session.get(year_page_url, timeout=20)
    resp.raise_for_status()

    soup = BeautifulSoup(resp.text, "lxml")

    # Best match: explicit Download PDF button
    for a in soup.find_all("a", href=True):
        href = a["href"].strip()
        abs_url = urljoin(year_page_url, href)

        aria = (a.get("aria-label") or "").strip().lower()
        track_text = (a.get("data-track-text") or "").strip().lower()
        text = a.get_text(" ", strip=True).lower()

        if (
            aria == "download pdf"
            or track_text == "download pdf"
            or text == "download pdf"
        ):
            return abs_url

    # Fallback: any Adyen brand asset download lnk
    for a in soup.find_all("a", href=True):
        href = a["href"].strip()
        abs_url = urljoin(year_page_url, href)

        if "brand.adyen.com/api/asset/" in abs_url and abs_url.endswith("/download"):
            return abs_url

    raise ValueError(f"no PDF link found on {year_page_url}")


def _year_from(text: str) -> int | None:
    m = _YEAR_RE.search(text)
    return int(m.group(1)) if m else None