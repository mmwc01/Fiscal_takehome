"""
Heineken N.V. — Discovery adapter.

IR page: https://www.theheinekencompany.com/investors/results-reports-webcasts-presentations

Age gate
--------
All pages and PDFs on theheinekencompany.com are behind an age gate.
``prepare_session`` must be called once per session before any requests
are made.  It POSTs to the age gate form and stores the resulting
``age_gate_access`` cookie on the session.

Scraper strategy
----------------
Parse the IR page with BeautifulSoup. Collect <a> tags whose href ends
in ``.pdf``.  Filter to links whose path or text contains "annual" or
"jaarverslag" (Dutch).

Fallback
--------
If the scraper fails, FALLBACK_FILINGS is used (10 years: 2014–2025).
All URLs were verified in April 2026.  The site has no consistent URL
pattern across years — each PDF has an ad-hoc path — so hardcoded URLs
are the most reliable approach.
"""
import logging
import re
from urllib.parse import urljoin

import requests
from bs4 import BeautifulSoup

logger = logging.getLogger(__name__)

KEY = "heineken"
NAME = "Heineken N.V."
IR_URL = "https://www.theheinekencompany.com/investors/results-reports-webcasts-presentations"
_BASE = "https://www.theheinekencompany.com"
_AGE_GATE_URL = "https://www.theheinekencompany.com/age-gate/2"

# Verified April 2026. No consistent URL pattern — each year uses a different
# path; update from the IR page if any return 404.
FALLBACK_FILINGS: list[dict] = [
    {
        "title": "Annual Report 2025",
        "url": (
            "https://www.theheinekencompany.com/sites/heineken-corp/files"
            "/2026-02/2025_Heineken_NV_Annual_Report_Interactive_100226_FINAL.pdf"
        ),
        "fiscal_year": 2025,
    },
    {
        "title": "Annual Report 2024",
        "url": (
            "https://www.theheinekencompany.com/sites/heineken-corp/files"
            "/2025-02/heineken_n_v_annual_report_2024_final_20feb2025.pdf"
        ),
        "fiscal_year": 2024,
    },
    {
        "title": "Annual Report 2023",
        "url": (
            "https://www.theheinekencompany.com/sites/heineken-corp/files"
            "/heineken-corp/sustainability-and-responsibility"
            "/heineken-n-v-annual-report-2023-final-22feb24.pdf"
        ),
        "fiscal_year": 2023,
    },
    {
        "title": "Annual Report 2022",
        "url": (
            "https://www.theheinekencompany.com/sites/heineken-corp/files"
            "/heineken-corp/sustainability-and-responsibility/our-progress"
            "/reporting-centre/2023/heineken-nv-annual-report-2022-23-02-2023.pdf"
        ),
        "fiscal_year": 2022,
    },
    {
        "title": "Annual Report 2021",
        "url": (
            "https://www.theheinekencompany.com/sites/heineken-corp/files"
            "/heineken-corp/sustainability-and-responsibility/our-progress"
            "/reporting-centre/2022/heineken-nv-annual-report-2021-25-02-2022.pdf"
        ),
        "fiscal_year": 2021,
    },
    {
        "title": "Annual Report 2020",
        "url": (
            "https://www.theheinekencompany.com/sites/heineken-corp/files"
            "/heineken-corp/investors/governance/agm/2021"
            "/heineken-nv-annual-report-2020.pdf"
        ),
        "fiscal_year": 2020,
    },
    {
        "title": "Annual Report 2019",
        # Official theheinekencompany.com URL for 2019 is no longer active (404).
        # annualreports.com hosts a verified copy of the same filing.
        "url": "https://www.annualreports.com/HostedData/AnnualReportArchive/h/OTC_HEIN_2019.pdf",
        "fiscal_year": 2019,
    },
    {
        "title": "Annual Report 2018",
        "url": (
            "https://www.theheinekencompany.com/sites/heineken-corp/files"
            "/heineken-corp/investors/governance/agm/2019"
            "/heineken-nv-2018-annual-report.pdf"
        ),
        "fiscal_year": 2018,
    },
    {
        "title": "Annual Report 2017",
        "url": (
            "https://www.theheinekencompany.com/sites/heineken-corp/files"
            "/heineken-corp/investors/governance/agm/2018"
            "/heineken-nv-annual-report-2017.pdf"
        ),
        "fiscal_year": 2017,
    },
    {
        "title": "Annual Report 2016",
        "url": (
            "https://www.theheinekencompany.com/sites/heineken-corp/files"
            "/heineken-corp/sustainability-and-responsibility/our-progress"
            "/reporting-centre/2017/heineken-nv-2016-annual-report.pdf"
        ),
        "fiscal_year": 2016,
    },
    {
        "title": "Annual Report 2015",
        "url": (
            "https://www.theheinekencompany.com/sites/heineken-corp/files"
            "/heineken-corp/investors/results-reports-webcasts-presentations"
            "/2016/heineken-nv-full-annual-reportInteractived-0.pdf"
        ),
        "fiscal_year": 2015,
    },
    {
        "title": "Annual Report 2014",
        "url": (
            "https://www.theheinekencompany.com/sites/heineken-corp/files"
            "/heineken-corp/investors/results-reports-webcasts-presentations"
            "/2015/heineken-nv-2014-annual-report.pdf"
        ),
        "fiscal_year": 2014,
    },
]

_YEAR_RE = re.compile(r"\b(20\d{2})\b")
_ANNUAL_SIGNALS = ["annual", "jaarverslag", "jaarrapport"]


def prepare_session(session: requests.Session) -> None:
    """
    Pass the Heineken age gate and store the resulting cookie on *session*.

    All pages and PDFs on theheinekencompany.com are behind an age gate.
    This function must be called once before any requests to the site.
    It is idempotent: if the cookie is already set it returns immediately.
    """
    if session.cookies.get("age_gate_access"):
        return  # already authenticated

    try:
        # Step 1: fetch the gate page to get a fresh form_build_id + cookies
        resp = session.get(_AGE_GATE_URL, timeout=15)
        resp.raise_for_status()
        soup = BeautifulSoup(resp.text, "lxml")

        form_build_id = ""
        tag = soup.find("input", {"name": "form_build_id"})
        if tag:
            form_build_id = tag.get("value", "")

        # Step 2: submit the form as an adult in the Netherlands
        payload = {
            "dob_day": "15",
            "dob_month": "6",
            "dob_year": "1985",
            "country": "NL",
            "op": "Enter",
            "remember_me": "1",
            "cookie_hidden_data": "Replace with cookie default value",
            "form_build_id": form_build_id,
            "form_id": "age_gate_thc_user_form",
        }
        post_resp = session.post(
            _AGE_GATE_URL,
            data=payload,
            headers={"Referer": _AGE_GATE_URL},
            timeout=15,
            allow_redirects=False,
        )
        post_resp.raise_for_status()

        if session.cookies.get("age_gate_access"):
            logger.info("heineken: age gate passed, session authenticated")
        else:
            logger.warning("heineken: age gate POST succeeded but cookie not set")

    except Exception as exc:
        logger.warning(f"heineken: age gate authentication failed ({exc}); downloads may fail")


def discover_filings(session: requests.Session) -> list[dict]:
    """
    Return FilingCandidate dicts for Heineken annual reports.
    Calls prepare_session first, then tries the live scraper.
    Falls back to FALLBACK_FILINGS on any scraper failure.
    """
    prepare_session(session)

    try:
        candidates = _scrape(session)
        if len(candidates) < 2:
            raise ValueError(
                f"scraper returned only {len(candidates)} result(s) — too few"
            )
        logger.info(f"heineken: scraper found {len(candidates)} filing(s)")
        return candidates
    except Exception as exc:
        logger.warning(
            f"heineken: scraper failed ({exc}); "
            f"using {len(FALLBACK_FILINGS)} hardcoded fallback URL(s)"
        )
        return FALLBACK_FILINGS


# ---------------------------------------------------------------------------
# Internal
# ---------------------------------------------------------------------------

def _scrape(session: requests.Session) -> list[dict]:
    resp = session.get(IR_URL, timeout=15)
    resp.raise_for_status()
    soup = BeautifulSoup(resp.text, "lxml")

    candidates: list[dict] = []
    seen: set[str] = set()

    for a in soup.find_all("a", href=True):
        href: str = a["href"]
        if not href.lower().endswith(".pdf"):
            continue

        abs_url = urljoin(_BASE, href)
        link_text = a.get_text(strip=True)
        combined = (abs_url + " " + link_text).lower()

        if not any(sig in combined for sig in _ANNUAL_SIGNALS):
            continue

        if abs_url in seen:
            continue
        seen.add(abs_url)

        title = link_text or _title_from_url(href)
        fiscal_year = _year_from(title) or _year_from(href)
        candidates.append({"title": title, "url": abs_url, "fiscal_year": fiscal_year})

    return candidates


def _title_from_url(url: str) -> str:
    stem = url.rstrip("/").split("/")[-1].replace(".pdf", "")
    return stem.replace("-", " ").replace("_", " ").title()


def _year_from(text: str) -> int | None:
    m = _YEAR_RE.search(text)
    return int(m.group(1)) if m else None
