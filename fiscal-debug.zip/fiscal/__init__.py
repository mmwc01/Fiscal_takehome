"""
fiscal — European public company financial data pipeline.

Pipeline stages:
  1. discover     — scrape IR pages, classify filings
  2. download     — fetch annual report PDFs           [Phase 3]
  3. extract      — parse PDFs → raw tables + items   [Phase 4]
  4. build-views  — aggregate 10-year compiled views  [Phase 5]
  5. export       — write CSV/JSON output             [Phase 6]
"""
import logging

# Library-style null handler so callers can configure logging themselves.
logging.getLogger(__name__).addHandler(logging.NullHandler())
