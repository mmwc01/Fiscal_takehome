"""
PDF report generator. Reads classified_metrics directly so metrics land in the
correct section (Income Statement / Balance Sheet / Cash Flow) by semantic group,
not PDF page location.

Entry point: run_export_pdf(company=None, output_dir="output", db_path=None)
"""
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from reportlab.lib import colors
from reportlab.lib.enums import TA_RIGHT
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import (
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

from fiscal import db
from fiscal.exporter import _fmt_value

logger = logging.getLogger(__name__)

MAX_YEARS          = 6   # show this many of the most-recent years
MIN_POPULATED_YEARS = 2  # drop rows with fewer real values than this

# Map metric_group → section in the PDF
_GROUP_TO_SECTION: dict[str, str] = {
    "revenue":                    "income_statement",
    "cost":                       "income_statement",
    "gross_profit":               "income_statement",
    "operating_expense":          "income_statement",
    "profitability":              "income_statement",
    "tax":                        "income_statement",
    "volume_or_usage":            "income_statement",
    "operating_kpi":              "income_statement",
    "assets":                     "balance_sheet",
    "liabilities":                "balance_sheet",
    "equity":                     "balance_sheet",
    "regulatory_or_capital_kpi":  "balance_sheet",
    "cash_flow_operating":        "cash_flow_statement",
    "cash_flow_investing":        "cash_flow_statement",
    "cash_flow_financing":        "cash_flow_statement",
}

# Ordering within a section (lower = higher on page)
_GROUP_ORDER: dict[str, int] = {
    # Income Statement
    "revenue":           10,
    "cost":              20,
    "gross_profit":      30,
    "operating_expense": 40,
    "profitability":     50,
    "tax":               60,
    "volume_or_usage":   70,
    "operating_kpi":     80,
    # Balance Sheet
    "assets":            10,
    "liabilities":       20,
    "equity":            30,
    "regulatory_or_capital_kpi": 40,
    # Cash Flow
    "cash_flow_operating":  10,
    "cash_flow_investing":  20,
    "cash_flow_financing":  30,
}

SECTION_LABEL = {
    "income_statement":    "Income Statement",
    "balance_sheet":       "Balance Sheet",
    "cash_flow_statement": "Cash Flow Statement",
}

SECTION_ORDER = ["income_statement", "balance_sheet", "cash_flow_statement"]

# Fiscal year-end date per company (month abbreviation + day).
# All three tracked companies close December 31.
# Add entries here if a new company has a different year-end.
_FISCAL_YEAR_END: dict[str, str] = {}   # company → "Mon DD", empty = use default
_DEFAULT_YEAR_END = "Dec 31"


def _col_header(company: str, year: int) -> str:
    """Return 'Dec 31, 2024 (12 Months)' style column header text."""
    month_day = _FISCAL_YEAR_END.get(company, _DEFAULT_YEAR_END)
    return f"{month_day}, {year} (12 Months)"


_COL_HEADER_BG = colors.HexColor("#F2F2F2")
_SECTION_BG    = colors.HexColor("#E8E8E8")
_TITLE_COLOR   = colors.HexColor("#1A1A2E")
_GRID_COLOR    = colors.HexColor("#CCCCCC")
_TEXT_COLOR    = colors.black
_DASH_COLOR    = colors.HexColor("#BBBBBB")
_MUTED_COLOR   = colors.HexColor("#888888")


def run_export_pdf(
    company: Optional[str] = None,
    output_dir: str = "output",
    db_path: Optional[Path] = None,
) -> dict[str, list[str]]:
    """Generate one PDF per company. Returns {"written": [paths]}."""
    db_path = db_path or db.DB_PATH
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)

    written: list[str] = []

    with db.get_connection(db_path) as conn:
        if company:
            companies = [company]
        else:
            rows = conn.execute(
                "SELECT DISTINCT company FROM classified_metrics "
                "WHERE classification_method != 'unclassified' ORDER BY company"
            ).fetchall()
            companies = [r[0] for r in rows]

        for co in companies:
            rows_by_section = _fetch_rows(conn, co)
            path = out / f"{co}_report.pdf"
            _build_pdf(path, co, rows_by_section)
            written.append(str(path))
            logger.info(f"PDF written: {path}")

    return {"written": written}


def _fetch_rows(conn, company: str) -> dict[str, list[dict]]:
    # Anchor the field list to the most recent report, then back-fill historical
    # values for those same fields. This prevents orphan rows (metrics that only
    # appear in 1–2 random years due to label drift across filings).
    sql = """
    WITH
    latest_report AS (
        SELECT MAX(report_year) AS yr
        FROM  classified_metrics
        WHERE company                = ?
          AND classification_method != 'unclassified'
          AND metric_group NOT IN ('non_metric', 'unclassified_financial')
    ),
    anchor AS (
        SELECT DISTINCT metric_group, display_label
        FROM  classified_metrics
        WHERE company                = ?
          AND report_year            = (SELECT yr FROM latest_report)
          AND classification_method != 'unclassified'
          AND metric_group NOT IN ('non_metric', 'unclassified_financial')
          AND period_year            IS NOT NULL
          AND parsed_value           IS NOT NULL
    ),
    best AS (
        SELECT
            a.metric_group,
            a.display_label         AS label,
            cm.period_year,
            cm.parsed_value         AS value,
            ROW_NUMBER() OVER (
                PARTITION BY cm.company, a.display_label, cm.period_year
                ORDER BY
                    CASE WHEN cm.report_year = cm.period_year THEN 0 ELSE 1 END,
                    cm.report_year ASC
            ) AS rn
        FROM  classified_metrics cm
        JOIN  anchor a
          ON  LOWER(TRIM(a.display_label)) = LOWER(TRIM(cm.display_label))
          AND (   a.metric_group = cm.metric_group
               OR cm.metric_group = 'unclassified_financial')
        WHERE cm.company                = ?
          AND cm.metric_group NOT IN ('non_metric')
          AND cm.period_year            IS NOT NULL
          AND cm.parsed_value           IS NOT NULL
          AND cm.report_year            >= cm.period_year
    )
    SELECT metric_group, label, period_year, value
    FROM   best
    WHERE  rn = 1
    ORDER  BY metric_group, label, period_year
    """
    raw = [dict(r) for r in conn.execute(sql, (company, company, company)).fetchall()]

    # Group by section
    by_section: dict[str, list[dict]] = {s: [] for s in SECTION_ORDER}
    for row in raw:
        section = _GROUP_TO_SECTION.get(row["metric_group"])
        if section:
            by_section[section].append(row)

    return by_section


def _build_pdf(
    path: Path,
    company: str,
    rows_by_section: dict[str, list[dict]],
) -> None:
    title_style = ParagraphStyle(
        "FT", fontSize=14, leading=18,
        textColor=_TITLE_COLOR, fontName="Helvetica-Bold", spaceAfter=2 * mm,
    )
    sub_style = ParagraphStyle(
        "FS", fontSize=8, leading=11,
        textColor=_MUTED_COLOR, fontName="Helvetica", spaceAfter=6 * mm,
    )

    doc = SimpleDocTemplate(
        str(path), pagesize=landscape(A4),
        leftMargin=12 * mm, rightMargin=12 * mm,
        topMargin=12 * mm,  bottomMargin=12 * mm,
        title=f"Fiscal Report — {company.title()}", author="Fiscal Pipeline",
    )

    # Global year list — newest → oldest, capped at MAX_YEARS
    all_rows = [r for rows in rows_by_section.values() for r in rows]
    years: list[int] = sorted(
        {r["period_year"] for r in all_rows}, reverse=True
    )[:MAX_YEARS]

    generated = datetime.now(timezone.utc).strftime("%B %d, %Y")
    story = [
        Paragraph(f"Financial Report — {company.title()}", title_style),
        Paragraph(f"Generated {generated}  ·  Fiscal Pipeline", sub_style),
    ]

    for section in SECTION_ORDER:
        section_rows = rows_by_section.get(section, [])
        if not section_rows:
            continue

        pivoted = _pivot(section_rows, years)
        if not pivoted:
            continue

        story.append(Spacer(1, 5 * mm))
        story.append(_build_table(SECTION_LABEL[section], pivoted, years, company))

    doc.build(story)


def _pivot(rows: list[dict], years: list[int]) -> list[dict]:
    by_label: dict[str, dict] = {}
    for r in rows:
        key = r["label"]
        if key not in by_label:
            by_label[key] = {"label": key, "metric_group": r["metric_group"]}
        by_label[key][r["period_year"]] = r["value"]

    ordered = sorted(
        by_label.values(),
        key=lambda d: (_GROUP_ORDER.get(d["metric_group"], 999), d["label"]),
    )

    result = []
    for row in ordered:
        row = _scrub_note_refs(row, years)
        populated = sum(1 for y in years if row.get(y) is not None)
        if populated >= MIN_POPULATED_YEARS:
            result.append(row)

    return result


def _scrub_note_refs(row: dict, years: list[int]) -> dict:
    year_vals = [(y, row[y]) for y in years if row.get(y) is not None]
    if not year_vals:
        return row

    max_abs = max(abs(v) for _, v in year_vals)
    if max_abs < 1_000:
        return row

    cleaned = dict(row)
    for y, v in year_vals:
        if abs(v) < 100:
            cleaned[y] = None
    return cleaned


def _build_table(
    label: str,
    pivoted: list[dict],
    years: list[int],
    company: str = "",
) -> Table:
    page_w      = landscape(A4)[0] - 24 * mm
    label_col_w = page_w * 0.32
    yr_col_w    = (page_w - label_col_w) / max(len(years), 1)
    col_widths  = [label_col_w] + [yr_col_w] * len(years)

    header_row     = [label] + [""] * len(years)
    col_header_row = [""] + [_col_header(company, y) for y in years]

    data_rows  = []
    dash_cells = []
    for ri, row in enumerate(pivoted, start=2):
        vals = [_fmt_value(row.get(y)) for y in years]
        data_rows.append([row["label"]] + vals)
        for ci, v in enumerate(vals, start=1):
            if v == "–":
                dash_cells.append((ci, ri))

    all_rows = [header_row, col_header_row] + data_rows
    tbl      = Table(all_rows, colWidths=col_widths, repeatRows=2)

    style = [
        # Section title row (0)
        ("SPAN",          (0, 0), (-1, 0)),
        ("BACKGROUND",    (0, 0), (-1, 0), _SECTION_BG),
        ("FONTNAME",      (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE",      (0, 0), (-1, 0), 8.5),
        ("TEXTCOLOR",     (0, 0), (-1, 0), _TITLE_COLOR),
        ("ALIGN",         (0, 0), (-1, 0), "LEFT"),
        ("LEFTPADDING",   (0, 0), (-1, 0), 5),
        ("TOPPADDING",    (0, 0), (-1, 0), 5),
        ("BOTTOMPADDING", (0, 0), (-1, 0), 5),
        ("LINEBELOW",     (0, 0), (-1, 0), 0.5, _GRID_COLOR),

        # Column header row (1)
        ("BACKGROUND",    (0, 1), (-1, 1), _COL_HEADER_BG),
        ("FONTNAME",      (0, 1), (-1, 1), "Helvetica-Bold"),
        ("FONTSIZE",      (0, 1), (-1, 1), 6.5),
        ("ALIGN",         (1, 1), (-1, 1), "RIGHT"),
        ("ALIGN",         (0, 1), (0,  1), "LEFT"),
        ("TOPPADDING",    (0, 1), (-1, 1), 4),
        ("BOTTOMPADDING", (0, 1), (-1, 1), 4),
        ("LINEBELOW",     (0, 1), (-1, 1), 0.75, _GRID_COLOR),

        # Data rows (2+)
        ("FONTNAME",      (0, 2), (-1, -1), "Helvetica"),
        ("FONTSIZE",      (0, 2), (-1, -1), 7.5),
        ("ALIGN",         (1, 2), (-1, -1), "RIGHT"),
        ("ALIGN",         (0, 2), (0,  -1), "LEFT"),
        ("LEFTPADDING",   (0, 2), (0,  -1), 10),
        ("TOPPADDING",    (0, 2), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 2), (-1, -1), 3),
        ("TEXTCOLOR",     (0, 2), (-1, -1), _TEXT_COLOR),
        ("ROWBACKGROUNDS", (0, 2), (-1, -1),
         [colors.white, colors.HexColor("#FAFAFA")]),
        ("LINEBELOW",     (0, -1), (-1, -1), 0.5, _GRID_COLOR),
    ]

    for col, row_idx in dash_cells:
        style.append(("TEXTCOLOR", (col, row_idx), (col, row_idx), _DASH_COLOR))

    tbl.setStyle(TableStyle(style))
    return tbl
