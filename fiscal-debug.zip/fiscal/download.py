"""
Download pipeline: fetches annual report PDFs and stores them locally.

Only operates on filings where document_type = 'annual_report'.

Skip rule
---------
If the destination file already exists AND its SHA256 matches the stored
checksum, the file is skipped. This makes the command safe to re-run.

File layout
-----------
PDFs are saved to: <db_dir>/pdfs/<company>/<safe_filename>.pdf
  e.g.  data/pdfs/adyen/adyen-annual-report-2023.pdf

The db_dir is derived from db_path so tests can use a tmp directory without
any monkey-patching of paths.

Error handling
--------------
A per-filing failure (HTTP error, connection error, disk error) is logged
and the pipeline continues to the next filing. The filing status is NOT
updated on failure so a re-run will attempt it again.
"""
import hashlib
import logging
import re
import time
from datetime import datetime, timezone
from pathlib import Path

import requests

from fiscal import db
from fiscal.companies import REGISTRY

logger = logging.getLogger(__name__)

_CHUNK = 8_192  # streaming download chunk size in bytes


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def run_download(
    company: str | None = None,
    db_path: Path | None = None,
    rate_limit_secs: float = 1.0,
) -> dict[str, int]:
    """
    Download all annual report PDFs that have not yet been downloaded.

    Args:
        company:         restrict to one company key, or None for all
        db_path:         override DB location (defaults to db.DB_PATH)
        rate_limit_secs: sleep between requests to be polite (default 1 s)

    Returns:
        {"downloaded": N, "skipped": N, "failed": N}
    """
    db_path = db_path or db.DB_PATH
    pdfs_root = db_path.parent / "pdfs"

    with db.get_connection(db_path) as conn:
        filings = db.get_filings(conn, company=company, document_type="annual_report")

    if not filings:
        logger.info("No annual_report filings found — run `fiscal discover` first.")
        return {"downloaded": 0, "skipped": 0, "failed": 0}

    counts: dict[str, int] = {"downloaded": 0, "skipped": 0, "failed": 0}
    session = _make_session()

    # Group by company so prepare_session is called once per company
    by_company: dict[str, list[dict]] = {}
    for f in filings:
        by_company.setdefault(f["company"], []).append(f)

    all_filings_ordered: list[dict] = []
    for co_key, co_filings in by_company.items():
        module = REGISTRY.get(co_key)
        if module and hasattr(module, "prepare_session"):
            logger.info(f"[{co_key}] Setting up session (authentication)")
            module.prepare_session(session)
        all_filings_ordered.extend(co_filings)

    for i, filing in enumerate(all_filings_ordered):
        _process_filing(filing, session, pdfs_root, db_path, counts)
        # Rate-limit between requests; skip the pause after the last one
        if rate_limit_secs > 0 and i < len(all_filings_ordered) - 1:
            time.sleep(rate_limit_secs)

    logger.info(
        f"Download complete: "
        f"{counts['downloaded']} downloaded, "
        f"{counts['skipped']} skipped, "
        f"{counts['failed']} failed."
    )
    return counts


# ---------------------------------------------------------------------------
# Per-filing logic
# ---------------------------------------------------------------------------

def _process_filing(
    filing: dict,
    session: requests.Session,
    pdfs_root: Path,
    db_path: Path,
    counts: dict[str, int],
) -> None:
    dest = _dest_path(filing, pdfs_root)

    # Skip if already downloaded with a matching checksum
    if dest.exists() and filing.get("sha256"):
        if _compute_sha256(dest) == filing["sha256"]:
            logger.info(
                f"[{filing['company']}] SKIP  {dest.name}  (exists, checksum matches)"
            )
            counts["skipped"] += 1
            return

    logger.info(f"[{filing['company']}] GET   {filing['url']}")
    try:
        _download_file(filing, session, dest, db_path)
        counts["downloaded"] += 1
    except requests.HTTPError as exc:
        logger.error(
            f"[{filing['company']}] FAIL  {filing['url']}  "
            f"— HTTP {exc.response.status_code if exc.response is not None else '?'}"
        )
        counts["failed"] += 1
    except requests.RequestException as exc:
        logger.error(f"[{filing['company']}] FAIL  {filing['url']}  — {exc}")
        counts["failed"] += 1
    except OSError as exc:
        logger.error(
            f"[{filing['company']}] FAIL  {dest}  — disk error: {exc}"
        )
        counts["failed"] += 1


def _download_file(
    filing: dict,
    session: requests.Session,
    dest: Path,
    db_path: Path,
) -> None:
    """
    Stream the PDF to a temp file, then rename atomically.
    Computes SHA256 during the download pass so we don't read the file twice.
    """
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix(".tmp")

    hasher = hashlib.sha256()
    size = 0

    resp = session.get(filing["url"], stream=True, timeout=30)
    resp.raise_for_status()

    content_type = resp.headers.get("Content-Type", "").lower()

    if "pdf" not in content_type:
        logger.error(
            f"[{filing['company']}] FAIL  {filing['url']}  "
            f"— not a PDF (Content-Type: {content_type})"
        )
        resp.close()
        raise requests.RequestException("Not a PDF response")

    try:
        with tmp.open("wb") as fh:
            for chunk in resp.iter_content(chunk_size=_CHUNK):
                if chunk:
                    fh.write(chunk)
                    hasher.update(chunk)
                    size += len(chunk)
    except Exception:
        tmp.unlink(missing_ok=True)
        raise

    tmp.rename(dest)  # atomic on POSIX; best-effort on Windows

    sha256 = hasher.hexdigest()
    logger.info(
        f"[{filing['company']}] OK    {dest.name}  "
        f"({size / 1_048_576:.1f} MB, sha256={sha256[:12]}…)"
    )

    with db.get_connection(db_path) as conn:
        db.update_filing(
            conn,
            filing["id"],
            local_path=str(dest.resolve()),
            file_size_bytes=size,
            sha256=sha256,
            downloaded_at=_utcnow(),
            status="downloaded",
        )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _dest_path(filing: dict, pdfs_root: Path) -> Path:
    return pdfs_root / filing["company"] / _safe_filename(filing)


def _safe_filename(filing: dict) -> str:
    """
    Derive a filesystem-safe filename from the filing URL.
    Falls back to title if the URL basename is not useful.
    Sanitizes to [a-z0-9_.-] and enforces .pdf extension.
    """
    url_basename = filing["url"].rstrip("/").split("/")[-1]
    if url_basename.lower().endswith(".pdf") and len(url_basename) > 8:
        name = url_basename
    else:
        title = filing.get("title") or (
            f"{filing['company']}-{filing.get('fiscal_year', 'unknown')}"
        )
        name = title.lower().replace(" ", "-") + ".pdf"

    # Keep only safe characters; collapse repeated underscores/dashes
    name = re.sub(r"[^\w.\-]", "_", name)
    name = re.sub(r"_+", "_", name)
    return name[:200]  # guard against absurdly long filenames


def _compute_sha256(path: Path) -> str:
    hasher = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(_CHUNK), b""):
            hasher.update(chunk)
    return hasher.hexdigest()


def _make_session() -> requests.Session:
    session = requests.Session()
    session.headers.update({
        "User-Agent": (
            "fiscal/0.1 financial-research-tool "
            "(educational use; contact: see project README)"
        )
    })
    return session


def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()
