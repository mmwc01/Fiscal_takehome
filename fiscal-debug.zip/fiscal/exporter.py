"""
Exporter: writes compiled_views and filings to CSV and JSON under output/.

Output files
------------
  output/{company}.csv / .json   (all 3 statement types combined, one file per company)
  output/filings_inventory.csv
  output/filings_inventory.json

Compiled-view format (wide pivot)
----------------------------------
Rows  = section headers + unique labels (raw_label)
Cols  = period_year values, sorted descending
Values = parsed numeric value (or empty string if absent)

Example:
  label                  | 2024  | 2023  | 2022  | ...
  === Income Statement ===|       |       |       |
  Revenue                | 2831  | 2960  | 3451  | ...
  Gross profit           |  ...  |  ...  |  ...  | ...
  === Balance Sheet ===   |       |       |       |
  ...

Entry point
-----------
    run_export(company, fmt, output_dir, db_path) -> dict[str, list[str]]
        Returns {"written": [list of file paths]}.
"""
import csv
import json
import logging
from pathlib import Path
from typing import Optional

from fiscal import db

logger = logging.getLogger(__name__)

STATEMENT_TYPES = ["income_statement", "balance_sheet", "cash_flow_statement"]


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def run_export(
    company: Optional[str] = None,
    fmt: str = "both",
    output_dir: str = "output",
    db_path: Optional[Path] = None,
) -> dict[str, list[str]]:
    """
    Export compiled_views (pivoted) and filings inventory.

    Parameters
    ----------
    company    : restrict to one company key, or None for all
    fmt        : "csv" | "json" | "both"
    output_dir : directory to write files into (created if absent)
    db_path    : override for the DB path

    Returns {"written": [list of absolute file path strings]}.
    """
    db_path = db_path or db.DB_PATH
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)

    written: list[str] = []

    with db.get_connection(db_path) as conn:
        companies = _get_companies(conn, company)
        all_views = _fetch_compiled_views(conn, company)
        all_filings = _fetch_filings(conn, company)
        # Load any label mappings that exist
        all_mappings: dict[tuple, dict] = {}
        for co in companies:
            for stmt in STATEMENT_TYPES:
                m = db.get_label_mappings(conn, co, stmt)
                if m:
                    all_mappings[(co, stmt)] = m

    # ---- one consolidated file per company ----
    SECTION_LABELS = {
        "income_statement": "Income Statement",
        "balance_sheet": "Balance Sheet",
        "cash_flow_statement": "Cash Flow Statement",
    }

    for co in companies:
        # Collect all years across all statements for this company so columns align
        all_years: list[int] = sorted(
            {r["period_year"] for r in all_views if r["company"] == co},
            reverse=True,
        )
        if not all_years:
            continue

        combined_rows: list[dict] = []
        combined_json: list[dict] = []

        for stmt in STATEMENT_TYPES:
            rows = [r for r in all_views
                    if r["company"] == co and r["statement_type"] == stmt]
            if not rows:
                continue

            mappings = all_mappings.get((co, stmt))
            pivoted, _ = _pivot(rows, mappings)

            # Section header row
            combined_rows.append({"_section": SECTION_LABELS[stmt]})
            combined_json.append({"section": SECTION_LABELS[stmt]})

            combined_rows.extend(pivoted)
            combined_json.extend(pivoted)

        if fmt in ("csv", "both"):
            path = out / f"{co}.csv"
            _write_combined_csv(path, combined_rows, all_years)
            written.append(str(path))
            logger.info(f"Wrote {path}")

        if fmt in ("json", "both"):
            path = out / f"{co}.json"
            _write_json_pivot(path, combined_json, all_years)
            written.append(str(path))
            logger.info(f"Wrote {path}")

    # ---- filings inventory ----
    filings_base = f"{company}_filings_inventory" if company else "filings_inventory"
    if fmt in ("csv", "both"):
        path = out / f"{filings_base}.csv"
        _write_filings_csv(path, all_filings)
        written.append(str(path))
        logger.info(f"Wrote {path}")

    if fmt in ("json", "both"):
        path = out / f"{filings_base}.json"
        _write_filings_json(path, all_filings)
        written.append(str(path))
        logger.info(f"Wrote {path}")

    return {"written": written}


# ---------------------------------------------------------------------------
# Pivot helpers
# ---------------------------------------------------------------------------

def _fmt_value(v: float | None) -> str:
    """Format a numeric value with thousands separators, no trailing .0."""
    if v is None:
        return "–"
    if v == int(v):
        return f"{int(v):,}"
    return f"{v:,.1f}"


def _pivot(
    rows: list[dict],
    mappings: dict[str, dict] | None = None,
) -> tuple[list[dict], list[int]]:
    """
    Convert flat compiled_view rows into a wide-format list of dicts.

    If mappings is provided (from label_mappings table), rows tagged
    include=False are dropped and remaining rows are grouped under their
    canonical_label, then sorted by sort_order.

    Returns (pivoted_rows, sorted_years_descending).
    """
    years: list[int] = sorted({r["period_year"] for r in rows}, reverse=True)

    # Group by canonical label (or raw label if no mapping)
    by_label: dict[str, dict] = {}   # canonical_label -> {year: value, _sort_order: int}

    for r in rows:
        raw  = r["label"]
        m    = mappings.get(raw) if mappings else None

        if m and not m["include"]:
            continue

        canon      = m["canonical_label"] if m else raw
        sort_order = m["sort_order"]      if m else 999

        entry = by_label.setdefault(canon, {"_sort_order": sort_order})
        entry[r["period_year"]] = r["value"]

    # Sort by sort_order, then canonical label for stability
    ordered = sorted(
        by_label.items(),
        key=lambda kv: (kv[1].get("_sort_order", 999), kv[0]),
    )

    pivoted = [
        {"label": label, **{k: v for k, v in year_values.items() if k != "_sort_order"}}
        for label, year_values in ordered
    ]
    return pivoted, years


# ---------------------------------------------------------------------------
# CSV writers
# ---------------------------------------------------------------------------

def _write_csv(path: Path, pivoted: list[dict], years: list[int]) -> None:
    fieldnames = ["label"] + [str(y) for y in years]
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        for row in pivoted:
            out_row: dict = {"label": row["label"]}
            for y in years:
                out_row[str(y)] = _fmt_value(row.get(y))
            writer.writerow(out_row)


def _write_combined_csv(path: Path, rows: list[dict], years: list[int]) -> None:
    """Write a combined multi-statement CSV with section header rows."""
    fieldnames = ["label"] + [str(y) for y in years]
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            if "_section" in row:
                # Section header: write the name in the label column, blanks elsewhere
                writer.writerow({"label": f"=== {row['_section']} ==="})
            else:
                out_row: dict = {"label": row["label"]}
                for y in years:
                    out_row[str(y)] = _fmt_value(row.get(y))
                writer.writerow(out_row)


def _write_filings_csv(path: Path, filings: list[dict]) -> None:
    if not filings:
        path.write_text("")
        return
    fieldnames = list(filings[0].keys())
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(filings)


# ---------------------------------------------------------------------------
# JSON writers
# ---------------------------------------------------------------------------

def _write_json_pivot(path: Path, pivoted: list[dict], years: list[int]) -> None:
    """Write as a list of objects: [{label, year: value, ...}, ...]
    Section header rows (containing a 'section' key) are passed through as-is.
    """
    output = []
    for row in pivoted:
        if "section" in row:
            output.append({"section": row["section"]})
            continue
        obj: dict = {"label": row["label"]}
        for y in years:
            obj[str(y)] = row.get(y)  # None where absent (raw float, not formatted)
        output.append(obj)
    path.write_text(json.dumps(output, indent=2, ensure_ascii=False), encoding="utf-8")


def _write_filings_json(path: Path, filings: list[dict]) -> None:
    path.write_text(json.dumps(filings, indent=2, ensure_ascii=False, default=str),
                    encoding="utf-8")


# ---------------------------------------------------------------------------
# DB fetch helpers
# ---------------------------------------------------------------------------

def _get_companies(conn, company: Optional[str]) -> list[str]:
    if company:
        return [company]
    rows = conn.execute(
        "SELECT DISTINCT company FROM compiled_views ORDER BY company"
    ).fetchall()
    return [r[0] for r in rows]


def _fetch_compiled_views(conn, company: Optional[str]) -> list[dict]:
    sql = (
        "SELECT company, statement_type, label, period_year, value "
        "FROM compiled_views "
    )
    params: list = []
    if company:
        sql += "WHERE company = ? "
        params.append(company)
    sql += "ORDER BY company, statement_type, label, period_year"
    return [dict(r) for r in conn.execute(sql, params).fetchall()]


def _fetch_filings(conn, company: Optional[str]) -> list[dict]:
    sql = "SELECT * FROM filings "
    params: list = []
    if company:
        sql += "WHERE company = ? "
        params.append(company)
    sql += "ORDER BY company, fiscal_year DESC"
    return [dict(r) for r in conn.execute(sql, params).fetchall()]
