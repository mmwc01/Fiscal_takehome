"""
Builds compiled_views from raw_line_items, using classified_metrics when available.

Deduplication rule: prefer the row where report_year == period_year; fall back to
the earliest later filing. compiled_views is fully rebuilt on each run.
"""
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from fiscal import db

logger = logging.getLogger(__name__)


def run_build_views(
    db_path: Optional[Path] = None,
) -> dict[str, int]:
    """Rebuild compiled_views. Returns {"rows_written": N}."""
    db_path = db_path or db.DB_PATH
    built_at = datetime.now(timezone.utc).isoformat()

    rows = _select_preferred_rows(db_path)

    with db.get_connection(db_path) as conn:
        conn.execute("DELETE FROM compiled_views")
        conn.executemany(
            """
            INSERT INTO compiled_views
                (company, statement_type, label, period_year,
                 value, unit, currency, source_report_year, source_filing_id, built_at)
            VALUES
                (:company, :statement_type, :label, :period_year,
                 :value, :unit, :currency, :source_report_year, :source_filing_id, :built_at)
            """,
            [{**r, "built_at": built_at} for r in rows],
        )

    logger.info(f"compiled_views rebuilt: {len(rows)} row(s) written.")
    return {"rows_written": len(rows)}


def _companies_with_classifications(db_path: Path) -> set[str]:
    try:
        with db.get_connection(db_path) as conn:
            rows = conn.execute(
                "SELECT DISTINCT company FROM classified_metrics"
            ).fetchall()
        return {r["company"] for r in rows}
    except Exception:
        return set()


def _select_preferred_rows(db_path: Path) -> list[dict]:
    classified_companies = _companies_with_classifications(db_path)

    with db.get_connection(db_path) as conn:
        all_companies = [
            r["company"]
            for r in conn.execute(
                "SELECT DISTINCT company FROM raw_line_items ORDER BY company"
            ).fetchall()
        ]

    all_rows: list[dict] = []
    for co in all_companies:
        if co in classified_companies:
            all_rows.extend(_classified_path(db_path, co))
        else:
            all_rows.extend(_raw_path(db_path, co))

    return all_rows


def _raw_path(db_path: Path, company: str) -> list[dict]:
    sql = """
    WITH ranked AS (
        SELECT
            rli.company,
            rli.statement_type,
            rli.raw_label                       AS label,
            rli.period_year,
            rli.parsed_value                    AS value,
            rli.unit,
            rli.currency,
            rli.report_year                     AS source_report_year,
            rli.filing_id                       AS source_filing_id,
            ROW_NUMBER() OVER (
                PARTITION BY
                    rli.company,
                    rli.statement_type,
                    rli.raw_label,
                    rli.period_year
                ORDER BY
                    CASE WHEN rli.report_year = rli.period_year THEN 0 ELSE 1 END,
                    rli.report_year ASC
            ) AS rn
        FROM raw_line_items rli
        WHERE rli.company       = ?
          AND rli.period_year   IS NOT NULL
          AND rli.parsed_value  IS NOT NULL
          AND rli.report_year   >= rli.period_year
    )
    SELECT company, statement_type, label, period_year,
           value, unit, currency, source_report_year, source_filing_id
    FROM   ranked
    WHERE  rn = 1
    ORDER  BY company, statement_type, label, period_year
    """
    with db.get_connection(db_path) as conn:
        rows = conn.execute(sql, (company,)).fetchall()
    return [dict(r) for r in rows]


def _classified_path(db_path: Path, company: str) -> list[dict]:
    sql = """
    WITH
    classified AS (
        SELECT
            cm.company,
            cm.statement_type,
            cm.metric_key                       AS dedup_key,
            cm.display_label                    AS label,
            cm.period_year,
            cm.parsed_value                     AS value,
            rli.unit,
            rli.currency,
            cm.report_year                      AS source_report_year,
            rli.filing_id                       AS source_filing_id,
            ROW_NUMBER() OVER (
                PARTITION BY
                    cm.company,
                    cm.statement_type,
                    cm.metric_key,
                    cm.period_year
                ORDER BY
                    CASE WHEN cm.report_year = cm.period_year THEN 0 ELSE 1 END,
                    cm.report_year ASC
            ) AS rn
        FROM  classified_metrics cm
        JOIN  raw_line_items rli ON rli.id = cm.raw_line_item_id
        WHERE cm.company                  = ?
          AND cm.classification_method   != 'unclassified'
          AND cm.period_year              IS NOT NULL
          AND cm.parsed_value             IS NOT NULL
          AND cm.report_year              >= cm.period_year
    ),
    unclassified AS (
        SELECT
            cm.company,
            cm.statement_type,
            cm.raw_label                        AS dedup_key,
            cm.raw_label                        AS label,
            cm.period_year,
            cm.parsed_value                     AS value,
            rli.unit,
            rli.currency,
            cm.report_year                      AS source_report_year,
            rli.filing_id                       AS source_filing_id,
            ROW_NUMBER() OVER (
                PARTITION BY
                    cm.company,
                    cm.statement_type,
                    cm.raw_label,
                    cm.period_year
                ORDER BY
                    CASE WHEN cm.report_year = cm.period_year THEN 0 ELSE 1 END,
                    cm.report_year ASC
            ) AS rn
        FROM  classified_metrics cm
        JOIN  raw_line_items rli ON rli.id = cm.raw_line_item_id
        WHERE cm.company                  = ?
          AND cm.classification_method    = 'unclassified'
          AND cm.period_year              IS NOT NULL
          AND cm.parsed_value             IS NOT NULL
          AND cm.report_year              >= cm.period_year
    ),
    merged AS (
        SELECT company, statement_type, label, period_year,
               value, unit, currency, source_report_year, source_filing_id,
               ROW_NUMBER() OVER (
                   PARTITION BY company, statement_type, label, period_year
                   ORDER BY 1
               ) AS rn2
        FROM (
            SELECT company, statement_type, label, period_year,
                   value, unit, currency, source_report_year, source_filing_id
            FROM   classified  WHERE rn = 1
            UNION ALL
            SELECT company, statement_type, label, period_year,
                   value, unit, currency, source_report_year, source_filing_id
            FROM   unclassified WHERE rn = 1
        )
    )

    SELECT company, statement_type, label, period_year,
           value, unit, currency, source_report_year, source_filing_id
    FROM   merged
    WHERE  rn2 = 1
    ORDER  BY company, statement_type, label, period_year
    """
    with db.get_connection(db_path) as conn:
        rows = conn.execute(sql, (company, company)).fetchall()
    return [dict(r) for r in rows]
