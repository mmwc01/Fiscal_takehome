"""
Metric classifier: assigns metric_group, metric_key, and display_label to
each raw_line_item row.

Five classification layers are tried in order; the highest-scoring candidate
wins. Layers 1–3 use regex/exact rules (scores 0.7–1.0); layer 4 uses token
overlap as a fallback (scores 0.1–0.65). Unmatched rows are filed as
unclassified_financial (real metric, no rule coverage) or non_metric (junk).

Hybrid mode:
- deterministic rules run first
- LLM fallback is only used for weak / unresolved rows
"""
from __future__ import annotations

import logging
import os
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from fiscal import db
from fiscal.llm.adjudicator import should_accept_llm
from fiscal.llm.client import LLMClient
from fiscal.llm.metric_mapper import map_metric_with_llm
from fiscal.llm.missing_field_recovery import run_missing_field_recovery
from fiscal.metrics_rules import (
    COMPANY_OVERRIDES,
    COMPANY_TO_INDUSTRY,
    GENERIC_HEURISTIC_RULES,
    INDUSTRY_EXACT_RULES,
    INDUSTRY_PATTERN_RULES,
)

logger = logging.getLogger(__name__)


# Unit/currency annotations: (in millions of €), (€m), ($bn), (in %), (%)
_UNIT_RE = re.compile(
    r"\(\s*in\s+(?:millions?|billions?|thousands?)[^)]*\)"
    r"|\(\s*(?:€|US\$|\$|£|¥|CHF|AED|SEK|NOK|DKK)\s*(?:m|mn|mm|bn|k|tn)?\s*\)"
    r"|\(\s*in\s*%\s*\)"
    r"|\(\s*%\s*\)",
    re.IGNORECASE,
)

# Leading extraction artifacts: "25,811 Cash flow…" → "Cash flow…"
_LEADING_NUM_RE = re.compile(r"^\s*[\d,\.]+\s+")

# Parenthetical qualifiers only — safe subset, won't accidentally strip "total"
_QUALIFIER_RE = re.compile(
    r"\s*\(\s*(?:beia|adjusted|adj|underlying|reported|restated|"
    r"normalized|normalised|organic|excl[^)]*|incl[^)]*|constant[^)]*|"
    r"pro\s+forma|as\s+reported|at\s+constant[^)]*)\s*\)",
    re.IGNORECASE,
)

# Trailing footnote markers: ¹, ², ³, ⁴–⁹, or bare digits at end
_FOOTNOTE_RE = re.compile(r"\s*[\u00b9\u00b2\u00b3\u2070-\u2079]+$|\s*\d+\s*$")


def normalize_label(raw_label: str) -> str:
    """Lowercase, strip units/qualifiers/footnotes, collapse whitespace."""
    s = raw_label.strip()
    s = _UNIT_RE.sub("", s)
    s = _LEADING_NUM_RE.sub("", s)
    s = _QUALIFIER_RE.sub("", s)
    s = _FOOTNOTE_RE.sub("", s)
    s = re.sub(r"^[\-–—•·\s]+", "", s)
    s = s.lower()
    s = re.sub(r"/\(", " ", s)
    s = re.sub(r"[\\/\(\)\[\]{}]", " ", s)
    s = re.sub(r"\brevenues\b", "revenue", s)
    s = re.sub(r"[^\w\s]", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s


def _score_to_confidence(score: float) -> str:
    if score >= 0.9:
        return "high"
    if score >= 0.6:
        return "medium"
    return "low"


@dataclass(frozen=True)
class ClassificationResult:
    industry_family: str
    metric_group: str
    metric_key: str
    display_label: str
    classification_confidence: str  # high | medium | low
    classification_method: str
    classification_score: float = 0.0
    matched_pattern: str = field(default="")


# Terms whose presence in the lowercased label disqualifies a row from LLM fallback.
# Includes contact/location metadata and non-financial disclosure vocabulary that
# cannot map to any canonical metric group.
_LLM_SKIP_TERMS: frozenset[str] = frozenset({
    # Contact / address / location
    "office", "sales office", "support office", "address", "addresses",
    "contact", "contacts", "website", "email", "city", "country",
    "headquarters", "registered office", "phone", "fax",
    "location", "locations", "region", "regions", "geography", "geographies",
    # ESG / sustainability / disclosure rows
    "greenhouse gas", "ghg", "co2", "carbon dioxide",
    "sustainability", "sustainable", "esg", "csr",
    "social responsibility", "biodiversity", "water usage",
    "waste", "scope 1", "scope 2", "scope 3",
    "category 1", "category 2", "category 3", "category 4",
    # Note / policy / taxonomy metadata
    "accounting policy", "basis of preparation",
    "basis of consolidation", "see note", "refer to note",
    "reporting framework", "assurance statement",
})

# Regex gate for scope/category rows and disclosure boilerplate not easily
# caught by substring matching alone.
_LLM_SKIP_RE: re.Pattern = re.compile(
    r"\bscope\s+[1-3]\b"
    r"|\bcategory\s+\d+\b"
    r"|\b(?:ghg|co2e?)\b"
    r"|\b(?:sustainability|esg|csr)\b"
    r"|\baccounting\s+polic(?:y|ies)\b"
    r"|\bbasis\s+of\s+(?:preparation|consolidation|presentation)\b"
    r"|\bsee\s+note\s+\d+\b"
    r"|\brefer\s+to\s+note\b"
    r"|\bas\s+(?:described|disclosed|noted)\s+in\b"
    r"|\bscope\s+of\s+(?:work|services?|consolidation)\b",
    re.IGNORECASE,
)


def _should_try_llm(result: ClassificationResult, raw_label: str) -> bool:
    label = (raw_label or "").strip().lower()
    if not label:
        return False

    # Hard length limits: very short labels are junk, very long are disclosures.
    if len(label) < 4 or len(label) > 120:
        return False

    # Substring gate — contact/location/ESG terms.
    if any(term in label for term in _LLM_SKIP_TERMS):
        return False

    # Regex gate — scope rows, disclosure boilerplate, policy notes.
    if _LLM_SKIP_RE.search(label):
        return False

    # Only proceed for unclassified_financial (real metric, no rule coverage)
    # or weak deterministic matches below the confidence threshold.
    if result.classification_method == "unclassified":
        return result.metric_key == "unclassified_financial"

    return result.classification_score < 0.60


def _build_sibling_labels(
    items: list[dict],
    idx: int,
    window: int = 3,
) -> list[str]:
    start = max(0, idx - window)
    end = min(len(items), idx + window + 1)

    labels: list[str] = []
    for j in range(start, end):
        if j == idx:
            continue
        label = (items[j].get("raw_label") or "").strip()
        if label:
            labels.append(label)
    return labels


def _classification_from_llm(
    *,
    llm_result,
    industry_family: str,
    fallback_display_label: str,
) -> ClassificationResult:
    if not llm_result.include or not llm_result.metric_key or not llm_result.metric_group:
        return ClassificationResult(
            industry_family=industry_family,
            metric_group="non_metric",
            metric_key="non_metric",
            display_label=fallback_display_label,
            classification_confidence="low",
            classification_method="llm_exclude",
            classification_score=llm_result.confidence,
            matched_pattern="llm_exclude",
        )

    return ClassificationResult(
        industry_family=industry_family,
        metric_group=llm_result.metric_group,
        metric_key=llm_result.metric_key,
        display_label=llm_result.display_label or fallback_display_label,
        classification_confidence=_score_to_confidence(llm_result.confidence),
        classification_method="llm_fallback",
        classification_score=llm_result.confidence,
        matched_pattern="llm_fallback",
    )


_FINANCIAL_KW = frozenset({
    "revenue", "profit", "loss", "income", "expense", "cost", "sales", "turnover",
    "asset", "liability", "equity", "cash", "debt", "tax", "earnings", "margin",
    "ebit", "ebitda", "capex", "depreciation", "amortization", "amortisation",
    "interest", "dividend", "capital", "borrowing", "provision", "reserve",
    "goodwill", "receivable", "payable", "inventory", "inventories", "pension",
    "lease", "loan", "fee", "premium", "claim", "operating", "financial",
    "impairment", "write", "restructur", "subsidi", "hedge", "hedging",
    "derivative", "instrument", "warrant", "option", "fund",
})


def _unclassified_result(
    label_stripped: str,
    label_normalized: str,
    industry_family: str,
) -> ClassificationResult:
    words = label_normalized.split()

    is_junk = (
        len(words) == 0
        or len(label_stripped) <= 3
        or label_stripped.startswith("===")
        or label_stripped.startswith("---")
        or bool(re.match(r"^\s*[\d,\.]+\s*$", label_stripped))
        or len(label_stripped) > 130
        or sum(1 for c in label_stripped if c.isalpha()) < 4
    )

    has_financial_kw = any(w in _FINANCIAL_KW for w in words)

    if is_junk or not has_financial_kw:
        group = key = "non_metric"
    else:
        group = key = "unclassified_financial"

    return ClassificationResult(
        industry_family=industry_family,
        metric_group=group,
        metric_key=key,
        display_label=label_stripped,
        classification_confidence="low",
        classification_method="unclassified",
        classification_score=0.0,
        matched_pattern="",
    )


_STOPWORDS: frozenset[str] = frozenset({
    "the", "a", "an", "of", "in", "for", "and", "or", "to", "from", "by",
    "on", "at", "is", "as", "per", "its", "this", "that", "with", "has",
    "been", "related", "further", "due", "certain", "year", "period",
    "attributable", "allocated", "recognised", "recognized", "presented",
    "operations", "activities",
})


def _tokenize(label_normalized: str) -> frozenset[str]:
    return frozenset(
        tok for tok in label_normalized.split()
        if tok not in _STOPWORDS and len(tok) >= 3
    )


_POWER_TOKENS: dict[str, tuple[str, str, str, float]] = {
    "ebitda": ("profitability", "ebitda", "EBITDA", 0.65),
    "ebit": ("profitability", "ebit", "EBIT", 0.65),
    "capex": ("cash_flow_investing", "capex", "Capital Expenditure", 0.65),
    "arpu": ("operating_kpi", "arpu", "ARPU", 0.65),
    "fcf": ("operating_kpi", "free_cash_flow", "Free Cash Flow", 0.65),
    "roe": ("operating_kpi", "return_on_equity", "Return on Equity", 0.65),
    "roic": ("operating_kpi", "return_on_capital", "ROIC", 0.65),
    "roce": ("operating_kpi", "return_on_capital", "ROCE", 0.65),
    "roa": ("operating_kpi", "return_on_assets", "Return on Assets", 0.65),
    "eps": ("operating_kpi", "eps_basic", "EPS", 0.65),
    "dps": ("operating_kpi", "dividends_per_share", "Dividend Per Share", 0.65),
    "bvps": ("operating_kpi", "book_value_per_share", "Book Value Per Share", 0.65),
    "nav": ("operating_kpi", "nav", "Net Asset Value", 0.60),
    "ppe": ("assets", "ppe", "PP&E", 0.60),
    "goodwill": ("assets", "goodwill", "Goodwill", 0.60),
    "inventories": ("assets", "inventories", "Inventories", 0.60),
    "inventory": ("assets", "inventories", "Inventories", 0.60),
    "borrowings": ("liabilities", "borrowings", "Borrowings", 0.55),
    "provisions": ("liabilities", "provisions", "Provisions", 0.55),
    "depreciation": ("operating_expense", "depreciation_amortization", "Depreciation", 0.55),
    "amortization": ("operating_expense", "depreciation_amortization", "D&A", 0.55),
    "amortisation": ("operating_expense", "depreciation_amortization", "D&A", 0.55),
    "impairment": ("operating_expense", "impairment", "Impairment", 0.55),
    "restructuring": ("operating_expense", "restructuring", "Restructuring Charges", 0.55),
    "cet1": ("regulatory_or_capital_kpi", "cet1_ratio", "CET1 Ratio", 0.65),
    "lcr": ("regulatory_or_capital_kpi", "lcr", "LCR", 0.65),
    "nsfr": ("regulatory_or_capital_kpi", "nsfr", "NSFR", 0.65),
    "npl": ("operating_kpi", "npl_ratio", "Non-Performing Loans", 0.65),
    "backlog": ("volume_or_usage", "order_backlog", "Order Backlog", 0.60),
    "churn": ("operating_kpi", "churn_rate", "Churn Rate", 0.60),
    "subscribers": ("volume_or_usage", "subscribers", "Subscribers", 0.55),
}


_GroupKeywordRule = tuple[str, str, str, "str | None", frozenset, float]

_GROUP_KEYWORD_RULES: list[_GroupKeywordRule] = [
    ("revenue", "total_revenue", "Revenue", "income_statement",
     frozenset({"revenue", "sales", "turnover", "proceeds", "receipts"}), 0.55),

    ("gross_profit", "gross_profit", "Gross Profit", "income_statement",
     frozenset({"gross", "profit", "margin"}), 0.50),

    ("profitability", "net_profit", "Profit", None,
     frozenset({"profit", "earnings", "income", "loss", "margin"}), 0.40),

    ("tax", "income_tax", "Tax Charge", None,
     frozenset({"tax", "taxes", "taxation", "fiscal"}), 0.55),

    ("operating_expense", "other_opex", "Operating Expense", "income_statement",
     frozenset({"expense", "expenses", "cost", "costs", "charges", "fees"}), 0.35),

    ("assets", "other_current_assets", "Assets", "balance_sheet",
     frozenset({"asset", "assets", "receivable", "receivables",
                "investment", "investments", "property", "equipment",
                "plant", "intangible", "goodwill"}), 0.50),

    ("liabilities", "other_current_liabilities", "Liabilities", "balance_sheet",
     frozenset({"liability", "liabilities", "payable", "payables",
                "debt", "obligation", "obligations", "borrowing", "borrowings"}), 0.50),

    ("equity", "other_reserves", "Equity", "balance_sheet",
     frozenset({"equity", "reserve", "reserves", "retained", "surplus",
                "shareholders", "deficit", "capital", "premium"}), 0.45),

    ("cash_flow_operating", "total", "Cash Flow from Operations", "cash_flow_statement",
     frozenset({"cash", "operating"}), 0.50),

    ("cash_flow_investing", "total", "Cash Flow from Investing", "cash_flow_statement",
     frozenset({"cash", "investing", "investment", "capex", "acquisition"}), 0.50),

    ("cash_flow_financing", "total", "Cash Flow from Financing", "cash_flow_statement",
     frozenset({"cash", "financing", "dividend", "borrowing", "borrowings"}), 0.50),

    ("volume_or_usage", "volume", "Volume", None,
     frozenset({"volume", "units", "tonnes", "barrels", "hectolitres",
                "subscribers", "users", "stores"}), 0.55),
]


def _token_candidates(
    label_normalized: str,
    statement_type: str,
) -> list[tuple[str, str, str, float, str]]:
    tokens = _tokenize(label_normalized)
    if not tokens:
        return []

    candidates: list[tuple[str, str, str, float, str]] = []

    for tok in tokens:
        if tok in _POWER_TOKENS:
            group, key, display, score = _POWER_TOKENS[tok]
            candidates.append((group, key, display, score, f"token_power:{tok}"))

    for group, key, display, stmt_filter, keywords, max_score in _GROUP_KEYWORD_RULES:
        if stmt_filter and stmt_filter != statement_type:
            continue
        overlap = tokens & keywords
        if not overlap:
            continue
        raw = len(overlap) / len(tokens)
        score = raw * max_score
        if score < 0.15:
            continue
        matched = "+".join(sorted(overlap))
        candidates.append((group, key, display, score, f"token_overlap:{matched}"))

    return candidates


def classify_label(
    raw_label: str,
    statement_type: str,
    company: str,
    industry_family: str,
) -> ClassificationResult:
    if not raw_label or not raw_label.strip():
        return _unclassified_result("", "", industry_family)

    label_stripped = raw_label.strip()
    label_normalized = normalize_label(label_stripped)

    best_score: float = -1.0
    best_group: str = ""
    best_key: str = ""
    best_display: str = ""
    best_method: str = ""
    best_pattern: str = ""

    def _consider(
        group: str,
        key: str,
        display: str,
        score: float,
        method: str,
        pattern: str,
    ) -> None:
        nonlocal best_score, best_group, best_key, best_display, best_method, best_pattern
        if score > best_score:
            best_score = score
            best_group = group
            best_key = key
            best_display = display
            best_method = method
            best_pattern = pattern

    company_rules = COMPANY_OVERRIDES.get(company, {})
    if label_stripped in company_rules:
        g, k, d = company_rules[label_stripped]
        _consider(g, k, d, 1.0, "company_rule", f"company_exact:{label_stripped[:50]}")

    industry_exact = INDUSTRY_EXACT_RULES.get(industry_family, {})
    if label_normalized in industry_exact:
        g, k, d = industry_exact[label_normalized]
        _consider(g, k, d, 0.9, "industry_exact_rule", f"industry_exact:{label_normalized[:50]}")

    for pattern, stmt_filter, group, key, display, score in INDUSTRY_PATTERN_RULES.get(industry_family, []):
        if stmt_filter and stmt_filter != statement_type:
            continue
        if pattern.search(label_stripped) or pattern.search(label_normalized):
            _consider(
                group,
                key,
                display,
                score,
                "industry_pattern_rule",
                f"industry_pattern:{pattern.pattern[:60]}",
            )

    for pattern, stmt_filter, group, key, display, score in GENERIC_HEURISTIC_RULES:
        if stmt_filter and stmt_filter != statement_type:
            continue
        if pattern.search(label_stripped) or pattern.search(label_normalized):
            _consider(
                group,
                key,
                display,
                score,
                "generic_heuristic",
                f"generic:{pattern.pattern[:60]}",
            )

    for group, key, display, score, tok_pattern in _token_candidates(label_normalized, statement_type):
        method = "token_power" if tok_pattern.startswith("token_power") else "token_overlap"
        _consider(group, key, display, score, method, tok_pattern)

    if best_score >= 0:
        return ClassificationResult(
            industry_family=industry_family,
            metric_group=best_group,
            metric_key=best_key,
            display_label=best_display,
            classification_confidence=_score_to_confidence(best_score),
            classification_method=best_method,
            classification_score=best_score,
            matched_pattern=best_pattern,
        )

    return _unclassified_result(label_stripped, label_normalized, industry_family)


def run_classify(
    company: Optional[str] = None,
    db_path: Optional[Path] = None,
) -> dict[str, int]:
    """Classify all raw_line_items. Returns classified/unclassified counts."""
    db_path = db_path or db.DB_PATH
    totals: dict[str, int] = {
        "classified": 0,
        "unclassified": 0,
        "companies_processed": 0,
    }

    with db.get_connection(db_path) as conn:
        if company:
            companies = [company]
        else:
            rows = conn.execute(
                "SELECT DISTINCT company FROM raw_line_items ORDER BY company"
            ).fetchall()
            companies = [r["company"] for r in rows]

    llm_client = LLMClient()
    use_llm = llm_client.enabled() and os.getenv("ENABLE_LLM_FALLBACK", "1") == "1"
    max_llm_calls = int(os.getenv("MAX_LLM_CALLS", "100"))
    use_recovery = use_llm and os.getenv("ENABLE_LLM_RECOVERY", "1") == "1"
    max_recovery_calls = int(os.getenv("MAX_LLM_RECOVERY_CALLS", "20"))

    if use_llm:
        logger.info("[classify] LLM fallback enabled (MAX_LLM_CALLS=%s)", max_llm_calls)
    else:
        logger.info("[classify] LLM fallback disabled")

    for co in companies:
        industry_family = COMPANY_TO_INDUSTRY.get(co, "generic")
        logger.info("[classify] %s — industry_family=%r", co, industry_family)

        with db.get_connection(db_path) as conn:
            db.delete_classified_metrics_for_company(conn, co)
            items = conn.execute(
                """
                SELECT id, company, report_year, statement_type,
                       raw_label, raw_value, parsed_value,
                       period_label, period_year, page_number
                FROM   raw_line_items
                WHERE  company = ?
                ORDER  BY id
                """,
                (co,),
            ).fetchall()
            items = [dict(r) for r in items]

        if not items:
            logger.info("[classify] %s: no raw_line_items found — skipping", co)
            totals["companies_processed"] += 1
            continue

        logger.info("[classify] %s: classifying %s raw_line_items", co, f"{len(items):,}")

        classified_n = 0
        unclassified_n = 0
        llm_calls = 0
        llm_cache_hits = 0
        llm_accepted = 0
        llm_failed = 0
        # In-run cache: (normalized_label, statement_type, report_year) → MetricMappingResult.
        # Including report_year avoids cross-year cache pollution for labels whose
        # context changes between filings (e.g. a KPI that shifted statement position).
        _llm_cache: dict[tuple[str, str, int | None], object] = {}
        now = datetime.now(timezone.utc).isoformat()
        batch: list[dict] = []

        for idx, item in enumerate(items):
            result = classify_label(
                raw_label=item.get("raw_label") or "",
                statement_type=item.get("statement_type") or "",
                company=co,
                industry_family=industry_family,
            )

            raw_label   = item.get("raw_label") or ""
            stmt_type   = item.get("statement_type") or ""
            report_year = item.get("report_year")

            should_try = _should_try_llm(result, raw_label)

            if use_llm and should_try:
                cache_key = (normalize_label(raw_label), stmt_type, report_year)
                try:
                    if cache_key in _llm_cache:
                        llm_result = _llm_cache[cache_key]
                        llm_cache_hits += 1
                        logger.debug(
                            "[classify] LLM cache hit company=%s label=%r",
                            co, raw_label,
                        )
                    elif llm_calls < max_llm_calls:
                        sibling_labels = _build_sibling_labels(items, idx)
                        logger.info(
                            "[classify] LLM fallback #%s company=%s label=%r",
                            llm_calls + 1, co, raw_label,
                        )
                        llm_result = map_metric_with_llm(
                            raw_label=raw_label,
                            statement_type=stmt_type,
                            sibling_labels=sibling_labels,
                            company=co,
                            report_year=report_year,
                            client=llm_client,
                        )
                        _llm_cache[cache_key] = llm_result
                        llm_calls += 1
                    else:
                        llm_result = None  # budget exhausted, cache miss — skip

                    if llm_result is not None:
                        deterministic_metric_key = (
                            None if result.classification_method == "unclassified"
                            else result.metric_key
                        )
                        if should_accept_llm(
                            deterministic_metric_key=deterministic_metric_key,
                            deterministic_score=result.classification_score,
                            llm_metric_key=llm_result.metric_key,
                            llm_confidence=llm_result.confidence,
                        ):
                            result = _classification_from_llm(
                                llm_result=llm_result,
                                industry_family=industry_family,
                                fallback_display_label=raw_label,
                            )
                            llm_accepted += 1
                            logger.info(
                                "[classify] LLM accepted company=%s label=%r -> %s/%s (%.2f)",
                                co, raw_label,
                                result.metric_group, result.metric_key,
                                result.classification_score,
                            )
                except Exception as e:
                    llm_failed += 1
                    logger.warning(
                        "[classify] LLM failed company=%s label=%r: %s",
                        co, raw_label, e,
                    )

            effective_display = result.display_label or raw_label

            batch.append({
                "raw_line_item_id": item["id"],
                "company": co,
                "report_year": item.get("report_year"),
                "statement_type": item.get("statement_type"),
                "raw_label": item.get("raw_label"),
                "raw_value": item.get("raw_value"),
                "parsed_value": item.get("parsed_value"),
                "period_label": item.get("period_label"),
                "period_year": item.get("period_year"),
                "page_number": item.get("page_number"),
                "industry_family": result.industry_family,
                "metric_group": result.metric_group,
                "metric_key": result.metric_key,
                "display_label": effective_display,
                "classification_confidence": result.classification_confidence,
                "classification_method": result.classification_method,
                "classification_score": result.classification_score,
                "matched_pattern": result.matched_pattern,
                "classified_at": now,
            })

            if result.classification_method == "unclassified":
                unclassified_n += 1
            else:
                classified_n += 1

        with db.get_connection(db_path) as conn:
            conn.executemany(
                """
                INSERT INTO classified_metrics
                    (raw_line_item_id, company, report_year, statement_type,
                     raw_label, raw_value, parsed_value, period_label, period_year,
                     page_number, industry_family, metric_group, metric_key,
                     display_label, classification_confidence, classification_method,
                     classification_score, matched_pattern, classified_at)
                VALUES
                    (:raw_line_item_id, :company, :report_year, :statement_type,
                     :raw_label, :raw_value, :parsed_value, :period_label, :period_year,
                     :page_number, :industry_family, :metric_group, :metric_key,
                     :display_label, :classification_confidence, :classification_method,
                     :classification_score, :matched_pattern, :classified_at)
                ON CONFLICT(raw_line_item_id) DO UPDATE SET
                    metric_group              = excluded.metric_group,
                    metric_key                = excluded.metric_key,
                    display_label             = excluded.display_label,
                    industry_family           = excluded.industry_family,
                    classification_confidence = excluded.classification_confidence,
                    classification_method     = excluded.classification_method,
                    classification_score      = excluded.classification_score,
                    matched_pattern           = excluded.matched_pattern,
                    classified_at             = excluded.classified_at
                """,
                batch,
            )

        logger.info(
            "[classify] %s: classified=%s unclassified=%s | "
            "llm_calls=%s llm_cache_hits=%s llm_accepted=%s llm_failed=%s",
            co,
            f"{classified_n:,}",
            f"{unclassified_n:,}",
            llm_calls,
            llm_cache_hits,
            llm_accepted,
            llm_failed,
        )

        if use_recovery:
            with db.get_connection(db_path) as conn:
                run_missing_field_recovery(
                    co,
                    conn,
                    llm_client=llm_client,
                    industry_family=industry_family,
                    max_calls=max_recovery_calls,
                )

        totals["classified"] += classified_n
        totals["unclassified"] += unclassified_n
        totals["companies_processed"] += 1

    return totals

def main() -> None:
    import argparse
    import json

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    parser = argparse.ArgumentParser(description="Classify raw financial metrics")
    parser.add_argument("--company", help="Company slug to classify, e.g. adyen")
    parser.add_argument("--db-path", help="Optional path to fiscal.db")
    args = parser.parse_args()

    result = run_classify(
        company=args.company,
        db_path=Path(args.db_path) if args.db_path else None,
    )

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()