"""
Heuristic classification of filing documents.

Assigns document_type and infers fiscal_year from a filing's title and URL.
No ML, no network calls — pure regex pattern matching.

Priority order (first match wins):
  1. sustainability / ESG
  2. quarterly
  3. interim / half-year
  4. annual report (affirmative match)
  5. other (default)
"""
import logging
import re

logger = logging.getLogger(__name__)

# Extract first 4-digit year in range 2000–2029
_YEAR_RE = re.compile(r"\b(20\d{2})\b")

# --- Affirmative patterns ------------------------------------------------

_ANNUAL_PATTERNS = [
    re.compile(p, re.IGNORECASE)
    for p in [
        r"annual[\s\-_]report",
        r"annual[\s\-_]review",
        r"integrated[\s\-_]annual",
        r"integrated[\s\-_]report",  # SAP "Integrated Report" branding
        r"full[\s\-_]year[\s\-_]report",
        r"jaarverslag",          # Dutch
        r"gesch[äa]ftsbericht",  # German (with or without umlaut)
        r"jahresbericht",        # German alternative
    ]
]

# --- Exclusion / override patterns (checked before annual) ---------------

_SUSTAINABILITY_PATTERNS = [
    re.compile(p, re.IGNORECASE)
    for p in [
        r"\bsustainability\b",
        r"\besg\b",
        r"\bcsr\b",
        r"responsible[\s\-]business",
        r"climate[\s\-]report",
        r"non[\s\-]financial",
    ]
]

_QUARTERLY_PATTERNS = [
    re.compile(p, re.IGNORECASE)
    for p in [
        r"\bq[1-4]\b",
        r"\bquarter(?:ly)?\b",
        r"first quarter",
        r"second quarter",
        r"third quarter",
        r"fourth quarter",
    ]
]

_INTERIM_PATTERNS = [
    re.compile(p, re.IGNORECASE)
    for p in [
        r"\bh[12]\b",
        r"half[\s\-]year",
        r"semi[\s\-]annual",
        r"\binterim\b",
        r"six[\s\-]month",
    ]
]


def classify_filing(title: str, url: str) -> tuple[str, int | None]:
    """
    Classify a filing candidate by document type and infer its fiscal year.

    Returns:
        (document_type, fiscal_year)
        document_type : "annual_report" | "interim_report" | "quarterly"
                        | "sustainability" | "other"
        fiscal_year   : int (e.g. 2022) or None if not determinable
    """
    combined = f"{title} {url}"
    fiscal_year = _extract_year(combined)

    # If the title explicitly matches an annual report pattern, trust it over
    # URL-based signals (e.g. Heineken hosts annual reports under a
    # /sustainability-and-responsibility/ path that would otherwise trigger
    # the sustainability override).
    if any(p.search(title) for p in _ANNUAL_PATTERNS):
        logger.debug(f"classify → annual_report (title match, year={fiscal_year}): {title!r}")
        return "annual_report", fiscal_year

    # Check overrides first (in priority order)
    if any(p.search(combined) for p in _SUSTAINABILITY_PATTERNS):
        logger.debug(f"classify → sustainability: {title!r}")
        return "sustainability", fiscal_year

    if any(p.search(combined) for p in _QUARTERLY_PATTERNS):
        logger.debug(f"classify → quarterly: {title!r}")
        return "quarterly", fiscal_year

    if any(p.search(combined) for p in _INTERIM_PATTERNS):
        logger.debug(f"classify → interim_report: {title!r}")
        return "interim_report", fiscal_year

    # Affirmative annual report check
    if any(p.search(combined) for p in _ANNUAL_PATTERNS):
        logger.debug(f"classify → annual_report (year={fiscal_year}): {title!r}")
        return "annual_report", fiscal_year

    logger.debug(f"classify → other: {title!r}")
    return "other", fiscal_year


def _extract_year(text: str) -> int | None:
    """Return the first 4-digit year (2000–2029) found in text, or None."""
    m = _YEAR_RE.search(text)
    return int(m.group(1)) if m else None
