"""Fiscal CLI — main entry point."""
import logging
import sys
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from fiscal import canonicalizer, classify_metrics as classifier, combined_builder, db, discovery, download as downloader, exporter, view_builder
from fiscal.extraction import pipeline as extractor
from fiscal.extraction.table_cleaner import run_clean, run_clean_all

app = typer.Typer(
    name="fiscal",
    help="European public company financial data pipeline.",
    add_completion=False,
    no_args_is_help=True,
)
console = Console()


def _setup_logging(verbose: bool) -> None:
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s  %(name)-40s  %(levelname)-8s  %(message)s",
        datefmt="%H:%M:%S",
        stream=sys.stderr,
    )


def _require_db() -> None:
    if not db.DB_PATH.exists():
        console.print(
            "[red]Database not found.[/red] "
            "Run [bold cyan]fiscal init[/bold cyan] first.",
            err=True,
        )
        raise typer.Exit(1)


@app.command()
def init(
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Enable debug logging"),
) -> None:
    """Initialize the database and data directory structure."""
    _setup_logging(verbose)

    for company in ("adyen", "heineken", "sap"):
        (Path("data") / "pdfs" / company).mkdir(parents=True, exist_ok=True)
    Path("output").mkdir(parents=True, exist_ok=True)
    db.init_db(db.DB_PATH)

    console.print(f"[green]✓[/green] Database initialized at [bold]{db.DB_PATH}[/bold]")
    console.print(f"[green]✓[/green] PDF directories created under [bold]data/pdfs/[/bold]")
    console.print(f"[green]✓[/green] Output directory: [bold]output/[/bold]")


@app.command()
def discover(
    company: Optional[str] = typer.Option(
        None,
        "--company", "-c",
        help="Company key to run (adyen | heineken | sap). Omit for all.",
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Enable debug logging"),
) -> None:
    """Discover filings from IR pages and classify them. Writes to DB."""
    _setup_logging(verbose)
    _require_db()

    label = f"[bold]{company}[/bold]" if company else "all companies"
    console.print(f"Running discovery for {label}...")

    try:
        results = discovery.run_discovery(company=company)
    except ValueError as exc:
        console.print(f"[red]Error:[/red] {exc}", err=True)
        raise typer.Exit(1)

    total_new = sum(results.values())
    for key, count in sorted(results.items()):
        symbol = "[green]+[/green]" if count > 0 else " "
        console.print(f"  {symbol} {key:<12}  {count} new filing(s)")

    console.print()
    console.print(f"Discovery complete: [bold]{total_new}[/bold] new filing(s) added.")
    if total_new == 0:
        console.print(
            "[dim](All discovered URLs are already in the database.)[/dim]"
        )


@app.command()
def download(
    company: Optional[str] = typer.Option(
        None,
        "--company", "-c",
        help="Restrict to one company key (adyen | heineken | sap). Omit for all.",
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Enable debug logging"),
) -> None:
    """Download annual report PDFs to data/pdfs/<company>/."""
    _setup_logging(verbose)
    _require_db()

    label = f"[bold]{company}[/bold]" if company else "all companies"
    console.print(f"Downloading annual reports for {label}...")

    try:
        counts = downloader.run_download(company=company)
    except ValueError as exc:
        console.print(f"[red]Error:[/red] {exc}", err=True)
        raise typer.Exit(1)

    console.print(
        f"\nDone: [green]{counts['downloaded']}[/green] downloaded, "
        f"{counts['skipped']} skipped, "
        f"[{'red' if counts['failed'] else 'dim'}]{counts['failed']} failed[/{'red' if counts['failed'] else 'dim'}]."
    )
    if counts["failed"]:
        console.print(
            "[dim]Re-run with --verbose to see per-filing error details.[/dim]"
        )
        raise typer.Exit(1)


@app.command()
def extract(
    company: Optional[str] = typer.Option(
        None,
        "--company", "-c",
        help="Restrict to one company key (adyen | heineken | sap). Omit for all.",
    ),
    filing_id: Optional[int] = typer.Option(
        None,
        "--filing-id",
        help=(
            "Extract (or re-extract) a single filing by DB id. "
            "Clears existing raw_tables for that filing first."
        ),
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Enable debug logging"),
) -> None:
    """Extract raw financial tables from downloaded annual report PDFs."""
    _setup_logging(verbose)
    _require_db()

    if filing_id:
        console.print(f"Extracting filing ID [bold]{filing_id}[/bold] (clearing previous results)...")
    else:
        label = f"[bold]{company}[/bold]" if company else "all companies"
        console.print(f"Extracting annual reports for {label}...")

    try:
        counts = extractor.run_extract(
            company=company,
            filing_id=filing_id,
        )
    except ValueError as exc:
        console.print(f"[red]Error:[/red] {exc}", err=True)
        raise typer.Exit(1)

    console.print(
        f"\nExtraction complete: "
        f"[green]{counts['extracted']}[/green] extracted, "
        f"{counts['skipped']} skipped, "
        f"[{'red' if counts['failed'] else 'dim'}]{counts['failed']} failed"
        f"[/{'red' if counts['failed'] else 'dim'}]."
    )
    if counts["failed"]:
        console.print("[dim]Re-run with --verbose to see per-filing error details.[/dim]")
        raise typer.Exit(1)


@app.command()
def clean(
    filing_id: int = typer.Option(
        ...,
        "--filing-id",
        help="Clean a single filing by DB id.",
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Convert raw_tables into raw_line_items."""
    _setup_logging(verbose)
    _require_db()

    console.print(f"Cleaning filing ID [bold]{filing_id}[/bold]...")

    try:
        counts = run_clean(filing_id=filing_id)
    except Exception as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(1)

    console.print(
        f"\nCleaning complete: "
        f"[green]{counts['items_inserted']}[/green] row(s) written."
    )

@app.command()
def canonicalize(
    company: Optional[str] = typer.Option(
        None, "--company", "-c",
        help="Restrict to one company (adyen | heineken | sap). Omit for all.",
    ),
    statement_type: Optional[str] = typer.Option(
        None, "--statement",
        help="Restrict to one statement type. Omit for all.",
    ),
    api_key: Optional[str] = typer.Option(
        None, "--api-key",
        help="OpenAI API key (falls back to OPENAI_API_KEY env var).",
    ),
    model: str = typer.Option("gpt-4o", "--model", help="OpenAI model to use."),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Use GPT-4o to deduplicate and order financial statement labels."""
    _setup_logging(verbose)
    _require_db()

    label = f"[bold]{company}[/bold]" if company else "all companies"
    console.print(f"Canonicalizing labels for {label} using [bold]{model}[/bold]…")

    try:
        result = canonicalizer.run_canonicalize(
            company=company,
            statement_type=statement_type,
            api_key=api_key,
            model=model,
        )
    except Exception as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(1)

    console.print(
        f"Done: [bold]{result['mappings_written']}[/bold] mapping(s) written "
        f"across {result['combinations_processed']} statement(s)."
    )


@app.command(name="build-combined")
def build_combined(
    company: Optional[str] = typer.Option(
        None, "--company", "-c",
        help="Restrict to one company (adyen | heineken | sap). Omit for all.",
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Build combined_views: all 3 statements per company in one DB table with canonical labels."""
    _setup_logging(verbose)
    _require_db()

    label = f"[bold]{company}[/bold]" if company else "all companies"
    console.print(f"Building combined views for {label}...")

    try:
        result = combined_builder.run_build_combined(company=company)
    except Exception as exc:
        console.print(f"[red]Error:[/red] {exc}", err=True)
        raise typer.Exit(1)

    console.print(
        f"Done: [bold]{result['rows_written']}[/bold] row(s) written "
        f"across {result['companies_processed']} company/companies."
    )


@app.command(name="classify-metrics")
def classify_metrics_cmd(
    company: Optional[str] = typer.Option(
        None, "--company", "-c",
        help="Company key to classify (adyen | heineken | sap). Omit for all.",
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Classify raw_line_items into metric groups. Safe to re-run."""
    _setup_logging(verbose)
    _require_db()

    label = f"[bold]{company}[/bold]" if company else "all companies"
    console.print(f"Classifying metrics for {label}…")

    try:
        result = classifier.run_classify(company=company)
    except Exception as exc:
        console.print(f"[red]Error:[/red] {exc}", err=True)
        raise typer.Exit(1)

    co_count = result["companies_processed"]
    console.print(
        f"Done: [bold]{result['classified']:,}[/bold] classified, "
        f"[dim]{result['unclassified']:,}[/dim] unclassified "
        f"across {co_count} company/companies."
    )


@app.command(name="build-views")
def build_views(
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Build compiled views from extracted line items."""
    _setup_logging(verbose)
    _require_db()

    console.print("Building compiled views...")
    try:
        counts = view_builder.run_build_views()
    except Exception as exc:
        console.print(f"[red]Error:[/red] {exc}", err=True)
        raise typer.Exit(1)

    console.print(
        f"Done: [bold]{counts['rows_written']}[/bold] row(s) written to compiled_views."
    )


@app.command()
def export(
    company: Optional[str] = typer.Option(None, "--company", "-c"),
    fmt: str = typer.Option("both", "--format", help="Output format: csv | json | both"),
    output_dir: str = typer.Option("output", "--output-dir"),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Export compiled views and filings inventory to CSV / JSON."""
    _setup_logging(verbose)
    _require_db()

    if fmt not in ("csv", "json", "both"):
        console.print(
            f"[red]Error:[/red] --format must be csv, json, or both (got {fmt!r})",
            err=True,
        )
        raise typer.Exit(1)

    label = f"[bold]{company}[/bold]" if company else "all companies"
    console.print(f"Exporting {label} → [bold]{output_dir}/[/bold] (format: {fmt})")

    try:
        result = exporter.run_export(
            company=company,
            fmt=fmt,
            output_dir=output_dir,
        )
    except Exception as exc:
        console.print(f"[red]Error:[/red] {exc}", err=True)
        raise typer.Exit(1)

    for path in result["written"]:
        console.print(f"  [green]✓[/green] {path}")
    console.print(f"\n{len(result['written'])} file(s) written.")


@app.command(name="export-pdf")
def export_pdf(
    company: Optional[str] = typer.Option(None, "--company", "-c"),
    output_dir: str = typer.Option("output", "--output-dir"),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Export compiled views to a formatted PDF report (one file per company)."""
    from fiscal.pdf_exporter import run_export_pdf

    _setup_logging(verbose)
    _require_db()

    label = f"[bold]{company}[/bold]" if company else "all companies"
    console.print(f"Exporting PDF report for {label} → [bold]{output_dir}/[/bold]")

    try:
        result = run_export_pdf(company=company, output_dir=output_dir)
    except Exception as exc:
        console.print(f"[red]Error:[/red] {exc}", err=True)
        raise typer.Exit(1)

    for path in result["written"]:
        console.print(f"  [green]✓[/green] {path}")
    console.print(f"\n{len(result['written'])} PDF file(s) written.")


@app.command()
def serve(
    host: str = typer.Option("127.0.0.1", "--host", help="Bind address"),
    port: int = typer.Option(8080, "--port", "-p", help="Port to listen on"),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Start the web UI — a button that runs the pipeline and downloads a PDF."""
    from fiscal.server import run_server

    _setup_logging(verbose)
    _require_db()

    console.print(
        f"[green]✓[/green] Fiscal server starting at "
        f"[bold cyan]http://{host}:{port}[/bold cyan]"
    )
    console.print("[dim]Press Ctrl+C to stop.[/dim]")
    run_server(host=host, port=port)


@app.command(name="run-all")
def run_all(
    company: Optional[str] = typer.Option(None, "--company", "-c"),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Run the full pipeline end-to-end: discover → download → extract → clean → build-views → export."""
    _setup_logging(verbose)
    _require_db()

    label = f"[bold]{company}[/bold]" if company else "all companies"
    console.print(f"Running full pipeline for {label}...\n")

    console.print("[bold cyan]1/6[/bold cyan] Discovering filings...")
    try:
        results = discovery.run_discovery(company=company)
    except ValueError as exc:
        console.print(f"[red]Error during discovery:[/red] {exc}", err=True)
        raise typer.Exit(1)
    total_new = sum(results.values())
    for key, count in sorted(results.items()):
        console.print(f"  {'[green]+[/green]' if count > 0 else ' '} {key:<12}  {count} new filing(s)")
    console.print(f"  → {total_new} new filing(s) added.\n")

    console.print("[bold cyan]2/6[/bold cyan] Downloading PDFs...")
    try:
        dl_counts = downloader.run_download(company=company)
    except ValueError as exc:
        console.print(f"[red]Error during download:[/red] {exc}", err=True)
        raise typer.Exit(1)
    console.print(
        f"  → [green]{dl_counts['downloaded']}[/green] downloaded, "
        f"{dl_counts['skipped']} skipped, "
        f"[{'red' if dl_counts['failed'] else 'dim'}]{dl_counts['failed']} failed[/{'red' if dl_counts['failed'] else 'dim'}].\n"
    )

    console.print("[bold cyan]3/6[/bold cyan] Extracting financial tables...")
    try:
        ex_counts = extractor.run_extract(company=company)
    except ValueError as exc:
        console.print(f"[red]Error during extraction:[/red] {exc}", err=True)
        raise typer.Exit(1)
    console.print(
        f"  → [green]{ex_counts['extracted']}[/green] extracted, "
        f"{ex_counts['skipped']} skipped, "
        f"[{'red' if ex_counts['failed'] else 'dim'}]{ex_counts['failed']} failed[/{'red' if ex_counts['failed'] else 'dim'}].\n"
    )

    console.print("[bold cyan]4/6[/bold cyan] Cleaning tables into line items...")
    try:
        cl_counts = run_clean_all(company=company)
    except Exception as exc:
        console.print(f"[red]Error during clean:[/red] {exc}", err=True)
        raise typer.Exit(1)
    console.print(
        f"  → [green]{cl_counts['filings_cleaned']}[/green] filing(s) cleaned, "
        f"{cl_counts['items_inserted']} line item(s) inserted.\n"
    )

    console.print("[bold cyan]5/6[/bold cyan] Building compiled views...")
    try:
        vb_counts = view_builder.run_build_views()
    except Exception as exc:
        console.print(f"[red]Error during build-views:[/red] {exc}", err=True)
        raise typer.Exit(1)
    console.print(f"  → [bold]{vb_counts['rows_written']}[/bold] row(s) written.\n")

    console.print("[bold cyan]6/6[/bold cyan] Exporting to output/...")
    try:
        exp_result = exporter.run_export(company=company, fmt="both", output_dir="output")
    except Exception as exc:
        console.print(f"[red]Error during export:[/red] {exc}", err=True)
        raise typer.Exit(1)
    for path in exp_result["written"]:
        console.print(f"  [green]✓[/green] {path}")
    console.print()

    console.print("[green bold]Pipeline complete.[/green bold]")
    if dl_counts["failed"] or ex_counts["failed"]:
        raise typer.Exit(1)


@app.command()
def reset(
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt"),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Delete all data: clears the database and output/ folder. Keeps PDF files."""
    _setup_logging(verbose)

    if not yes:
        typer.confirm(
            "This will delete all DB contents and output/ files. Continue?",
            abort=True,
        )

    import shutil

    if db.DB_PATH.exists():
        with db.get_connection(db.DB_PATH) as conn:
            conn.execute("DELETE FROM combined_views")
            conn.execute("DELETE FROM compiled_views")
            try:
                conn.execute("DELETE FROM classified_metrics")
            except Exception:
                pass
            conn.execute("DELETE FROM raw_line_items")
            conn.execute("DELETE FROM raw_tables")
            conn.execute("DELETE FROM filings")
        console.print(f"[green]✓[/green] Database cleared ({db.DB_PATH})")
    else:
        console.print("[dim]Database not found — skipping.[/dim]")

    output_dir = Path("output")
    if output_dir.exists():
        deleted = 0
        for f in output_dir.iterdir():
            if f.is_file():
                f.unlink()
                deleted += 1
            elif f.is_dir():
                shutil.rmtree(f)
                deleted += 1
        console.print(f"[green]✓[/green] output/ cleared ({deleted} item(s) deleted)")
    else:
        console.print("[dim]output/ directory not found — skipping.[/dim]")


@app.command()
def status(
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Show pipeline state: filing counts, extraction progress, DB row totals."""
    _setup_logging(verbose)
    _require_db()

    with db.get_connection() as conn:
        summary = db.get_status_summary(conn)
        counts = db.get_aggregate_counts(conn)

    if not summary:
        console.print(
            "No filings in database yet. "
            "Run [bold cyan]fiscal discover[/bold cyan] first."
        )
        return

    tbl = Table(title="Fiscal Pipeline Status", show_lines=True, expand=False)
    tbl.add_column("Company",        style="bold", min_width=10)
    tbl.add_column("Total Filings",  justify="right")
    tbl.add_column("Annual Reports", justify="right", style="cyan")
    tbl.add_column("Downloaded",     justify="right")
    tbl.add_column("Extracted",      justify="right", style="green")
    tbl.add_column("Failed",         justify="right", style="red")

    for row in summary:
        tbl.add_row(
            row["company"],
            str(row["total_filings"]  or 0),
            str(row["annual_reports"] or 0),
            str(row["downloaded"]     or 0),
            str(row["extracted"]      or 0),
            str(row["failed"]         or 0),
        )

    console.print(tbl)
    console.print()
    console.print(f"  Raw tables stored    :  [bold]{counts['raw_tables']:>6,}[/bold]")
    console.print(f"  Raw line items       :  [bold]{counts['raw_line_items']:>6,}[/bold]")
    console.print(f"  Classified metrics   :  [bold]{counts['classified_metrics']:>6,}[/bold]")
    console.print(f"  Compiled view rows   :  [bold]{counts['compiled_views']:>6,}[/bold]")
    console.print(f"  Combined view rows:  [bold]{counts['combined_views']:>6,}[/bold]")
